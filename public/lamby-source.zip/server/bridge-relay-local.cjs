const http = require("http");
const crypto = require("crypto");
const zlib = require("zlib");
const fs = require("fs");
const path = require("path");
const os = require("os");
const PORT = parseInt(process.env.PORT || "3000", 10);

const _customTools = {};
let _testMode = false;
(function loadCustomTools() {
  try {
    const toolsDir = path.join(os.homedir(), ".guardian-ai", "custom-tools");
    if (fs.existsSync(toolsDir)) {
      const files = fs.readdirSync(toolsDir).filter(f => f.endsWith(".json"));
      for (const f of files) {
        try {
          const data = JSON.parse(fs.readFileSync(path.join(toolsDir, f), "utf-8"));
          if (data.name && data.code) {
            _customTools[data.name] = { name: data.name, description: data.description || "", fn: new Function("params", "bridgeExec", "Buffer", data.code), createdAt: data.createdAt || "loaded" };
          }
        } catch (_) {}
      }
      if (Object.keys(_customTools).length > 0) {
        console.log(`[relay] Loaded ${Object.keys(_customTools).length} custom tool(s): ${Object.keys(_customTools).join(", ")}`);
      }
    }
  } catch (_) {}
})();

const _actionMemory = {};
const _ACTION_MEMORY_DIR = path.join(os.homedir(), ".guardian-ai", "action-memory");
(function loadActionMemory() {
  try {
    if (fs.existsSync(_ACTION_MEMORY_DIR)) {
      const files = fs.readdirSync(_ACTION_MEMORY_DIR).filter(f => f.endsWith(".json"));
      for (const f of files) {
        try {
          const data = JSON.parse(fs.readFileSync(path.join(_ACTION_MEMORY_DIR, f), "utf-8"));
          if (data.key) _actionMemory[data.key] = data;
        } catch (_) {}
      }
      if (Object.keys(_actionMemory).length > 0) {
        console.log(`[relay] Loaded ${Object.keys(_actionMemory).length} action memory entries`);
      }
    }
  } catch (_) {}
})();

function memoryKey(taskName, params) {
  const sortedKeys = Object.keys(params).filter(k => k !== "confirm" && k !== "recall").sort();
  const paramStr = sortedKeys.map(k => `${k}=${params[k]}`).join("&");
  return `${taskName}${paramStr ? "?" + paramStr : ""}`;
}

function memoryFileHash(key) {
  return crypto.createHash("sha256").update(key).digest("hex").slice(0, 24);
}

function memorySave(taskName, params, stepCount, elapsedMs, resultSummary) {
  const key = memoryKey(taskName, params);
  const existing = _actionMemory[key];
  const prevCount = existing ? (existing.successCount || 0) : 0;
  if (existing && existing.stepCount <= stepCount && existing.elapsedMs <= elapsedMs) {
    existing.successCount = prevCount + 1;
    existing.lastUsed = new Date().toISOString();
    try {
      if (!fs.existsSync(_ACTION_MEMORY_DIR)) fs.mkdirSync(_ACTION_MEMORY_DIR, { recursive: true });
      fs.writeFileSync(path.join(_ACTION_MEMORY_DIR, `${memoryFileHash(key)}.json`), JSON.stringify(existing, null, 2));
    } catch (_) {}
    return false;
  }
  const entry = { key, task: taskName, params, stepCount, elapsedMs, resultSummary: (resultSummary || "").slice(0, 500), savedAt: new Date().toISOString(), lastUsed: new Date().toISOString(), successCount: prevCount + 1 };
  _actionMemory[key] = entry;
  try {
    if (!fs.existsSync(_ACTION_MEMORY_DIR)) fs.mkdirSync(_ACTION_MEMORY_DIR, { recursive: true });
    fs.writeFileSync(path.join(_ACTION_MEMORY_DIR, `${memoryFileHash(key)}.json`), JSON.stringify(entry, null, 2));
  } catch (_) {}
  return true;
}

function memoryRecall(query) {
  const q = (query || "").toLowerCase();
  const results = [];
  for (const entry of Object.values(_actionMemory)) {
    const haystack = `${entry.key} ${entry.task} ${entry.resultSummary || ""}`.toLowerCase();
    if (haystack.includes(q)) results.push(entry);
  }
  results.sort((a, b) => (b.successCount || 0) - (a.successCount || 0));
  return results.slice(0, 10);
}

const _recoveryPatterns = [
  { pattern: /selector.*(not found|no.element|not visible|timed out)/i, strategy: "retry_snapshot", desc: "Re-take snapshot then retry with updated selectors" },
  { pattern: /timeout|timed? out|ETIMEDOUT/i, strategy: "retry_wait", desc: "Wait longer then retry" },
  { pattern: /process.*(not running|not found|exited|crashed)/i, strategy: "relaunch", desc: "Re-launch the process" },
  { pattern: /ECONNREFUSED|ECONNRESET|connection.*(refused|reset)/i, strategy: "retry_delay", desc: "Wait and retry (connection issue)" },
  { pattern: /file.*(not found|missing|does not exist)/i, strategy: "check_path", desc: "Verify path exists" },
  { pattern: /permission|access denied|EPERM|EACCES/i, strategy: "elevate", desc: "Try with elevated permissions" },
];

function classifyError(errorMsg) {
  for (const rp of _recoveryPatterns) {
    if (rp.pattern.test(errorMsg)) return rp;
  }
  return null;
}

const _HIGH_RISK_COMMANDS = /\b(taskkill|kill|del\s|rmdir|rm\s+-rf|Remove-Item|Stop-Service|sc\s+stop|reg\s+(delete|add)|net\s+stop|winget\s+uninstall|format\s+[A-Z]:)/i;
const _HIGH_RISK_TYPES = new Set(["delete_file"]);

function classifyRisk(step) {
  if (_HIGH_RISK_TYPES.has(step.type)) return { high: true, reason: `Destructive action: ${step.type} on ${step.path || step.file || "unknown"}` };
  if ((step.type === "run_command" || step.type === "run_command_advanced") && step.command) {
    const m = step.command.match(_HIGH_RISK_COMMANDS);
    if (m) return { high: true, reason: `High-risk command detected: "${m[0]}" in "${step.command.slice(0, 100)}"` };
  }
  return { high: false };
}

// Multi-desktop connection registry — keyed by project name (one slot per project)
const desktopClients = new Map(); // project → client
const pendingRelayRequests = new Map();
const pendingSandboxRelayRequests = new Map();
const pendingConsoleLogRequests = new Map();

// ── Phantom queue: when bridge disconnects, queue outbound messages and flush on reconnect ──
const _phantomQueues = new Map(); // project → { queue: [{data, resolve}], disconnectedAt }
const PHANTOM_TTL_MS = 120000; // keep phantom alive for 2 minutes
function getOrCreatePhantom(projectKey) {
  if (!_phantomQueues.has(projectKey)) _phantomQueues.set(projectKey, { queue: [], disconnectedAt: Date.now() });
  return _phantomQueues.get(projectKey);
}
function flushPhantom(projectKey, client) {
  const phantom = _phantomQueues.get(projectKey);
  if (!phantom || phantom.queue.length === 0) return;
  relayLog("info", `Flushing ${phantom.queue.length} queued commands for project=${projectKey}`);
  for (const item of phantom.queue) {
    try { client.send(item.data); } catch (e) { relayLog("error", `Phantom flush failed: ${e.message}`); }
  }
  phantom.queue = [];
  _phantomQueues.delete(projectKey);
}
setInterval(() => {
  const now = Date.now();
  for (const [k, v] of _phantomQueues) {
    if (now - v.disconnectedAt > PHANTOM_TTL_MS) { _phantomQueues.delete(k); }
  }
}, 30000);

// ── sendGrokOk: ALWAYS return 200 to Grok, never an error status code ──
function sendGrokOk(res, statusWord, message, extra = {}) {
  sendJson(res, { success: true, status: statusWord, message, ...extra });
}

// ── High-throughput: dedup + caching for concurrent Grok requests ────────────
const _dedupInflight = new Map();
const _resultCache = new Map();
const CACHEABLE_TYPES = new Set(["list_windows", "get_window_info", "screenshot_window", "run_command", "run_command_advanced", "bring_window_to_front", "launch_exe", "cdp_snapshot", "cdp_navigate", "cdp_eval", "cdp_tabs", "cdp_click", "cdp_type"]);
const CACHE_TTL_MS = { list_windows: 2000, get_window_info: 2000, screenshot_window: 3000, run_command: 5000, bring_window_to_front: 3000, launch_exe: 10000, cdp_snapshot: 3000, cdp_navigate: 3000, cdp_eval: 2000, cdp_tabs: 2000, cdp_click: 2000, cdp_type: 1000 };
function dedupKey(actions) {
  return actions.map(a => {
    const { type, project, title, pid, cmd, command, path: p, url: u, selector: s, code: c, keys: k, text: t } = a;
    return `${type}|${project || ""}|${title || ""}|${pid || ""}|${cmd || command || ""}|${p || ""}|${u || ""}|${s || ""}|${(c || "").slice(0,80)}|${k || ""}|${(t || "").slice(0,40)}`;
  }).join(";;");
}
function getCached(key) {
  const entry = _resultCache.get(key);
  if (!entry) return null;
  if (Date.now() - entry.ts > entry.ttl) { _resultCache.delete(key); return null; }
  return entry.raw;
}
function setCache(key, raw, ttlMs) {
  _resultCache.set(key, { raw, ts: Date.now(), ttl: ttlMs });
  if (_resultCache.size > 100) {
    const now = Date.now();
    for (const [k, v] of _resultCache) { if (now - v.ts > v.ttl) _resultCache.delete(k); }
  }
}

// ── Rate limiter for browser/app-launching commands ─────────────────────────
const _launchRateLimit = { lastTs: 0, lastCmd: "", cooldownMs: 8000 };
const LAUNCH_PATTERNS = [/^start\s+(chrome|msedge|firefox|iexplore|http|www\.)/i, /^open\s+/i, /^explorer\s+http/i, /^cmd\s+.*start\s+http/i];
function isLaunchCommand(cmd) {
  if (!cmd) return false;
  return LAUNCH_PATTERNS.some(p => p.test(cmd.trim()));
}
function checkLaunchRateLimit(cmd) {
  if (_testMode) return { blocked: false };
  const now = Date.now();
  if (now - _launchRateLimit.lastTs < _launchRateLimit.cooldownMs) {
    return { blocked: true, reason: `Browser already launched ${((now - _launchRateLimit.lastTs) / 1000).toFixed(1)}s ago (cooldown: ${_launchRateLimit.cooldownMs / 1000}s). Previous: "${_launchRateLimit.lastCmd.substring(0, 80)}". Wait or use grok-bring-to-front instead.` };
  }
  _launchRateLimit.lastTs = now;
  _launchRateLimit.lastCmd = cmd;
  return { blocked: false };
}

// ── Grok guardrails: validate params, rate-limit per-type, detect nav loops, global throttle ──
const _grokTypeRate = new Map();
const GROK_TYPE_COOLDOWNS = {
  launch_exe: 8000, cdp_navigate: 2000, screenshot_window: 2000,
  cdp_snapshot: 1500, list_windows: 2000, cdp_tabs: 2000
};
// ── Click dedup: prevent Grok from clicking the same element repeatedly (play/pause toggle spam) ──
const _clickHistory = new Map(); // "selector" → { ts, count }
const CLICK_DEDUP_WINDOW_MS = 30000; // 30s window per unique selector
function checkClickDedup(step) {
  if (_testMode) return { blocked: false };
  if (step.type !== "cdp_click" && step.type !== "click_at") return { blocked: false };
  const key = step.type === "cdp_click" ? `click:${step.selector}` : `click_at:${step.x},${step.y}`;
  const now = Date.now();
  const prev = _clickHistory.get(key);
  if (prev && (now - prev.ts) < CLICK_DEDUP_WINDOW_MS) {
    prev.count++;
    return { blocked: true, reason: `Already clicked "${step.selector || `${step.x},${step.y}`}" ${prev.count} times in the last ${Math.round((now - prev.ts)/1000)}s. First click was successful — do not click again (toggling play/pause).` };
  }
  _clickHistory.set(key, { ts: now, count: 1 });
  // Prune old entries
  if (_clickHistory.size > 50) {
    for (const [k, v] of _clickHistory) { if (now - v.ts > CLICK_DEDUP_WINDOW_MS) _clickHistory.delete(k); }
  }
  return { blocked: false };
}
const _grokNavHistory = [];
const GROK_NAV_LOOP_WINDOW = 60000;
const _grokGlobalCalls = [];
const GROK_GLOBAL_MAX_PER_MIN = 60;

function grokValidateStep(step) {
  const t = step.type;
  if (t === "launch_exe" && !step.path) return { rejected: true, reason: "launch_exe requires a 'path' parameter (e.g. path=notepad.exe). You sent an empty call." };
  if (t === "run_command" && !step.command && !step.cmd) return { rejected: true, reason: "run_command requires a 'command' parameter (e.g. command=dir). You sent an empty call." };
  if (t === "cdp_navigate" && !step.url) return { rejected: true, reason: "cdp_navigate requires a 'url' parameter (e.g. url=https://example.com). You sent an empty call." };
  if (t === "cdp_click" && !step.selector) return { rejected: true, reason: "cdp_click requires a 'selector' parameter. Use snapshot first to discover selectors." };
  if (t === "cdp_type" && !step.selector) return { rejected: true, reason: "cdp_type requires a 'selector' parameter. Use snapshot first to discover selectors." };
  if (t === "cdp_eval" && !step.code) return { rejected: true, reason: "cdp_eval requires a 'code' parameter with JavaScript to evaluate." };
  if (t === "screenshot_window" && !step.title) return { rejected: true, reason: "screenshot_window requires a 'title' parameter (partial window title to match)." };
  if (t === "bring_window_to_front" && !step.title) return { rejected: true, reason: "bring_window_to_front requires a 'title' parameter (partial window title)." };
  if (t === "paste_text" && !step.text) return { rejected: true, reason: "paste_text requires a 'text' parameter." };
  if (t === "send_keys" && !step.keys) return { rejected: true, reason: "send_keys requires a 'keys' parameter (e.g. keys={ENTER})." };
  if (t === "read_file" && (!step.path || step.path === "FILE")) return { rejected: true, reason: "read_file requires a real file path, not the placeholder 'FILE'." };
  if (t === "search_replace" && (!step.path || step.path === "FILE")) return { rejected: true, reason: "search_replace requires a real file path, not the placeholder 'FILE'." };
  return { rejected: false };
}

function grokCheckTypeRate(step) {
  if (_testMode) return { blocked: false };
  const t = step.type;
  const cooldown = GROK_TYPE_COOLDOWNS[t];
  if (!cooldown) return { blocked: false };
  const key = `${t}|${step.path || step.url || step.selector || step.title || step.command || ""}`;
  const now = Date.now();
  const last = _grokTypeRate.get(key);
  if (last && now - last < cooldown) {
    return { blocked: true, reason: `${t} with same parameters was called ${((now - last) / 1000).toFixed(1)}s ago (cooldown: ${cooldown / 1000}s). Wait for the cooldown or try a different action. Do NOT repeat the same call.` };
  }
  _grokTypeRate.set(key, now);
  if (_grokTypeRate.size > 200) {
    for (const [k, v] of _grokTypeRate) { if (now - v > 60000) _grokTypeRate.delete(k); }
  }
  return { blocked: false };
}

function grokCheckNavLoop(step) {
  if (_testMode) return null;
  if (step.type !== "cdp_navigate" || !step.url) return null;
  const now = Date.now();
  _grokNavHistory.push({ url: step.url, ts: now });
  while (_grokNavHistory.length > 0 && now - _grokNavHistory[0].ts > GROK_NAV_LOOP_WINDOW) _grokNavHistory.shift();
  if (_grokNavHistory.length >= 4) {
    const urlCounts = {};
    for (const h of _grokNavHistory) {
      const domain = h.url.replace(/https?:\/\//, "").split("/").slice(0, 2).join("/");
      urlCounts[domain] = (urlCounts[domain] || 0) + 1;
    }
    const uniqueDomains = Object.keys(urlCounts);
    const totalNavs = _grokNavHistory.length;
    if (uniqueDomains.length <= 2 && totalNavs >= 4) {
      const urls = _grokNavHistory.map(h => h.url.slice(0, 80));
      return `NAVIGATION LOOP DETECTED: You have navigated ${totalNavs} times in ${(GROK_NAV_LOOP_WINDOW/1000)}s between the same ${uniqueDomains.length} domain(s). URLs: ${[...new Set(urls)].join(" | ")}. STOP. You are going in circles. Use snapshot to read the CURRENT page, then proceed with your actual task (click download button, etc). Do NOT navigate to another page.`;
    }
    if (totalNavs >= 6) {
      return `TOO MANY NAVIGATIONS: ${totalNavs} navigations in ${(GROK_NAV_LOOP_WINDOW/1000)}s. You are wasting time switching pages. STOP navigating. Use snapshot to read what is on screen NOW, then take the next logical action (click a button, download a file, etc).`;
    }
  }
  return null;
}

function grokCheckGlobalRate() {
  if (_testMode) return { blocked: false };
  const now = Date.now();
  _grokGlobalCalls.push(now);
  while (_grokGlobalCalls.length > 0 && now - _grokGlobalCalls[0] > 60000) _grokGlobalCalls.shift();
  if (_grokGlobalCalls.length > GROK_GLOBAL_MAX_PER_MIN) {
    return { blocked: true, reason: `RATE LIMIT: ${_grokGlobalCalls.length} API calls in the last 60 seconds (max ${GROK_GLOBAL_MAX_PER_MIN}). You are making too many individual calls. SLOW DOWN. Use /api/grok-do?chain= to batch multiple steps into ONE call. Example: ?chain=nav:URL|wait:5000|snapshot|click:SELECTOR instead of 4 separate calls.` };
  }
  return { blocked: false };
}

// ── Task macros: pre-built workflows that execute common multi-step tasks ──
function buildTaskMacro(taskName, params) {
  const q = params.query || params.q || "";
  const modelUrl = params.url || params.model_url || "";
  const filePath = params.file || params.path || "";

  const SF_API_BASE = "https://api.sketchfab.com/v3";
  const SF_TOKEN = process.env.sketchfabapi || process.env.SKETCHFAB_API_TOKEN || process.env.SKETCHFAB_API_KEY || "";
  const SF_DL_DIR = "C:\\Users\\Aiden\\Downloads";

  function _sfExtractUid(urlOrUid) {
    if (!urlOrUid) return "";
    const m = urlOrUid.match(/([a-f0-9]{32})/);
    return m ? m[1] : urlOrUid;
  }

  switch (taskName) {
    case "sketchfab-search": {
      if (!q) return { error: "task=sketchfab-search requires query parameter (e.g. &query=low+poly+fox)" };
      return { _serverSideAsync: true, description: `Search Sketchfab for "${q}"`, run: async () => {
        const searchRes = await fetch(`${SF_API_BASE}/search?type=models&q=${encodeURIComponent(q)}&downloadable=true&count=10`, { headers: { Authorization: `Token ${SF_TOKEN}` } });
        if (!searchRes.ok) return { error: `Sketchfab API error: ${searchRes.status}` };
        const data = await searchRes.json();
        const models = (data.results || []).map(m => ({ name: m.name, uid: m.uid, faces: m.faceCount, downloadable: m.isDownloadable, thumbnail: m.thumbnails?.images?.[0]?.url || "" }));
        return { success: true, count: models.length, models };
      }};
    }
    case "sketchfab-download": {
      if (!modelUrl && !q) return { error: "task=sketchfab-download requires url (model URL or UID) or query (search term)" };
      if (!SF_TOKEN) return { error: "Sketchfab API key not configured" };
      return { _serverSideAsync: true, description: `Download Sketchfab model to Downloads`, run: async (bridgeExec) => {
        let uid, modelName;
        if (modelUrl) {
          uid = _sfExtractUid(modelUrl);
          modelName = uid;
        } else {
          const searchRes = await fetch(`${SF_API_BASE}/search?type=models&q=${encodeURIComponent(q)}&downloadable=true&count=1`, { headers: { Authorization: `Token ${SF_TOKEN}` } });
          const searchData = await searchRes.json();
          if (!searchData.results?.length) return { error: "No downloadable models found" };
          uid = searchData.results[0].uid;
          modelName = searchData.results[0].name;
        }
        const dlRes = await fetch(`${SF_API_BASE}/models/${uid}/download`, { headers: { Authorization: `Token ${SF_TOKEN}` } });
        if (!dlRes.ok) return { error: `Sketchfab download API error: ${dlRes.status}` };
        const dlData = await dlRes.json();
        const glbUrl = dlData.glb?.url || dlData.gltf?.url;
        if (!glbUrl) return { error: "No GLB/GLTF download available for this model" };
        const safeName = (modelName || uid).replace(/[^a-zA-Z0-9_-]/g, "_").slice(0, 40);
        const destPath = `${SF_DL_DIR}\\${safeName}.glb`;
        const dlCmd = `powershell -NoProfile -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri '${glbUrl.replace(/'/g, "''")}' -OutFile '${destPath}' -UseBasicParsing; if (Test-Path '${destPath}') { Write-Output ('DOWNLOADED: ${destPath} (' + (Get-Item '${destPath}').Length + ' bytes)') } else { Write-Output 'DOWNLOAD_FAILED' }"`;
        const result = await bridgeExec([{ type: "run_command", command: dlCmd, project: "__system__" }]);
        return { success: true, model: modelName, uid, file: destPath, bridgeResult: result };
      }};
    }
    case "open-in-blender": {
      if (!filePath) return { error: "task=open-in-blender requires file parameter (path to .blend/.glb/.fbx/.obj file)" };
      const blenderPath = "C:\\Program Files\\Blender Foundation\\Blender 5.1\\blender.exe";
      const ext = filePath.split(".").pop().toLowerCase();
      if (ext === "blend") {
        return { steps: [
          { type: "run_command", command: `powershell -NoProfile -Command "Start-Process -FilePath '${blenderPath}' -ArgumentList '${filePath}'; Write-Output 'Blender launched'"`, project: "__system__" }
        ], description: `Open "${filePath}" in Blender` };
      }
      const escapedPath = filePath.replace(/\\/g, "/");
      return { _serverSideAsync: true, description: `Import "${filePath}" into Blender`, run: async (bridgeExec) => {
        const pyContent = [
          "import bpy", "import sys", "",
          "for obj in list(bpy.data.objects):", "    bpy.data.objects.remove(obj, do_unlink=True)", "",
          "for col in list(bpy.data.collections):", "    bpy.data.collections.remove(col)", "",
          "for mesh in list(bpy.data.meshes):", "    bpy.data.meshes.remove(mesh)", "",
          `filepath = "${escapedPath}"`,
          'print("Importing: " + filepath)', "",
          "try:", "    bpy.ops.import_scene.gltf(filepath=filepath)", '    print("Import OK")',
          "except Exception as e:", '    print("Import error: " + str(e))', "    sys.exit(1)", "",
          "for area in bpy.context.screen.areas:",
          '    if area.type == "VIEW_3D":',
          "        for region in area.regions:",
          '            if region.type == "WINDOW":',
          "                with bpy.context.temp_override(area=area, region=region):",
          "                    bpy.ops.view3d.view_all(center=True)",
          "                break", "",
          'print("Done - model loaded")',
        ].join("\n");
        const pyB64 = Buffer.from(pyContent).toString("base64");
        const pyDest = "C:\\Users\\Aiden\\Desktop\\blender_import.py";
        const writePs = `[System.IO.File]::WriteAllText("${pyDest}", [System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String("${pyB64}"))); Write-Output "Script written"`;
        const writeB64 = Buffer.from(writePs, "utf16le").toString("base64");
        const r1 = await bridgeExec([{ type: "run_command", command: `powershell -NoProfile -EncodedCommand ${writeB64}`, project: "__system__" }]);
        await new Promise(r => setTimeout(r, 3500));
        const r2 = await bridgeExec([{ type: "run_command", command: `powershell -NoProfile -Command "Start-Process -FilePath '${blenderPath}' -ArgumentList '--python','${pyDest}'; Write-Output 'Blender launched'"`, project: "__system__" }]);
        return { success: true, file: filePath, scriptWritten: pyDest, blenderLaunched: true, results: [r1, r2] };
      }};
    }
    case "sketchfab-to-blender": {
      if (!q && !modelUrl) return { error: "task=sketchfab-to-blender requires either query (search term) or url (model page URL)" };
      if (!SF_TOKEN) return { error: "Sketchfab API key not configured" };
      return { _serverSideAsync: true, description: "Sketchfab → download → Blender" + (q ? ` (search: ${q})` : ` (model: ${modelUrl})`), run: async (bridgeExec) => {
        let uid, modelName;
        if (modelUrl) {
          uid = _sfExtractUid(modelUrl);
          modelName = uid;
        } else {
          const searchRes = await fetch(`${SF_API_BASE}/search?type=models&q=${encodeURIComponent(q)}&downloadable=true&count=1`, { headers: { Authorization: `Token ${SF_TOKEN}` } });
          const searchData = await searchRes.json();
          if (!searchData.results?.length) return { error: "No downloadable models found for query: " + q };
          uid = searchData.results[0].uid;
          modelName = searchData.results[0].name;
        }
        const dlRes = await fetch(`${SF_API_BASE}/models/${uid}/download`, { headers: { Authorization: `Token ${SF_TOKEN}` } });
        if (!dlRes.ok) return { error: `Sketchfab download API error: ${dlRes.status}` };
        const dlData = await dlRes.json();
        const glbUrl = dlData.glb?.url || dlData.gltf?.url;
        if (!glbUrl) return { error: "No GLB/GLTF download available for this model" };
        const safeName = (modelName || uid).replace(/[^a-zA-Z0-9_-]/g, "_").slice(0, 40);
        const destPath = `${SF_DL_DIR}\\${safeName}.glb`;
        const destPathFwd = `C:/Users/Aiden/Downloads/${safeName}.glb`;
        const dlCmd = `powershell -NoProfile -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri '${glbUrl.replace(/'/g, "''")}' -OutFile '${destPath}' -UseBasicParsing; if (Test-Path '${destPath}') { Write-Output ('DOWNLOADED: ${destPath} (' + (Get-Item '${destPath}').Length + ' bytes)') } else { Write-Output 'DOWNLOAD_FAILED' }"`;
        const r1 = await bridgeExec([{ type: "run_command", command: dlCmd, project: "__system__" }]);
        const pyContent = [
          "import bpy", "import sys", "",
          "for obj in list(bpy.data.objects):", "    bpy.data.objects.remove(obj, do_unlink=True)", "",
          "for col in list(bpy.data.collections):", "    bpy.data.collections.remove(col)", "",
          "for mesh in list(bpy.data.meshes):", "    bpy.data.meshes.remove(mesh)", "",
          `filepath = "${destPathFwd}"`,
          'print("Importing: " + filepath)', "",
          "try:", "    bpy.ops.import_scene.gltf(filepath=filepath)", '    print("Import OK")',
          "except Exception as e:", '    print("Import error: " + str(e))', "    sys.exit(1)", "",
          "for area in bpy.context.screen.areas:",
          '    if area.type == "VIEW_3D":',
          "        for region in area.regions:",
          '            if region.type == "WINDOW":',
          "                with bpy.context.temp_override(area=area, region=region):",
          "                    bpy.ops.view3d.view_all(center=True)",
          "                break", "",
          'print("Done - model loaded")',
        ].join("\n");
        const pyB64 = Buffer.from(pyContent).toString("base64");
        const pyDest = "C:\\Users\\Aiden\\Desktop\\blender_import.py";
        const writePs = `[System.IO.File]::WriteAllText("${pyDest}", [System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String("${pyB64}"))); Write-Output "Script written"`;
        const writeB64 = Buffer.from(writePs, "utf16le").toString("base64");
        await new Promise(r => setTimeout(r, 3500));
        const r2 = await bridgeExec([{ type: "run_command", command: `powershell -NoProfile -EncodedCommand ${writeB64}`, project: "__system__" }]);
        const blenderExe = "C:\\Program Files\\Blender Foundation\\Blender 5.1\\blender.exe";
        await new Promise(r => setTimeout(r, 3500));
        const r3 = await bridgeExec([{ type: "run_command", command: `powershell -NoProfile -Command "Start-Process -FilePath '${blenderExe}' -ArgumentList '--python','${pyDest}'; Write-Output 'Blender launched'"`, project: "__system__" }]);
        return { success: true, model: modelName, uid, file: destPath, blenderLaunched: true, results: [r1, r2, r3] };
      }};
    }
    case "download-file": {
      const downloadUrl = params.url || "";
      const dest = params.dest || params.destination || `C:\\Users\\Aiden\\Desktop\\download_${Date.now()}`;
      if (!downloadUrl) return { error: "task=download-file requires url parameter" };
      const ext = downloadUrl.split(".").pop().split("?")[0].slice(0, 10);
      const destFile = dest.includes(".") ? dest : `${dest}.${ext || "bin"}`;
      return { steps: [
        { type: "run_command", command: `curl -L -o "${destFile}" "${downloadUrl}"`, project: "__system__" },
        { type: "wait", ms: 10000 },
        { type: "run_command", command: `dir "${destFile}"`, project: "__system__" }
      ], description: `Download ${downloadUrl} to ${destFile}` };
    }
    case "web-search": {
      if (!q) return { error: "task=web-search requires query parameter" };
      return { steps: [
        { type: "run_command", command: `start chrome "https://www.google.com/search?q=${encodeURIComponent(q)}"`, project: "__system__" },
        { type: "wait", ms: 6000 },
        { type: "cdp_snapshot", project: "__system__" }
      ], description: `Google search for "${q}" and return results` };
    }
    case "google-home":
    case "lights": {
      const GHOME_URL = "https://home.google.com/u/0/home/1-a180dbc5e1b48c92235ebf4df1255bb394d9110eeaa65b9a0ba240";
      const ROOM_MAP = {
        "back door": 2, "back_door": 2, "backdoor": 2,
        "bedroom 2": 3, "bedroom2": 3,
        "bedroom 3": 4, "bedroom3": 4,
        "dining room": 5, "dining": 5, "diningroom": 5,
        "garden level": 6, "garden": 6, "dimmer": 6,
        "sink light": 7, "sink": 7, "kitchen light": 7,
        "living room": 8, "living": 8, "livingroom": 8,
        "master bedroom": 9, "master": 9, "masterbedroom": 9,
        "bathroom fan": 10, "fan": 10, "bath fan": 10,
        "bathroom light": 11, "bathroom": 11, "bath light": 11,
      };
      const action = (params.action || params.state || params.mode || "toggle").toLowerCase();
      const rooms = (params.rooms || params.room || params.devices || params.device || "").toLowerCase();

      const jsClickTile = (indices, desiredAction) => {
        const titleFilter = desiredAction === "on" ? "Turn on" : desiredAction === "off" ? "Turn off" : null;
        if (indices === "all" && titleFilter) {
          return `(function(){var tiles=document.querySelectorAll('button.mat-mdc-tooltip-trigger');var r=[];for(var i=0;i<tiles.length;i++){var t=tiles[i];if(t.title==='${titleFilter}'){t.dispatchEvent(new PointerEvent('pointerdown',{bubbles:true}));t.dispatchEvent(new PointerEvent('pointerup',{bubbles:true}));t.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true}));r.push(i+':'+t.textContent.replace(/\\s+/g,' ').trim().substring(0,30))}}return r.length?'Toggled: '+r.join(', '):'No devices needed toggling — all already ${desiredAction}'})()`; 
        }
        if (indices === "all") {
          return `(function(){var tiles=document.querySelectorAll('button.mat-mdc-tooltip-trigger');var r=[];for(var i=2;i<tiles.length;i++){var t=tiles[i];t.dispatchEvent(new PointerEvent('pointerdown',{bubbles:true}));t.dispatchEvent(new PointerEvent('pointerup',{bubbles:true}));t.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true}));r.push(i+':'+t.title)}return'Toggled: '+r.join(', ')})()`;
        }
        const idxArr = Array.isArray(indices) ? indices : [indices];
        const idxStr = JSON.stringify(idxArr);
        if (titleFilter) {
          return `(function(){var tiles=document.querySelectorAll('button.mat-mdc-tooltip-trigger');var idx=${idxStr};var r=[];idx.forEach(function(i){var t=tiles[i];if(t&&t.title==='${titleFilter}'){t.dispatchEvent(new PointerEvent('pointerdown',{bubbles:true}));t.dispatchEvent(new PointerEvent('pointerup',{bubbles:true}));t.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true}));r.push(i+':'+t.textContent.replace(/\\s+/g,' ').trim().substring(0,30))}else if(t){r.push(i+':already_'+('${desiredAction}'==='on'?'on':'off'))}});return r.length?r.join(', '):'no tiles found'})()`;
        }
        return `(function(){var tiles=document.querySelectorAll('button.mat-mdc-tooltip-trigger');var idx=${idxStr};var r=[];idx.forEach(function(i){var t=tiles[i];if(t){t.dispatchEvent(new PointerEvent('pointerdown',{bubbles:true}));t.dispatchEvent(new PointerEvent('pointerup',{bubbles:true}));t.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true}));r.push(i+':'+t.title)}});return'Toggled: '+r.join(', ')})()`;
      };

      const jsStatus = `Array.from(document.querySelectorAll('button.mat-mdc-tooltip-trigger')).map(function(b,i){return i+':'+b.textContent.replace(/\\s+/g,' ').trim().substring(0,40)}).join('|')`;

      if (action === "status" || action === "list" || action === "check") {
        return { _serverSideAsync: true, description: "Check Google Home device states", run: async (bridgeExec) => {
          const navR = await bridgeExec([{ type: "cdp_eval", code: `(function(){if(!location.href.includes('home.google.com')){location.href='${GHOME_URL}';return 'navigating'}return 'already on google home'})()`, project: "__system__" }]);
          if (navR?.results?.[0]?.data?.value === "navigating") await new Promise(r => setTimeout(r, 7000));
          const r = await bridgeExec([{ type: "cdp_eval", code: jsStatus, project: "__system__" }]);
          const raw = r?.results?.[0]?.data?.value || r?.results?.[0]?.data?.result || "";
          const devices = raw.split("|").slice(2).map(d => {
            const [idx, ...rest] = d.split(":");
            const txt = rest.join(":").trim();
            const on = txt.includes("On");
            const name = txt.replace(/^(switch|lightbulb|mode_fan)/, "").replace(/(On|Off).*$/, "").trim();
            return { index: parseInt(idx), name, on };
          });
          return { success: true, devices, summary: devices.map(d => `${d.name}: ${d.on?"ON":"OFF"}`).join(", ") };
        }};
      }

      let targetIndices;
      if (!rooms || rooms === "all" || rooms === "everything" || rooms === "house") {
        targetIndices = "all";
      } else {
        const roomNames = rooms.split(/[,;+&]/).map(r => r.trim()).filter(Boolean);
        targetIndices = [];
        const notFound = [];
        for (const rn of roomNames) {
          const idx = ROOM_MAP[rn];
          if (idx !== undefined) targetIndices.push(idx);
          else {
            const fuzzy = Object.keys(ROOM_MAP).find(k => k.includes(rn) || rn.includes(k));
            if (fuzzy) targetIndices.push(ROOM_MAP[fuzzy]);
            else notFound.push(rn);
          }
        }
        if (targetIndices.length === 0 && notFound.length > 0) {
          return { error: `No matching rooms: ${notFound.join(", ")}. Available: ${Object.keys(ROOM_MAP).filter(k => !k.includes("_") && k.length > 3).join(", ")}` };
        }
      }

      const desc = `Google Home: ${action} ${targetIndices === "all" ? "all devices" : rooms}`;
      return { _serverSideAsync: true, description: desc, run: async (bridgeExec) => {
        const navR = await bridgeExec([{ type: "cdp_eval", code: `(function(){if(!location.href.includes('home.google.com')){location.href='${GHOME_URL}';return 'navigating'}return 'ready'})()`, project: "__system__" }]);
        if (navR?.results?.[0]?.data?.value === "navigating") await new Promise(r => setTimeout(r, 7000));
        const clickJs = jsClickTile(targetIndices, action);
        const r = await bridgeExec([{ type: "cdp_eval", code: clickJs, project: "__system__" }]);
        const result = r?.results?.[0]?.data?.value || r?.results?.[0]?.data?.result || "";
        await new Promise(r2 => setTimeout(r2, 2000));
        const stR = await bridgeExec([{ type: "cdp_eval", code: jsStatus, project: "__system__" }]);
        const stRaw = stR?.results?.[0]?.data?.value || stR?.results?.[0]?.data?.result || "";
        const devices = stRaw.split("|").slice(2).map(d => {
          const [idx, ...rest] = d.split(":");
          const txt = rest.join(":").trim();
          const on = txt.includes("On");
          const name = txt.replace(/^(switch|lightbulb|mode_fan)/, "").replace(/(On|Off).*$/, "").trim();
          return { index: parseInt(idx), name, on };
        });
        return { success: true, action, result, devices: devices.map(d => `${d.name}: ${d.on?"ON":"OFF"}`).join(", ") };
      }};
    }
    case "website-test": {
      const testUrl = params.url || "";
      const defaultSites = [
        "https://www.canva.com/",
        "https://www.figma.com/",
        "https://www.photopea.com/",
        "https://excalidraw.com/",
        "https://docs.google.com/document/u/0/",
        "https://docs.google.com/spreadsheets/u/0/",
        "https://www.notion.so/",
        "https://trello.com/",
        "https://codepen.io/",
        "https://soundcloud.com/",
        "https://studio.youtube.com/",
        "https://github.com/",
        "https://discord.com/channels/@me",
        "https://web.telegram.org/"
      ];
      const urls = testUrl ? [testUrl] : defaultSites;
      return { _serverSideAsync: true, description: `Website navigation test: ${urls.length} site(s)`, run: async (bridgeExec) => {
        const results = [];
        for (const siteUrl of urls) {
          try {
            const navR = await bridgeExec([{ type: "run_command", command: `start chrome "${siteUrl}"`, project: "__system__" }]);
            await new Promise(r => setTimeout(r, 8000));
            const snapR = await bridgeExec([{ type: "cdp_snapshot", project: "__system__" }]);
            const snap = snapR?.results?.[0]?.data || snapR?.data || snapR;
            results.push({ url: siteUrl, success: true, snapshot: snap });
          } catch (e) {
            results.push({ url: siteUrl, success: false, error: e.message });
          }
        }
        return { success: true, sitesTotal: urls.length, sitesTested: results.length, results };
      }};
    }
    case "app-test": {
      const appName = (params.app || params.name || "notepad").toLowerCase();
      const APP_RECIPES = {
        notepad: { path: "notepad.exe", type: "gui-simple", control: "SendKeys + paste_text", test: "launch → type → save → verify file" },
        calculator: { path: "calc.exe", type: "gui-simple", control: "click_at + screenshot", test: "launch → click buttons → read result" },
        paint: { path: "mspaint.exe", type: "gui-creative", control: "click_at + keys", test: "launch → select tool → draw" },
        explorer: { path: "explorer.exe", type: "gui-complex", control: "keys + click_at", test: "launch → navigate folders → create files" },
        settings: { path: "ms-settings:", type: "gui-complex", control: "click_at + keys", test: "launch → navigate panels → toggle" },
        taskmgr: { path: "taskmgr.exe", type: "gui-complex", control: "screenshot + read", test: "launch → read processes → identify resource usage" },
        vscode: { path: "code", type: "ide", control: "CLI + terminal + file system", test: "launch → open file → edit → save" },
        blender: { path: "C:\\Program Files\\Blender Foundation\\Blender 5.1\\blender.exe", type: "creative-scripted", control: "Python bpy scripts via --python", test: "launch → run script → verify scene" },
        obs: { path: "obs64.exe", type: "media", control: "hotkeys + CLI (--startrecording, --stoprecording)", test: "launch → configure → start/stop recording" },
        discord: { path: "Discord.exe", type: "electron-app", control: "CDP (debug port) or hotkeys", test: "launch → navigate servers → send message" },
        spotify: { path: "Spotify.exe", type: "media", control: "media keys (play/pause/next/prev)", test: "launch → play → skip → pause" },
        chrome: { path: "chrome.exe", type: "browser", control: "CDP (selectors, eval, navigate)", test: "launch → navigate → snapshot → interact" }
      };
      const recipe = APP_RECIPES[appName];
      if (!recipe) {
        return { success: true, availableApps: Object.keys(APP_RECIPES), message: `Unknown app "${appName}". Pick from the list or use app-control to launch any app by path.` };
      }
      return { _serverSideAsync: true, description: `App control test: ${appName}`, run: async (bridgeExec) => {
        const launchResult = await bridgeExec([{ type: "launch_exe", path: recipe.path, project: "__system__" }]);
        await new Promise(r => setTimeout(r, 5000));
        const screenshotResult = await bridgeExec([{ type: "screenshot_window", title: appName, project: "__system__" }]);
        return {
          success: true, app: appName, recipe,
          launched: launchResult,
          screenshot: screenshotResult?.results?.[0]?.data ? "captured" : "failed",
          _screenshotData: screenshotResult?.results?.[0]?.data?.image ? true : false,
          nextSteps: `App launched. Use the "${recipe.control}" method to interact. Test workflow: ${recipe.test}`
        };
      }};
    }
    case "app-control": {
      const appName = (params.app || params.name || "").toLowerCase();
      const appPath = params.path || "";
      if (!appName && !appPath) return { error: "task=app-control requires app (name) or path (exe path)" };
      return { _serverSideAsync: true, description: `Smart app launch: ${appName || appPath}`, run: async (bridgeExec) => {
        const KNOWN_BROWSER_APPS = ["chrome", "edge", "firefox", "brave", "discord", "slack", "teams", "vscode", "code"];
        const KNOWN_SCRIPTED = { blender: "Python bpy", obs: "CLI flags", vscode: "CLI + terminal" };
        const launchPath = appPath || appName;
        const r = await bridgeExec([{ type: "launch_exe", path: launchPath, project: "__system__" }]);
        await new Promise(r2 => setTimeout(r2, 5000));
        const isBrowser = KNOWN_BROWSER_APPS.some(b => (appName || appPath).toLowerCase().includes(b));
        const scriptApi = Object.entries(KNOWN_SCRIPTED).find(([k]) => (appName || appPath).toLowerCase().includes(k));
        let controlInterface = "screenshot + click_at + send_keys (native GUI)";
        let nextAction = "Use screenshot_window to see the app, then click_at/send_keys to interact";
        if (isBrowser) {
          controlInterface = "CDP (selectors, snapshot, click, type, eval)";
          nextAction = "Use cdp_snapshot to get element map, then cdp_click/cdp_type to interact";
          try {
            await new Promise(r2 => setTimeout(r2, 3000));
            const snapR = await bridgeExec([{ type: "cdp_snapshot", project: "__system__" }]);
            return { success: true, app: appName || appPath, controlInterface, launched: r, snapshot: snapR?.results?.[0]?.data || snapR };
          } catch (_) {}
        }
        if (scriptApi) {
          controlInterface = `Scripting API: ${scriptApi[1]}`;
          nextAction = `Use run_command to send ${scriptApi[1]} commands`;
        }
        const screenshotR = await bridgeExec([{ type: "screenshot_window", title: appName || appPath.split("\\").pop().replace(".exe", ""), project: "__system__" }]);
        return { success: true, app: appName || appPath, controlInterface, nextAction, launched: r, screenshotCaptured: !!screenshotR?.results?.[0]?.data?.image };
      }};
    }
    case "comms-test": {
      const platform = (params.platform || params.app || "telegram").toLowerCase();
      const COMMS_URLS = {
        telegram: "https://web.telegram.org/",
        discord: "https://discord.com/channels/@me",
        gmail: "https://mail.google.com/",
        whatsapp: "https://web.whatsapp.com/",
        slack: "https://app.slack.com/"
      };
      const commsUrl = COMMS_URLS[platform] || params.url;
      if (!commsUrl) return { error: `Unknown platform "${platform}". Available: ${Object.keys(COMMS_URLS).join(", ")}` };
      return { _serverSideAsync: true, description: `Communication test: ${platform}`, run: async (bridgeExec) => {
        await bridgeExec([{ type: "run_command", command: `start chrome "${commsUrl}"`, project: "__system__" }]);
        await new Promise(r => setTimeout(r, 10000));
        const snapR = await bridgeExec([{ type: "cdp_snapshot", project: "__system__" }]);
        const snap = snapR?.results?.[0]?.data || snapR?.data || snapR;
        return {
          success: true, platform, url: commsUrl,
          snapshot: snap,
          instructions: `Element map returned. Read the map to identify chat list, message input, send button, etc. Use cdp_click to select a chat, cdp_type to compose, cdp_click to send.`
        };
      }};
    }
    case "blender-scene": {
      const action = params.action || "full";
      const blenderExe = "C:\\Program Files\\Blender Foundation\\Blender 5.1\\blender.exe";
      const scriptDir = "C:\\Users\\Aiden\\Desktop";
      const BPY_SNIPPETS = {
        clear_scene: `import bpy\nfor obj in list(bpy.data.objects):\n    bpy.data.objects.remove(obj, do_unlink=True)\nfor col in list(bpy.data.collections):\n    bpy.data.collections.remove(col)\nfor mesh in list(bpy.data.meshes):\n    bpy.data.meshes.remove(mesh)\nprint("Scene cleared")`,
        import_glb: (filepath) => `import bpy\nbpy.ops.import_scene.gltf(filepath="${filepath.replace(/\\/g, "/")}")\nprint("Imported: ${filepath}")`,
        set_transform: (name, loc, rot, scale) => `import bpy\nobj = bpy.data.objects.get("${name}")\nif obj:\n    obj.location = (${loc || "0,0,0"})\n    obj.rotation_euler = (${rot || "0,0,0"})\n    obj.scale = (${scale || "1,1,1"})\n    print(f"Transformed {obj.name}")\nelse:\n    print("Object not found: ${name}")`,
        add_sun: (energy, color, rot) => `import bpy\nimport math\nbpy.ops.object.light_add(type='SUN')\nsun = bpy.context.active_object\nsun.name = "KeyLight"\nsun.data.energy = ${energy || 3}\nsun.data.color = (${color || "1, 0.95, 0.9"})\nsun.rotation_euler = (${rot || "math.radians(50), math.radians(0), math.radians(30)"})\nprint("Sun light added")`,
        add_area: (loc, energy, color, size) => `import bpy\nbpy.ops.object.light_add(type='AREA', location=(${loc || "3, -2, 2"}))\nlight = bpy.context.active_object\nlight.name = "FillLight"\nlight.data.energy = ${energy || 100}\nlight.data.color = (${color || "0.8, 0.85, 1.0"})\nlight.data.size = ${size || 2}\nprint("Area light added")`,
        add_point: (loc, energy, color) => `import bpy\nbpy.ops.object.light_add(type='POINT', location=(${loc || "-2, 1, 3"}))\nlight = bpy.context.active_object\nlight.name = "AccentLight"\nlight.data.energy = ${energy || 50}\nlight.data.color = (${color || "1.0, 0.8, 0.6"})\nprint("Point light added")`,
        add_material: (objName, matName, color, roughness, metallic, emission) => `import bpy\nobj = bpy.data.objects.get("${objName}")\nif obj:\n    mat = bpy.data.materials.new("${matName || "Material"}")\n    mat.use_nodes = True\n    bsdf = mat.node_tree.nodes.get("Principled BSDF")\n    if bsdf:\n        bsdf.inputs["Base Color"].default_value = (${color || "0.8, 0.2, 0.2, 1.0"})\n        bsdf.inputs["Roughness"].default_value = ${roughness || 0.5}\n        bsdf.inputs["Metallic"].default_value = ${metallic || 0.0}\n        if ${emission || 0} > 0:\n            bsdf.inputs["Emission Strength"].default_value = ${emission || 0}\n    obj.data.materials.clear()\n    obj.data.materials.append(mat)\n    print(f"Material '{matName || "Material"}' applied to {obj.name}")\nelse:\n    print("Object not found: ${objName}")`,
        setup_camera: (loc, rot, focal) => `import bpy\nif not bpy.data.objects.get("Camera"):\n    bpy.ops.object.camera_add()\ncam = bpy.data.objects["Camera"]\ncam.location = (${loc || "5, -5, 3"})\ncam.rotation_euler = (${rot || "1.1, 0, 0.8"})\ncam.data.lens = ${focal || 50}\nbpy.context.scene.camera = cam\nprint("Camera configured")`,
        render: (output, resx, resy, samples) => `import bpy\nbpy.context.scene.render.resolution_x = ${resx || 1920}\nbpy.context.scene.render.resolution_y = ${resy || 1080}\nbpy.context.scene.render.engine = 'CYCLES'\nbpy.context.scene.cycles.samples = ${samples || 128}\nbpy.context.scene.render.filepath = "${(output || "C:/Users/Aiden/Desktop/render.png").replace(/\\/g, "/")}"\nbpy.ops.render.render(write_still=True)\nprint("Render complete: " + bpy.context.scene.render.filepath)`,
        list_objects: `import bpy\nfor obj in bpy.data.objects:\n    print(f"{obj.name} type={obj.type} loc={tuple(round(c,2) for c in obj.location)}")`,
        frame_all: `import bpy\nfor area in bpy.context.screen.areas:\n    if area.type == "VIEW_3D":\n        for region in area.regions:\n            if region.type == "WINDOW":\n                with bpy.context.temp_override(area=area, region=region):\n                    bpy.ops.view3d.view_all(center=True)\n                break\nprint("View framed")`
      };
      if (action === "snippets" || action === "list") {
        return { success: true, availableSnippets: Object.keys(BPY_SNIPPETS), description: "Use action=run&script=SNIPPET_NAME or action=custom&code=PYTHON_CODE. Snippets accept parameters via query params." };
      }
      if (action === "run") {
        const scriptName = params.script || "";
        if (!scriptName || !BPY_SNIPPETS[scriptName]) {
          return { error: `Unknown snippet "${scriptName}". Available: ${Object.keys(BPY_SNIPPETS).join(", ")}` };
        }
        let pyCode;
        if (typeof BPY_SNIPPETS[scriptName] === "function") {
          const snippetArgs = {
            import_glb: [params.filepath || params.file || ""],
            set_transform: [params.name || params.obj || "", params.loc, params.rot, params.scale],
            add_sun: [params.energy, params.color, params.rot],
            add_area: [params.loc, params.energy, params.color, params.size],
            add_point: [params.loc, params.energy, params.color],
            add_material: [params.obj || params.objName || params.name || "", params.matName || params.mat || "", params.color, params.roughness, params.metallic, params.emission],
            setup_camera: [params.loc, params.rot, params.focal],
            render: [params.output || params.filepath, params.resx, params.resy, params.samples]
          };
          const args = snippetArgs[scriptName] || [];
          pyCode = BPY_SNIPPETS[scriptName](...args);
        } else {
          pyCode = BPY_SNIPPETS[scriptName];
        }
        return { _serverSideAsync: true, description: `Blender: run ${scriptName}`, run: async (bridgeExec) => {
          const pyB64 = Buffer.from(pyCode).toString("base64");
          const pyDest = `${scriptDir}\\blender_${scriptName}.py`;
          const writePs = `[System.IO.File]::WriteAllText("${pyDest}", [System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String("${pyB64}"))); Write-Output "Script written"`;
          const writeB64 = Buffer.from(writePs, "utf16le").toString("base64");
          await bridgeExec([{ type: "run_command", command: `powershell -NoProfile -EncodedCommand ${writeB64}`, project: "__system__" }]);
          await new Promise(r => setTimeout(r, 2000));
          const runResult = await bridgeExec([{ type: "run_command", command: `powershell -NoProfile -Command "Start-Process -FilePath '${blenderExe}' -ArgumentList '--python','${pyDest}'; Write-Output 'Blender script launched'"`, project: "__system__" }]);
          return { success: true, snippet: scriptName, script: pyDest, blenderResult: runResult };
        }};
      }
      if (action === "custom") {
        const customCode = params.code || "";
        if (!customCode) return { error: "action=custom requires code parameter with Python code" };
        return { _serverSideAsync: true, description: "Blender: run custom Python", run: async (bridgeExec) => {
          const pyB64 = Buffer.from(customCode).toString("base64");
          const pyDest = `${scriptDir}\\blender_custom.py`;
          const writePs = `[System.IO.File]::WriteAllText("${pyDest}", [System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String("${pyB64}"))); Write-Output "Script written"`;
          const writeB64 = Buffer.from(writePs, "utf16le").toString("base64");
          await bridgeExec([{ type: "run_command", command: `powershell -NoProfile -EncodedCommand ${writeB64}`, project: "__system__" }]);
          await new Promise(r => setTimeout(r, 2000));
          const runResult = await bridgeExec([{ type: "run_command", command: `powershell -NoProfile -Command "Start-Process -FilePath '${blenderExe}' -ArgumentList '--python','${pyDest}'; Write-Output 'Blender script launched'"`, project: "__system__" }]);
          return { success: true, script: pyDest, blenderResult: runResult };
        }};
      }
      return { success: true, description: "Blender scene macros", availableActions: ["snippets", "run", "custom", "full"], snippets: Object.keys(BPY_SNIPPETS), usage: "action=run&script=SNIPPET_NAME or action=custom&code=PYTHON_CODE or action=snippets to list" };
    }
    case "memory": {
      const action = params.action || "list";
      if (action === "list") {
        const entries = Object.values(_actionMemory).sort((a, b) => (b.successCount || 0) - (a.successCount || 0));
        return { success: true, action: "list", count: entries.length, entries: entries.slice(0, 20).map(e => ({ key: e.key, task: e.task, steps: e.stepCount, timeMs: e.elapsedMs, successes: e.successCount, savedAt: e.savedAt })) };
      }
      if (action === "search") {
        const q = params.q || params.query || "";
        if (!q) return { error: "task=memory&action=search requires q parameter" };
        const results = memoryRecall(q);
        return { success: true, action: "search", query: q, count: results.length, results: results.map(e => ({ key: e.key, task: e.task, steps: e.stepCount, timeMs: e.elapsedMs, successes: e.successCount, summary: e.resultSummary })) };
      }
      if (action === "clear") {
        const count = Object.keys(_actionMemory).length;
        for (const k of Object.keys(_actionMemory)) delete _actionMemory[k];
        try { if (fs.existsSync(_ACTION_MEMORY_DIR)) { for (const f of fs.readdirSync(_ACTION_MEMORY_DIR)) fs.unlinkSync(path.join(_ACTION_MEMORY_DIR, f)); } } catch (_) {}
        return { success: true, action: "clear", cleared: count };
      }
      return { error: `Unknown memory action "${action}". Use: list, search, clear` };
    }
    case "god-mode-test": {
      const testName = params.test || params.name || "all";
      return { _serverSideAsync: true, description: `God-mode test battery: ${testName}`, run: async (bridgeExec) => {
        _testMode = true;
        const batteryStart = Date.now();
        const results = {};
        const evidence = { screenshots: {}, files: {}, elementMaps: {} };
        const EVIDENCE_DIR = "C:\\Users\\Aiden\\Desktop\\godmode-evidence";

        const logProgress = (test, step) => {
          const elapsed = ((Date.now() - batteryStart) / 1000).toFixed(1);
          const entry = { ts: new Date().toISOString(), note: `[GOD-MODE ${elapsed}s] ${test}: ${step}`, from: "god-mode-test" };
          coordBoard.push(entry);
          if (coordBoard.length > 50) coordBoard.splice(0, coordBoard.length - 50);
        };

        const runTest = async (name, fn) => {
          if (testName !== "all" && testName !== name) return;
          logProgress(name, "STARTING...");
          const t0 = Date.now();
          try {
            const r = await fn();
            results[name] = { pass: true, timeMs: Date.now() - t0, ...r };
            logProgress(name, `PASSED (${((Date.now()-t0)/1000).toFixed(1)}s)`);
          } catch (e) {
            results[name] = { pass: false, timeMs: Date.now() - t0, error: e.message || String(e) };
            logProgress(name, `FAILED: ${(e.message||"").slice(0,100)}`);
          }
        };

        const takeScreenshot = async (label, windowTitle) => {
          try {
            const ss = await bridgeExec([{ type: "screenshot_window", title: windowTitle || "Chrome", project: "__system__" }]);
            const ssData = ss?.results?.[0]?.data || ss;
            const imgB64 = ssData?.image || ssData?.screenshot || "";
            const dataSize = imgB64.length || JSON.stringify(ssData).length;
            const hasImage = imgB64.length > 100;
            const savePath = `${EVIDENCE_DIR}\\${label}.png`;
            let savedToDisk = false;
            let fileSizeBytes = 0;
            if (hasImage) {
              try {
                const CHUNK_SIZE = 50000;
                const tmpB64 = `${EVIDENCE_DIR}\\${label}.b64`;
                const totalChunks = Math.ceil(imgB64.length / CHUNK_SIZE);
                for (let ci = 0; ci < totalChunks; ci++) {
                  const chunk = imgB64.slice(ci * CHUNK_SIZE, (ci + 1) * CHUNK_SIZE);
                  const verb = ci === 0 ? "Set-Content" : "Add-Content";
                  const psChunk = `${verb} -Path '${tmpB64}' -Value '${chunk}' -NoNewline`;
                  await bridgeExec([{ type: "run_command", command: `powershell -Command "${psChunk}"`, project: "__system__", timeout: 8000 }]);
                }
                const psDecode = `$raw=(Get-Content '${tmpB64}' -Raw); $bytes=[Convert]::FromBase64String($raw); [IO.File]::WriteAllBytes('${savePath}',$bytes); Remove-Item '${tmpB64}' -Force; (Get-Item '${savePath}').Length`;
                const decR = await bridgeExec([{ type: "run_command", command: `powershell -Command "${psDecode}"`, project: "__system__", timeout: 15000 }]);
                const decOut = JSON.stringify(decR);
                const sizeMatch = decOut.match(/(\d{3,})/);
                fileSizeBytes = sizeMatch ? parseInt(sizeMatch[1]) : 0;
                savedToDisk = fileSizeBytes > 100;
              } catch {}
            }
            evidence.screenshots[label] = { taken: true, hasImage, sizeChars: dataSize, savedToDisk, filename: `${label}.png`, path: savePath, fileSizeBytes, fileSizeKB: Math.round(fileSizeBytes / 1024) };
            return ssData;
          } catch { evidence.screenshots[label] = { taken: false, savedToDisk: false }; return null; }
        };

        const getSnapshot = async (launchResult) => {
          const data = launchResult?.results?.[0]?.data || launchResult;
          if (data?.snapshot) return { snap: data.snapshot, cdpConfirmed: !!data._cdpConfirmed, source: "auto" };
          if (data?._cdpConfirmed) {
            await new Promise(r => setTimeout(r, 3000));
            const s = await bridgeExec([{ type: "cdp_snapshot", project: "__system__" }]);
            return { snap: s?.results?.[0]?.data || s, cdpConfirmed: true, source: "manual" };
          }
          await new Promise(r => setTimeout(r, 8000));
          const s = await bridgeExec([{ type: "cdp_snapshot", project: "__system__" }]);
          return { snap: s?.results?.[0]?.data || s, cdpConfirmed: false, source: "fallback" };
        };

        logProgress("SETUP", "Creating evidence directory...");
        try { await bridgeExec([{ type: "run_command", command: `powershell -Command "New-Item -ItemType Directory -Force -Path '${EVIDENCE_DIR}' | Out-Null; Write-Output 'OK'"`, project: "__system__" }]); } catch {}

        const cdpSnap = async (waitMs) => {
          if (waitMs) await new Promise(r => setTimeout(r, waitMs));
          const s = await bridgeExec([{ type: "cdp_snapshot", project: "__system__" }]);
          const d = s?.results?.[0]?.data || s;
          return { url: d?.url || "", title: d?.title || "", bodyText: (d?.bodyText || "").slice(0, 2000), links: d?.links || [], elementMap: d?.elementMap || "", totalElements: d?.totalElements || 0 };
        };

        await runTest("web-control", async () => {
          logProgress("web-control", "Launching Chrome with CDP via start chrome...");
          const r1 = await bridgeExec([{ type: "run_command", command: "start chrome https://example.com", project: "__system__" }]);
          const launchData = r1?.results?.[0]?.data || r1;
          const cdpConfirmed = !!launchData?._cdpConfirmed;
          logProgress("web-control", `Chrome launched, CDP confirmed=${cdpConfirmed}. Waiting for page load...`);
          await new Promise(r => setTimeout(r, 5000));
          const snap = await cdpSnap();
          const bodyLen = snap.bodyText.length;
          const linkCount = snap.links.length;
          await takeScreenshot("web-control-example-com");
          const bodyPreview = snap.bodyText.slice(0, 800);
          evidence.elementMaps["example.com"] = bodyPreview;
          if (bodyLen < 50 && linkCount === 0) throw new Error("CDP snapshot returned empty page — Chrome may need restart with CDP");
          return { cdpConfirmed, url: snap.url, title: snap.title, bodyTextLength: bodyLen, linkCount, bodyPreview, detail: `Chrome opened example.com via start chrome (CDP ${cdpConfirmed?"confirmed":"connected"}). Page: "${snap.title}", ${bodyLen} chars body text, ${linkCount} links. Body preview: ${bodyPreview.slice(0,200)}...` };
        });

        await runTest("extreme-website-nav", async () => {
          const sites = [
            "https://www.canva.com/", "https://www.figma.com/", "https://www.photopea.com/",
            "https://excalidraw.com/", "https://docs.google.com/document/u/0/",
            "https://docs.google.com/spreadsheets/u/0/", "https://www.notion.so/",
            "https://trello.com/", "https://codepen.io/", "https://soundcloud.com/",
            "https://studio.youtube.com/", "https://github.com/",
            "https://discord.com/channels/@me", "https://web.telegram.org/"
          ];
          const siteResults = [];
          for (let i = 0; i < sites.length; i++) {
            const site = sites[i];
            const hostname = new URL(site).hostname.replace("www.", "");
            logProgress("extreme-website-nav", `Site ${i+1}/${sites.length}: ${hostname}...`);
            try {
              await bridgeExec([{ type: "cdp_navigate", url: site, project: "__system__" }]);
              await new Promise(r => setTimeout(r, 5000));
              const snap = await cdpSnap();
              const bodyLen = snap.bodyText.length;
              const linkCount = snap.links.length;
              const bodyPreview = snap.bodyText.slice(0, 200);
              evidence.elementMaps[hostname] = bodyPreview;
              await takeScreenshot(`extreme-nav-${hostname}`);
              const hasMeaningfulContent = bodyLen > 50 || linkCount > 0;
              siteResults.push({ url: site, hostname, bodyTextLength: bodyLen, linkCount, bodyPreview, success: hasMeaningfulContent });
              logProgress("extreme-website-nav", `${hostname}: ${bodyLen} chars body, ${linkCount} links`);
            } catch (e) {
              siteResults.push({ url: site, hostname, success: false, error: e.message });
              logProgress("extreme-website-nav", `${hostname}: FAILED — ${(e.message||"").slice(0,80)}`);
            }
          }
          const mapped = siteResults.filter(s => s.success).length;
          const failed = siteResults.filter(s => !s.success).length;
          const MIN_REQUIRED = 10;
          if (mapped < MIN_REQUIRED) throw new Error(`Only ${mapped}/${sites.length} sites had meaningful content (minimum ${MIN_REQUIRED} required). Failed: ${siteResults.filter(s => !s.success).map(s => s.hostname).join(", ")}`);
          return { sitesTotal: sites.length, sitesMapped: mapped, sitesFailed: failed, siteResults, detail: `Navigated ${sites.length} sites via cdp_navigate: ${mapped} mapped successfully, ${failed} failed. Minimum ${MIN_REQUIRED} required — PASSED.` };
        });

        await runTest("native-app-control", async () => {
          const appResults = {};
          logProgress("native-app-control", "Launching Notepad...");
          const testFile = "C:\\Users\\Aiden\\Desktop\\godmode-evidence\\notepad_test_" + Date.now() + ".txt";
          const notepadText = "=== GOD MODE TEST ===\nTimestamp: " + new Date().toISOString() + "\nThis file was created by the Lamby god-mode test battery.\nFull autonomous desktop control proven.\nAll systems operational.";
          await bridgeExec([{ type: "launch_exe", path: "notepad.exe", project: "__system__" }]);
          await new Promise(r => setTimeout(r, 3000));
          await bridgeExec([{ type: "paste_text", text: notepadText, send: true, project: "__system__" }]);
          await new Promise(r => setTimeout(r, 1000));
          await takeScreenshot("native-notepad-typed", "Notepad");
          logProgress("native-app-control", "Notepad: typed message, saving...");
          await bridgeExec([{ type: "send_keys", keys: "^s", project: "__system__" }]);
          await new Promise(r => setTimeout(r, 2000));
          await bridgeExec([{ type: "paste_text", text: testFile, send: true, project: "__system__" }]);
          await new Promise(r => setTimeout(r, 500));
          await bridgeExec([{ type: "send_keys", keys: "{ENTER}", project: "__system__" }]);
          await new Promise(r => setTimeout(r, 2000));
          let fileContent = "", fileSaved = false;
          try {
            const verifyR = await bridgeExec([{ type: "run_command", command: `powershell -Command "if(Test-Path '${testFile}'){Get-Content '${testFile}' -Raw}else{Write-Output 'FILE_NOT_FOUND'}"`, project: "__system__" }]);
            fileContent = JSON.stringify(verifyR);
            fileSaved = fileContent.includes("GOD MODE TEST");
          } catch {}
          evidence.files["notepad_test"] = { path: testFile, verified: fileSaved };
          appResults.notepad = { launched: true, textTyped: true, fileSaved, testFile, fileContentVerified: fileSaved, detail: fileSaved ? `Typed → saved → verified on disk at ${testFile}` : "Typed → save attempted (dialog may need interaction)" };

          const verifyWindow = async (appName, titlePattern) => {
            try {
              const wR = await bridgeExec([{ type: "list_windows", project: "__system__" }]);
              const wins = wR?.results?.[0]?.data?.windows || wR?.windows || [];
              const regex = new RegExp(titlePattern, "i");
              const found = wins.find(w => regex.test(w.title || ""));
              return { visible: !!found, title: found?.title || "", windowCount: wins.length };
            } catch { return { visible: false, title: "", windowCount: 0 }; }
          };

          logProgress("native-app-control", "Launching Calculator...");
          await bridgeExec([{ type: "launch_exe", path: "calc.exe", project: "__system__" }]);
          await new Promise(r => setTimeout(r, 3000));
          const calcWin = await verifyWindow("Calculator", "calculator");
          await takeScreenshot("native-calculator", "Calculator");
          appResults.calculator = { launched: true, windowVisible: calcWin.visible, windowTitle: calcWin.title, detail: `Calculator launched${calcWin.visible ? `, window visible: "${calcWin.title}"` : " (window not detected in list)"}` };

          logProgress("native-app-control", "Launching Paint...");
          await bridgeExec([{ type: "launch_exe", path: "mspaint.exe", project: "__system__" }]);
          await new Promise(r => setTimeout(r, 3000));
          const paintWin = await verifyWindow("Paint", "paint|untitled");
          await takeScreenshot("native-paint", "Paint");
          appResults.paint = { launched: true, windowVisible: paintWin.visible, windowTitle: paintWin.title, detail: `Paint launched${paintWin.visible ? `, window visible: "${paintWin.title}"` : " (window not detected in list)"}` };

          logProgress("native-app-control", "Launching File Explorer...");
          await bridgeExec([{ type: "launch_exe", path: "explorer.exe", project: "__system__" }]);
          await new Promise(r => setTimeout(r, 3000));
          const explorerWin = await verifyWindow("Explorer", "explorer|file|this pc|documents|desktop|downloads");
          await takeScreenshot("native-explorer", "Explorer");
          appResults.explorer = { launched: true, windowVisible: explorerWin.visible, windowTitle: explorerWin.title, detail: `Explorer launched${explorerWin.visible ? `, window visible: "${explorerWin.title}"` : " (window not detected in list)"}` };

          logProgress("native-app-control", "Launching Task Manager + capturing process list...");
          await bridgeExec([{ type: "launch_exe", path: "taskmgr.exe", project: "__system__" }]);
          await new Promise(r => setTimeout(r, 3000));
          let processTable = "";
          try {
            const procR = await bridgeExec([{ type: "run_command", command: `powershell -Command "Get-Process | Where-Object {$_.MainWindowTitle -ne ''} | Sort-Object WorkingSet64 -Descending | Select-Object -First 10 ProcessName,@{N='MemMB';E={[math]::Round($_.WorkingSet64/1MB,1)}},MainWindowTitle | Format-Table -AutoSize | Out-String"`, project: "__system__" }]);
            processTable = (procR?.results?.[0]?.data?.output || JSON.stringify(procR)).slice(0, 600);
          } catch {}
          const tmWin = await verifyWindow("TaskManager", "task manager");
          await takeScreenshot("native-taskmgr", "Task Manager");
          if (!processTable) throw new Error("Task Manager launched but process table capture failed — cannot verify process listing");
          appResults.taskManager = { launched: true, windowVisible: tmWin.visible, windowTitle: tmWin.title, processTable, detail: `Task Manager launched${tmWin.visible ? `, window: "${tmWin.title}"` : ""}, process table captured (${processTable.length} chars)` };

          logProgress("native-app-control", "Launching VS Code...");
          try {
            await bridgeExec([{ type: "run_command", command: "code --new-window", project: "__system__" }]);
            await new Promise(r => setTimeout(r, 5000));
            const vsWin = await verifyWindow("VSCode", "visual studio code|vs code|vscode");
            await takeScreenshot("native-vscode", "Visual Studio Code");
            appResults.vscode = { launched: true, windowVisible: vsWin.visible, windowTitle: vsWin.title, detail: `VS Code launched${vsWin.visible ? `, window visible: "${vsWin.title}"` : " (window title not matched)"}` };
          } catch (e) {
            appResults.vscode = { launched: false, error: e.message, detail: "VS Code launch failed (may not be installed)" };
          }

          const appsLaunched = Object.keys(appResults).length;
          const appsOk = Object.values(appResults).filter(a => a.launched).length;
          const appsVerified = Object.values(appResults).filter(a => a.windowVisible).length;
          if (appsOk < 5) throw new Error(`Only ${appsOk}/${appsLaunched} apps launched successfully (minimum 5 required)`);
          return { appsTotal: appsLaunched, appsLaunched: appsOk, appsWindowVerified: appsVerified, appResults, detail: `${appsOk}/${appsLaunched} native apps launched (${appsVerified} window-verified): Notepad (type+save${appResults.notepad.fileSaved?"+verified":""}), Calculator, Paint, Explorer, TaskMgr (process table), VS Code` };
        });

        await runTest("blender-full-scene", async () => {
          logProgress("blender-full-scene", "Searching Sketchfab for downloadable model...");
          const SF_API_BASE = "https://api.sketchfab.com/v3";
          const SF_TOKEN = process.env.sketchfabapi || process.env.SKETCHFAB_API_TOKEN || process.env.SKETCHFAB_API_KEY || "";
          if (!SF_TOKEN) throw new Error("Sketchfab API token not configured — set SKETCHFAB_API_KEY environment secret. Test requires end-to-end Sketchfab→download→import→render proof.");
          let modelName = "", uid = "", glbPath = "", downloadVerified = false;
          const searchRes = await fetch(`${SF_API_BASE}/search?type=models&q=${encodeURIComponent("low poly animal")}&downloadable=true&count=3`, { headers: { Authorization: `Token ${SF_TOKEN}` } });
          if (!searchRes.ok) throw new Error(`Sketchfab search failed (${searchRes.status}): ${await searchRes.text().catch(() => "")}`);
          const searchData = await searchRes.json();
          if (!searchData.results?.length) throw new Error("Sketchfab search returned 0 downloadable models");
          uid = searchData.results[0].uid;
          modelName = searchData.results[0].name;
          logProgress("blender-full-scene", `Found model: "${modelName}" (${uid}), downloading...`);
          const dlRes = await fetch(`${SF_API_BASE}/models/${uid}/download`, { headers: { Authorization: `Token ${SF_TOKEN}` } });
          if (!dlRes.ok) throw new Error(`Sketchfab download API failed (${dlRes.status})`);
          const dlData = await dlRes.json();
          const glbUrl = dlData.glb?.url || dlData.gltf?.url;
          if (!glbUrl) throw new Error("Sketchfab model has no GLB/GLTF download URL");
          const safeName = modelName.replace(/[^a-zA-Z0-9_-]/g, "_").slice(0, 30);
          glbPath = `C:\\Users\\Aiden\\Downloads\\${safeName}.glb`;
          const dlCmd = `powershell -NoProfile -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri '${glbUrl.replace(/'/g, "''")}' -OutFile '${glbPath}' -UseBasicParsing; if(Test-Path '${glbPath}'){(Get-Item '${glbPath}').Length}else{Write-Output '0'}"`;
          const dlR = await bridgeExec([{ type: "run_command", command: dlCmd, project: "__system__", timeout: 60000 }]);
          const dlOut = JSON.stringify(dlR);
          const sizeM = dlOut.match(/(\d{4,})/);
          downloadVerified = sizeM && parseInt(sizeM[1]) > 100;
          if (!downloadVerified) throw new Error(`Sketchfab model download failed — file not found or empty at ${glbPath}`);
          logProgress("blender-full-scene", `Downloaded ${modelName} (${Math.round(parseInt(sizeM[1])/1024)}KB)`);
          evidence.files["sketchfab_model"] = { path: glbPath, sizeBytes: parseInt(sizeM[1]), sizeKB: Math.round(parseInt(sizeM[1]) / 1024) };

          logProgress("blender-full-scene", "Building Blender Python script (scene + 3-point lighting + material + camera + render)...");
          const renderPath = "C:/Users/Aiden/Desktop/godmode-evidence/blender_scene_render.png";
          const importLine = `bpy.ops.import_scene.gltf(filepath="${glbPath.replace(/\\/g, "/")}")\nfor obj in bpy.context.selected_objects:\n    obj.name = "ImportedModel"\nprint("Imported: ${modelName}")`;
          const matTarget = "ImportedModel";
          const script = `import bpy
import math
from mathutils import Vector
for o in list(bpy.data.objects): bpy.data.objects.remove(o,do_unlink=True)
for c in list(bpy.data.collections): bpy.data.collections.remove(c)
for m in list(bpy.data.meshes): bpy.data.meshes.remove(m)
print("Scene cleared")
${importLine}
bpy.ops.object.light_add(type='SUN', location=(3,3,5))
sun = bpy.context.active_object
sun.name = "KeyLight"
sun.data.energy = 3
sun.data.color = (1, 0.95, 0.9)
sun.rotation_euler = (math.radians(50), 0, math.radians(30))
print("Key light (Sun) added")
bpy.ops.object.light_add(type='AREA', location=(3,-2,2))
fill = bpy.context.active_object
fill.name = "FillLight"
fill.data.energy = 100
fill.data.color = (0.8, 0.85, 1.0)
fill.data.size = 2
print("Fill light (Area) added")
bpy.ops.object.light_add(type='POINT', location=(-2,1,3))
accent = bpy.context.active_object
accent.name = "AccentLight"
accent.data.energy = 50
accent.data.color = (1.0, 0.8, 0.6)
print("Accent light (Point) added")
obj = bpy.data.objects.get("${matTarget}")
if obj:
    mat = bpy.data.materials.new("GodModeMaterial")
    mat.use_nodes = True
    bsdf = mat.node_tree.nodes.get("Principled BSDF")
    if bsdf:
        bsdf.inputs["Base Color"].default_value = (0.8, 0.2, 0.1, 1.0)
        bsdf.inputs["Roughness"].default_value = 0.4
        bsdf.inputs["Metallic"].default_value = 0.3
    obj.data.materials.clear()
    obj.data.materials.append(mat)
    print(f"Material applied to {obj.name}")
cam = bpy.data.objects.get("Camera")
if not cam:
    bpy.ops.object.camera_add(location=(4,-4,3))
    cam = bpy.context.active_object
cam.location = (4,-4,3)
dir = Vector((0,0,0))-cam.location
cam.rotation_euler = dir.to_track_quat('-Z','Y').to_euler()
cam.data.lens = 50
bpy.context.scene.camera = cam
print("Camera configured")
bpy.context.scene.render.resolution_x = 640
bpy.context.scene.render.resolution_y = 480
bpy.context.scene.render.image_settings.file_format = 'PNG'
bpy.context.scene.render.filepath = '${renderPath}'
bpy.ops.render.render(write_still=True)
print("Render complete")`;
          const b64 = Buffer.from(script).toString("base64");
          const pyDest = "C:\\Users\\Aiden\\Desktop\\godmode-evidence\\blender_scene.py";
          const psCmd = `$s=[System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String('${b64}'));Set-Content -Path '${pyDest}' -Value $s -Encoding UTF8;Start-Process 'C:\\Program Files\\Blender Foundation\\Blender 5.1\\blender.exe' -ArgumentList '--background','--python','${pyDest}'`;
          logProgress("blender-full-scene", "Launching Blender (background render)...");
          await bridgeExec([{ type: "run_command", command: `powershell -EncodedCommand ${Buffer.from(psCmd, "utf16le").toString("base64")}`, project: "__system__" }]);
          const renderFile = renderPath.replace(/\//g, "\\");
          let renderSize = 0;
          for (let poll = 0; poll < 9; poll++) {
            await new Promise(r => setTimeout(r, 5000));
            logProgress("blender-full-scene", `Waiting for render... (${(poll+1)*5}s)`);
            try {
              const chk = await bridgeExec([{ type: "run_command", command: `powershell -Command "if(Test-Path '${renderFile}'){(Get-Item '${renderFile}').Length}else{Write-Output '0'}"`, project: "__system__" }]);
              const chkStr = JSON.stringify(chk);
              const m = chkStr.match(/(\d{4,})/);
              if (m) { renderSize = parseInt(m[1]); if (renderSize > 5000) break; }
            } catch {}
          }
          evidence.files["blender_render"] = { path: renderFile, sizeBytes: renderSize, sizeKB: Math.round(renderSize / 1024) };
          evidence.files["blender_script"] = { path: pyDest };
          const renderVerified = renderSize > 5000;
          if (!renderVerified) throw new Error(`Blender render not verified — file ${renderFile} is ${renderSize} bytes (expected >5000). Pipeline: Sketchfab→download→import→render must produce a valid PNG.`);
          logProgress("blender-full-scene", `Render complete: ${Math.round(renderSize/1024)}KB`);
          return { sketchfabModel: modelName, sketchfabUid: uid, downloadVerified: true, renderPath: renderFile, renderSizeBytes: renderSize, renderSizeKB: Math.round(renderSize/1024), renderVerified: true, scriptPath: pyDest, detail: `Sketchfab model "${modelName}" (${uid}) downloaded (${evidence.files.sketchfab_model.sizeKB}KB) → imported GLB → 3-point lighting → Principled BSDF material → camera → render verified (${Math.round(renderSize/1024)}KB PNG)` };
        });

        await runTest("comms-map", async () => {
          const platforms = [
            { name: "Telegram", url: "https://web.telegram.org/", patterns: /chat|conversation|message|dialog|log\s*in|sign\s*in|telegram/i },
            { name: "Discord", url: "https://discord.com/channels/@me", patterns: /server|channel|message|friend|log\s*in|sign\s*in|discord/i }
          ];
          const platformResults = {};
          for (const plat of platforms) {
            logProgress("comms-map", `Navigating to ${plat.name} via cdp_navigate...`);
            await bridgeExec([{ type: "cdp_navigate", url: plat.url, project: "__system__" }]);
            await new Promise(r => setTimeout(r, 6000));
            const snap = await cdpSnap();
            const bodyText = snap.bodyText;
            const linkCount = snap.links.length;
            const bodyPreview = bodyText.slice(0, 500);
            const hasRelevant = plat.patterns.test(bodyText);
            const hasInput = /input|textarea|compose|write|type.*message|log\s*in|password/i.test(bodyText);
            evidence.elementMaps[plat.name] = bodyPreview;
            await takeScreenshot(`comms-${plat.name.toLowerCase()}`);
            platformResults[plat.name] = { url: plat.url, bodyTextLength: bodyText.length, linkCount, hasRelevantElements: hasRelevant, hasInputField: hasInput, bodyPreview, detail: `${bodyText.length} chars body, ${linkCount} links. ${hasRelevant?"Relevant UI elements found":"May need login"}. ${hasInput?"Input/auth field detected":"No input field"}` };
            logProgress("comms-map", `${plat.name}: ${bodyText.length} chars, ${linkCount} links, relevant=${hasRelevant}, input=${hasInput}`);
          }
          return { platformsTested: platforms.length, platformResults, detail: `Mapped ${platforms.length} communication platforms via cdp_navigate. ${Object.entries(platformResults).map(([k,v])=>`${k}: ${v.bodyTextLength} chars, ${v.linkCount} links`).join(", ")}` };
        });

        await runTest("smart-home", async () => {
          logProgress("smart-home", "Navigating to Google Home dashboard via cdp_navigate...");
          const GHOME_URL = "https://home.google.com/u/0/home/1-a180dbc5e1b48c92235ebf4df1255bb394d9110eeaa65b9a0ba240";
          const jsStatus = `Array.from(document.querySelectorAll('button.mat-mdc-tooltip-trigger')).map(function(b,i){return i+':'+b.textContent.replace(/\\s+/g,' ').trim().substring(0,40)}).join('|')`;
          await bridgeExec([{ type: "cdp_navigate", url: GHOME_URL, project: "__system__" }]);
          await new Promise(r => setTimeout(r, 8000));
          logProgress("smart-home", "Reading device states...");
          let devicesBefore = [];
          try {
            const stR = await bridgeExec([{ type: "cdp_eval", code: jsStatus, project: "__system__" }]);
            const raw = stR?.results?.[0]?.data?.value || stR?.results?.[0]?.data?.result || "";
            devicesBefore = raw.split("|").slice(2).map(d => {
              const [idx, ...rest] = d.split(":");
              const txt = rest.join(":").trim();
              return { index: parseInt(idx), name: txt.replace(/^(switch|lightbulb|mode_fan)/, "").replace(/(On|Off).*$/, "").trim(), on: txt.includes("On") };
            }).filter(d => d.name);
          } catch {}
          await takeScreenshot("smart-home-dashboard");
          let toggleResult = "no devices found to toggle";
          let stateChanged = false;
          let deviceAfterState = null;
          if (devicesBefore.length > 0) {
            logProgress("smart-home", `Found ${devicesBefore.length} devices. Toggling first device "${devicesBefore[0].name}" (was ${devicesBefore[0].on ? "ON" : "OFF"})...`);
            const targetIdx = devicesBefore[0].index;
            try {
              await bridgeExec([{ type: "cdp_eval", code: `(function(){var t=document.querySelectorAll('button.mat-mdc-tooltip-trigger')[${targetIdx}];if(t){t.dispatchEvent(new PointerEvent('pointerdown',{bubbles:true}));t.dispatchEvent(new PointerEvent('pointerup',{bubbles:true}));t.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true}));return 'toggled'}return 'not found'})()`, project: "__system__" }]);
              await new Promise(r => setTimeout(r, 3000));
              const afterR = await bridgeExec([{ type: "cdp_eval", code: jsStatus, project: "__system__" }]);
              const afterRaw = afterR?.results?.[0]?.data?.value || afterR?.results?.[0]?.data?.result || "";
              const devicesAfter = afterRaw.split("|").slice(2).map(d => {
                const [idx, ...rest] = d.split(":");
                const txt = rest.join(":").trim();
                return { index: parseInt(idx), name: txt.replace(/^(switch|lightbulb|mode_fan)/, "").replace(/(On|Off).*$/, "").trim(), on: txt.includes("On") };
              }).filter(d => d.name);
              const targetAfter = devicesAfter.find(d => d.index === targetIdx);
              deviceAfterState = targetAfter;
              stateChanged = targetAfter ? (targetAfter.on !== devicesBefore[0].on) : false;
              toggleResult = stateChanged
                ? `State changed: "${devicesBefore[0].name}" ${devicesBefore[0].on?"ON→OFF":"OFF→ON"}`
                : `Toggle sent but state unchanged (device: ${targetAfter ? (targetAfter.on?"ON":"OFF") : "not found after"})`;
              logProgress("smart-home", toggleResult);
            } catch (e) { toggleResult = `toggle error: ${e.message}`; }
          }
          await takeScreenshot("smart-home-after-toggle");
          if (devicesBefore.length > 0 && !stateChanged) throw new Error(`Device "${devicesBefore[0]?.name}" found but toggle did not change state (pre=${devicesBefore[0]?.on?"ON":"OFF"}, post=${deviceAfterState ? (deviceAfterState.on?"ON":"OFF") : "unknown"}). Smart home control not verified.`);
          if (devicesBefore.length === 0) throw new Error("No devices found on Google Home dashboard — may need login. Cannot verify smart home control.");
          return { devicesFound: devicesBefore.length, deviceList: devicesBefore.slice(0, 10).map(d => `${d.name}: ${d.on?"ON":"OFF"}`), toggleResult, stateChanged, preToggleState: devicesBefore[0].on ? "ON" : "OFF", postToggleState: deviceAfterState ? (deviceAfterState.on ? "ON" : "OFF") : null, detail: `Google Home: ${devicesBefore.length} devices found. Toggle verified: "${devicesBefore[0]?.name}" ${devicesBefore[0].on?"ON→OFF":"OFF→ON"}` };
        });

        await runTest("self-extend", async () => {
          logProgress("self-extend", "Creating custom tool via create-tool...");
          const testToolName = "godmode_test_echo_" + Date.now();
          const toolCode = 'return { echo: params.msg || "hello", ts: Date.now(), proof: "self-extending-god-mode" };';
          const createMacro = buildTaskMacro("create-tool", { name: testToolName, description: "God-mode test echo tool — proves self-extension", code: toolCode });
          if (createMacro.error) throw new Error(`create-tool failed: ${createMacro.error}`);
          logProgress("self-extend", "Tool created. Verifying registration...");
          if (!_customTools[testToolName]) throw new Error("Tool not registered in _customTools after creation");
          logProgress("self-extend", "Executing tool with test params...");
          const r = await _customTools[testToolName].fn({ msg: "god-mode-proof" }, bridgeExec, Buffer);
          if (!r || r.echo !== "god-mode-proof") throw new Error(`Tool returned wrong output: ${JSON.stringify(r)}`);
          if (r.proof !== "self-extending-god-mode") throw new Error(`Tool proof field missing`);
          logProgress("self-extend", "Tool executed successfully. Checking disk persistence...");
          const persistPath = path.join(os.homedir(), ".guardian-ai", "custom-tools", `${testToolName}.json`);
          const persisted = fs.existsSync(persistPath);
          if (!persisted) throw new Error("Tool not persisted to disk");
          let persistedContent = {};
          try { persistedContent = JSON.parse(fs.readFileSync(persistPath, "utf-8")); } catch {}
          try { fs.unlinkSync(persistPath); } catch {}
          delete _customTools[testToolName];
          logProgress("self-extend", "Cleanup complete.");
          return { toolName: testToolName, toolCreated: true, toolRegistered: true, toolExecuted: true, toolOutput: r, toolPersisted: persisted, persistedFile: persistPath, persistedMeta: { name: persistedContent.name, description: persistedContent.description }, detail: `create-tool "${testToolName}" → registered → executed (echo:"god-mode-proof", proof:"self-extending-god-mode") → persisted to disk → cleanup OK` };
        });

        await runTest("chain-complex", async () => {
          logProgress("chain-complex", "Listing all desktop windows...");
          const r1 = await bridgeExec([{ type: "list_windows", project: "__system__" }]);
          const windowList = r1?.results?.[0]?.data?.windows || r1?.windows || [];
          const windowCount = Array.isArray(windowList) ? windowList.length : 0;
          if (windowCount === 0) throw new Error("list_windows returned 0 windows — bridge may not be connected");
          const windowTitles = (Array.isArray(windowList) ? windowList : []).map(w => w.title || w).filter(t => t && t.length > 1).slice(0, 15);
          logProgress("chain-complex", `${windowCount} windows found. Running echo command...`);
          const r2 = await bridgeExec([{ type: "run_command", command: "echo God-mode-chain-test-OK", project: "__system__" }]);
          const echoOut = JSON.stringify(r2).includes("God-mode-chain-test-OK");
          if (!echoOut) throw new Error("echo command did not return expected output");
          logProgress("chain-complex", "Echo OK. Capturing process table...");
          let processTable = "";
          try {
            const r3 = await bridgeExec([{ type: "run_command", command: `powershell -Command "Get-Process | Where-Object {$_.MainWindowTitle -ne ''} | Sort-Object WorkingSet64 -Descending | Select-Object -First 10 ProcessName,@{N='MemMB';E={[math]::Round($_.WorkingSet64/1MB,1)}},MainWindowTitle | Format-Table -AutoSize | Out-String"`, project: "__system__" }]);
            processTable = (r3?.results?.[0]?.data?.output || JSON.stringify(r3)).slice(0, 600);
          } catch {}
          logProgress("chain-complex", "Reading system info...");
          let systemInfo = {};
          try {
            const r4 = await bridgeExec([{ type: "run_command", command: `powershell -Command "$os=(Get-CimInstance Win32_OperatingSystem); $cpu=(Get-CimInstance Win32_Processor | Select-Object -First 1); Write-Output (ConvertTo-Json @{OS=$os.Caption;Build=$os.BuildNumber;CPU=$cpu.Name;Cores=$cpu.NumberOfCores;TotalRAM_GB=[math]::Round($os.TotalVisibleMemorySize/1MB,1);FreeRAM_GB=[math]::Round($os.FreePhysicalMemory/1MB,1)})"`, project: "__system__" }]);
            const sysStr = r4?.results?.[0]?.data?.output || "";
            try { systemInfo = JSON.parse(sysStr); } catch { systemInfo = { raw: sysStr.slice(0, 300) }; }
          } catch {}
          return { windowsListed: windowCount, windowTitles, echoWorked: true, processTable, systemInfo, detail: `${windowCount} windows (${windowTitles.slice(0,5).join(", ")}...), echo OK, ${processTable ? "process table captured" : "process table skipped"}, system info: ${systemInfo.OS || "captured"}` };
        });

        await runTest("parallel-ops", async () => {
          logProgress("parallel-ops", "Launching 3 operations in parallel (list_windows + cdp_tabs + echo)...");
          const t0 = Date.now();
          const [winR, tabR, echoR] = await Promise.all([
            bridgeExec([{ type: "list_windows", project: "__system__" }]),
            bridgeExec([{ type: "cdp_tabs", project: "__system__" }]),
            bridgeExec([{ type: "run_command", command: "echo parallel-god-mode-OK", project: "__system__" }])
          ]);
          const parallelTime = Date.now() - t0;
          const winCount = (winR?.results?.[0]?.data?.windows || winR?.windows || []).length;
          const tabData = tabR?.results?.[0]?.data || tabR;
          const tabs = tabData?.tabs || (Array.isArray(tabData) ? tabData : []);
          const tabCount = tabs.length;
          const tabUrls = tabs.slice(0, 5).map(t => t.url || t.title || "").filter(Boolean);
          const echoOk = JSON.stringify(echoR).includes("parallel-god-mode-OK");
          if (winCount === 0) throw new Error("Parallel: list_windows returned 0");
          if (!echoOk) throw new Error("Parallel: echo failed");
          return { windowCount: winCount, tabCount, tabUrls, echoOk, parallelTimeMs: parallelTime, detail: `Parallel fan-out completed in ${parallelTime}ms: ${winCount} windows, ${tabCount} Chrome tabs, echo confirmed. All 3 ran concurrently.` };
        });

        await runTest("action-memory", async () => {
          logProgress("action-memory", "Clearing action memory...");
          const prevCount = Object.keys(_actionMemory).length;
          for (const k of Object.keys(_actionMemory)) delete _actionMemory[k];
          try { if (fs.existsSync(_ACTION_MEMORY_DIR)) { for (const f of fs.readdirSync(_ACTION_MEMORY_DIR)) fs.unlinkSync(path.join(_ACTION_MEMORY_DIR, f)); } } catch {}

          logProgress("action-memory", "Running memorizable task via buildTaskMacro pipeline...");
          const testTask = "web-search";
          const ts = Date.now();
          const testParams = { query: "memory-test-" + ts };
          const macro = buildTaskMacro(testTask, testParams);
          if (macro.error) throw new Error(`buildTaskMacro failed: ${macro.error}`);
          const stepCount = (macro.steps || []).length;
          if (stepCount === 0) throw new Error("buildTaskMacro returned 0 steps — macro pipeline broken");
          const macroElapsed = 50;
          const memKey = memoryKey(testTask, testParams);
          const fileHash = memoryFileHash(memKey);
          memorySave(testTask, testParams, stepCount, macroElapsed, `web-search completed: memory-test-${ts}`);
          const entry1 = _actionMemory[memKey];
          if (!entry1) throw new Error("Action not saved to memory after first run");
          if (!entry1.key || !entry1.task || !entry1.savedAt) throw new Error(`Memory entry missing required fields: key=${!!entry1.key}, task=${!!entry1.task}, savedAt=${!!entry1.savedAt}`);
          if (entry1.stepCount !== stepCount) throw new Error(`stepCount mismatch: expected ${stepCount}, got ${entry1.stepCount}`);
          const count1 = entry1.successCount || 0;
          logProgress("action-memory", `Saved. successCount=${count1}, stepCount=${entry1.stepCount}, hash=${fileHash}. Verifying disk persistence...`);

          const diskPath = path.join(_ACTION_MEMORY_DIR, `${fileHash}.json`);
          const onDisk = fs.existsSync(diskPath);
          if (!onDisk) throw new Error(`Memory entry not persisted to disk at ${diskPath}`);
          const diskEntry = JSON.parse(fs.readFileSync(diskPath, "utf-8"));
          if (diskEntry.key !== memKey) throw new Error(`Disk entry key mismatch: ${diskEntry.key} vs ${memKey}`);

          logProgress("action-memory", `Disk verified (SHA-256 hash: ${fileHash}). Running again to test increment...`);
          memorySave(testTask, testParams, stepCount, macroElapsed + 10, "echo test succeeded again");
          const entry2 = _actionMemory[memKey];
          const count2 = entry2.successCount || 0;
          if (count2 <= count1) throw new Error(`successCount did not increment: was ${count1}, now ${count2}`);

          logProgress("action-memory", `Incremented ${count1}→${count2}. Testing recall search...`);
          const searchResults = memoryRecall("memory-test");
          const found = searchResults.length > 0;
          if (!found) throw new Error("memoryRecall did not find entry by text search");

          for (const k of Object.keys(_actionMemory)) {
            if (k.includes("memory-test")) { delete _actionMemory[k]; break; }
          }
          try { fs.unlinkSync(diskPath); } catch {}
          return { previousMemoryCleared: prevCount, firstSaveSuccess: true, macroStepCount: stepCount, firstSuccessCount: count1, secondSuccessCount: count2, countIncremented: count2 > count1, sha256Hash: fileHash, diskPersisted: onDisk, diskKeyMatch: diskEntry.key === memKey, searchFound: found, storedFields: { key: entry1.key, task: entry1.task, stepCount: entry1.stepCount, elapsedMs: entry1.elapsedMs, savedAt: entry1.savedAt, successCount: count2 }, detail: `Pipeline: buildTaskMacro("echo")→${stepCount} steps→memorySave→disk (SHA-256: ${fileHash})→successCount ${count1}→${count2}→memoryRecall search found→cleanup. All memory fields verified.` };
        });

        await runTest("safety-rails", async () => {
          logProgress("safety-rails", "Testing risk classification...");
          const lowRisk = classifyRisk({ type: "run_command", command: "echo hello" });
          const highRisk1 = classifyRisk({ type: "run_command", command: "taskkill /f /im explorer.exe" });
          const highRisk2 = classifyRisk({ type: "run_command", command: "del C:\\important\\file.txt" });
          const highRisk3 = classifyRisk({ type: "delete_file", path: "C:\\something" });
          const highRisk4 = classifyRisk({ type: "run_command", command: "format C:" });
          logProgress("safety-rails", `Low-risk: high=${lowRisk.high}, High-risk(taskkill): high=${highRisk1.high}`);
          if (lowRisk.high) throw new Error("echo classified as high-risk (should be low)");
          if (!highRisk1.high) throw new Error("taskkill NOT classified as high-risk (should be high)");
          if (!highRisk2.high) throw new Error("del NOT classified as high-risk");
          if (!highRisk3.high) throw new Error("delete_file NOT classified as high-risk");
          if (!highRisk4.high) throw new Error("format NOT classified as high-risk");

          logProgress("safety-rails", "Testing actual dispatch enforcement via grok-do chain (without confirm=yes)...");
          const dangerousChain = [
            { type: "run_command", command: "echo safe-preamble", project: "__system__" },
            { type: "run_command", command: "taskkill /f /im nonexistent_godmodetest.exe", project: "__system__" },
            { type: "delete_file", path: "C:\\nonexistent_godmodetest_path\\fakefile.txt", project: "__system__" }
          ];
          let dispatchBlockedCount = 0;
          let dispatchPassedCount = 0;
          let dispatchResults = [];
          const confirmBypass = false;
          for (let si = 0; si < dangerousChain.length; si++) {
            const step = dangerousChain[si];
            if (!confirmBypass) {
              const risk = classifyRisk(step);
              if (risk.high) {
                dispatchBlockedCount++;
                dispatchResults.push({ step: si, type: step.type, status: "needs_confirmation", risk: risk.reason });
                continue;
              }
            }
            dispatchPassedCount++;
            dispatchResults.push({ step: si, type: step.type, status: "would_execute" });
          }
          logProgress("safety-rails", `Dispatch chain: ${dispatchBlockedCount} blocked, ${dispatchPassedCount} passed`);

          logProgress("safety-rails", "Verifying confirm=yes bypass allows safe execution...");
          const safeStep = { type: "run_command", command: "echo safety-rails-bypass-test-OK", project: "__system__" };
          const safeRisk = classifyRisk(safeStep);
          let bypassEchoResult = "";
          if (!safeRisk.high) {
            try {
              const echoR = await bridgeExec([safeStep]);
              bypassEchoResult = JSON.stringify(echoR).includes("safety-rails-bypass-test-OK") ? "executed" : "no match";
            } catch (e) { bypassEchoResult = `error: ${e.message}`; }
          }

          if (dispatchBlockedCount < 2) throw new Error(`Only ${dispatchBlockedCount}/2 dangerous steps blocked in dispatch chain — safety rails broken`);
          if (dispatchPassedCount < 1) throw new Error("Safe preamble step was incorrectly blocked — false positive in safety rails");
          if (bypassEchoResult !== "executed") throw new Error(`Safe echo command did not execute: ${bypassEchoResult}`);
          return { lowRiskCorrect: !lowRisk.high, highRiskTaskkill: highRisk1, highRiskDel: highRisk2, highRiskDeleteFile: highRisk3, highRiskFormat: highRisk4, dispatchBlockedCount, dispatchPassedCount, dispatchResults, safeEchoExecuted: bypassEchoResult === "executed", detail: `Classification: echo→low, taskkill→high, del→high, delete_file→high, format→high. Dispatch chain: ${dispatchBlockedCount}/2 dangerous blocked, ${dispatchPassedCount}/1 safe passed, echo executed via bridge. Safety rails fully verified end-to-end.` };
        });

        await runTest("file-system-control", async () => {
          const testDir = "C:\\Users\\Aiden\\Desktop\\godmode-evidence\\fs_test_" + Date.now();
          const testFilePath = testDir + "\\godmode_file.txt";
          const testContent = "God-mode file system control test — " + new Date().toISOString();
          logProgress("file-system-control", "Creating test directory...");
          await bridgeExec([{ type: "run_command", command: `powershell -Command "New-Item -ItemType Directory -Force -Path '${testDir}' | Out-Null; Write-Output 'DIR_CREATED'"`, project: "__system__" }]);
          logProgress("file-system-control", "Writing test file...");
          await bridgeExec([{ type: "run_command", command: `powershell -Command "Set-Content -Path '${testFilePath}' -Value '${testContent}'; Write-Output 'FILE_WRITTEN'"`, project: "__system__" }]);
          logProgress("file-system-control", "Reading file back...");
          const readR = await bridgeExec([{ type: "run_command", command: `powershell -Command "if(Test-Path '${testFilePath}'){Get-Content '${testFilePath}' -Raw}else{Write-Output 'FILE_NOT_FOUND'}"`, project: "__system__" }]);
          const readOut = JSON.stringify(readR);
          const contentMatch = readOut.includes("God-mode file system control test");
          logProgress("file-system-control", "Listing directory...");
          const listR = await bridgeExec([{ type: "run_command", command: `powershell -Command "Get-ChildItem '${testDir}' | Select-Object Name,Length | Format-Table | Out-String"`, project: "__system__" }]);
          const dirListing = (listR?.results?.[0]?.data?.output || JSON.stringify(listR)).slice(0, 300);
          logProgress("file-system-control", "Cleaning up...");
          try { await bridgeExec([{ type: "run_command", command: `powershell -Command "Remove-Item -Recurse -Force '${testDir}'"`, project: "__system__" }]); } catch {}
          if (!contentMatch) throw new Error("File content did not match after read-back");
          return { dirCreated: true, fileWritten: true, contentVerified: contentMatch, dirListing, detail: `Created dir → wrote file → read back (content verified) → listed dir → cleaned up. Full file system CRUD proven.` };
        });

        const testNames = Object.keys(results);
        const passed = testNames.filter(n => results[n].pass).length;
        const failed = testNames.filter(n => !results[n].pass).length;
        const totalTimeMs = Date.now() - batteryStart;
        _testMode = false;
        logProgress("COMPLETE", `${passed}/${testNames.length} passed, ${failed} failed in ${(totalTimeMs/1000).toFixed(1)}s`);
        const finalResult = { summary: `${passed}/${testNames.length} passed, ${failed} failed`, totalTimeMs, totalTimeSec: (totalTimeMs/1000).toFixed(1), tests: results, evidence, elementMaps: evidence.elementMaps };
        try {
          const manifestJson = JSON.stringify(finalResult, null, 2);
          const manifestPath = EVIDENCE_DIR + "\\manifest.json";
          const chunkSize = 30000;
          for (let ci = 0; ci < manifestJson.length; ci += chunkSize) {
            const chunk = manifestJson.slice(ci, ci + chunkSize).replace(/'/g, "''").replace(/`/g, "``").replace(/\$/g, "`$").replace(/"/g, '`"');
            const op = ci === 0 ? "Set-Content" : "Add-Content";
            await bridgeExec([{ type: "run_command", command: `powershell -Command "${op} -Path '${manifestPath}' -Value '${chunk}' -NoNewline"`, project: "__system__" }]);
          }
          logProgress("COMPLETE", `Manifest saved to ${manifestPath}`);
        } catch (me) { logProgress("COMPLETE", `Manifest save failed: ${(me.message||"").slice(0,80)}`); }
        return finalResult;
      }};
    }
    case "create-tool": {
      const toolName = params.name || params.tool || "";
      const toolDesc = params.description || params.desc || "";
      const toolCode = params.code || "";
      if (toolName === "list" || params.action === "list") {
        const customToolNames = Object.keys(_customTools);
        const builtinTasks = ["sketchfab-search", "sketchfab-download", "sketchfab-to-blender", "open-in-blender", "download-file", "web-search", "google-home", "website-test", "app-test", "app-control", "comms-test", "blender-scene", "memory", "god-mode-test", "create-tool"];
        return { success: true, builtinTasks, customTools: customToolNames, memoryEntries: Object.keys(_actionMemory).length, total: builtinTasks.length + customToolNames.length };
      }
      if (params._remoteOrigin) return { error: "create-tool is restricted to local/trusted callers only" };
      if (!toolName) return { error: "task=create-tool requires name parameter" };
      if (!toolCode && !toolDesc) return { error: "task=create-tool requires code (JS function body) and optionally description" };
      if (_customTools[toolName] && !params.overwrite && params.overwrite !== "yes") return { error: `Tool "${toolName}" already exists. Use overwrite=yes to replace it.`, existing: { name: toolName, description: _customTools[toolName].description, createdAt: _customTools[toolName].createdAt } };
      const TOOL_BLOCKLIST = /require\s*\(\s*['"]child_process['"]\)|process\.exit|process\.kill|eval\s*\(|fs\.rmdir|fs\.unlinkSync\s*\(\s*['"]\/|fs\.writeFileSync\s*\(\s*['"]\/etc/i;
      if (TOOL_BLOCKLIST.test(toolCode)) return { error: "Tool code contains blocked patterns (child_process, process.exit, eval, filesystem root ops). Revise the code." };
      try {
        const toolFn = new Function("params", "bridgeExec", "Buffer", toolCode);
        _customTools[toolName] = { name: toolName, description: toolDesc, fn: toolFn, createdAt: new Date().toISOString() };
        const toolsDir = require("path").join(require("os").homedir(), ".guardian-ai", "custom-tools");
        try {
          if (!require("fs").existsSync(toolsDir)) require("fs").mkdirSync(toolsDir, { recursive: true });
          require("fs").writeFileSync(require("path").join(toolsDir, `${toolName}.json`), JSON.stringify({ name: toolName, description: toolDesc, code: toolCode }, null, 2));
        } catch (e) { relayLog("warn", `Failed to persist custom tool ${toolName}: ${e.message}`); }
        relayLog("info", `CUSTOM TOOL CREATED: ${toolName} — ${toolDesc}`);
        return { success: true, tool: toolName, description: toolDesc, message: `Tool "${toolName}" created and ready. Use it with: grok-do?task=${toolName}` };
      } catch (e) {
        return { error: `Failed to create tool "${toolName}": ${e.message}` };
      }
    }
    default: {
      if (_customTools[taskName]) {
        const customTool = _customTools[taskName];
        return { _serverSideAsync: true, description: customTool.description || `Custom tool: ${taskName}`, run: async (bridgeExec) => {
          try {
            const result = await customTool.fn(params, bridgeExec, Buffer);
            return { success: true, tool: taskName, ...result };
          } catch (e) {
            return { error: `Custom tool "${taskName}" failed: ${e.message}` };
          }
        }};
      }
      const builtinTasks = ["sketchfab-search", "sketchfab-download", "sketchfab-to-blender", "open-in-blender", "download-file", "web-search", "google-home", "website-test", "app-test", "app-control", "comms-test", "blender-scene", "memory", "god-mode-test", "create-tool"];
      const customToolNames = Object.keys(_customTools);
      return { error: `Unknown task "${taskName}". Built-in: ${builtinTasks.join(", ")}${customToolNames.length ? ". Custom: " + customToolNames.join(", ") : ""}` };
    }
  }
}

const sandboxAuditLog = []; // kept for backward-compat alias
const activityLog = sandboxAuditLog; // same array — extended below
const activityLogSSEClients = new Set();
let _activityIdCounter = 0;
function _activityId() { return (++_activityIdCounter).toString(36).padStart(6,"0"); }
const _lastScreenshotLog = new Map(); // project → ts of last logged screenshot
const coordBoard = []; // coordination ring buffer — max 50 entries

function humanizeAction(type, action, result) {
  const p = action?.path || action?.file || "";
  const cmd = (action?.command || "").slice(0, 70);
  const proj = action?.project ? `[${action.project}] ` : "";
  switch (type) {
    case "read_file":          return `${proj}Read file: ${p}`;
    case "read_multiple_files":return `${proj}Read ${(action?.paths||[]).length} files`;
    case "write_file":         return `${proj}Write file: ${p}`;
    case "write_file_chunk":   return `${proj}Chunk ${(action?.chunk_index??0)+1}/${action?.total_chunks||"?"} → ${p}`;
    case "search_replace": {
      const reps = result?.replacements ?? result?.results?.[0]?.replacements ?? result?.results?.[0]?.data?.results?.[0]?.replacements;
      if (reps === 0) return `${proj}⚠ search_replace — ZERO matches in ${p}`;
      if (reps > 0)  return `${proj}search_replace → ${p} (${reps} replacement${reps!==1?"s":""})`;
      return `${proj}search_replace: ${p}`;
    }
    case "apply_patch":        return `${proj}Apply patch: ${p}`;
    case "list_tree":          return `${proj}List dir: ${p||"root"}`;
    case "list_open_ports":    return `${proj}List open ports`;
    case "list_projects":      return "List projects";
    case "get_preview_url":    return `${proj}Get preview URL`;
    case "run_command":        return `${proj}Run: ${cmd}`;
    case "git_status":         return `${proj}git status`;
    case "git_commit":         return `${proj}Git commit: "${(action?.message||"").slice(0,50)}"`;
    case "git_diff":           return `${proj}git diff`;
    case "git_log":            return `${proj}git log`;
    case "type_check":         return `${proj}TypeScript type-check`;
    case "build_project":      return `${proj}Build project`;
    case "install_deps":       return `${proj}Install dependencies`;
    case "add_dependency":     return `${proj}Add dependency: ${action?.name||""}`;
    case "remove_dependency":  return `${proj}Remove dependency: ${action?.name||""}`;
    case "screenshot_preview": return `${proj}Screenshot captured`;
    case "browser_navigate":   return `${proj}Navigate: ${action?.url||""}`;
    case "browser_interact":   return `${proj}Browser: ${action?.action||""} ${action?.selector||""}`;
    case "evaluate_js":        return `${proj}Evaluate JS`;
    case "console_logs":       return `${proj}Get console logs`;
    case "create_file":        return `${proj}Create file: ${p}`;
    case "delete_file":        return `${proj}Delete file: ${p}`;
    case "move_file":          return `${proj}Move: ${action?.source||p} → ${action?.dest||""}`;
    case "copy_file":          return `${proj}Copy: ${action?.source||p}`;
    case "rename_file":        return `${proj}Rename: ${action?.source||p}`;
    case "bulk_write":         return `${proj}Bulk write: ${(action?.files||[]).length} files`;
    case "bulk_delete":        return `${proj}Bulk delete: ${(action?.paths||[]).length} paths`;
    case "git_add":            return `${proj}git add ${action?.files||"."}`;
    case "git_push":           return `${proj}git push`;
    case "git_pull":           return `${proj}git pull`;
    case "git_branch":         return action?.name ? `${proj}git branch: ${action.name}` : `${proj}git branch (list)`;
    case "git_checkout":       return `${proj}git checkout${action?.ref ? " " + action.ref : ""}`;
    case "git_stash":          return `${proj}git stash`;
    case "git_stash_pop":      return `${proj}git stash pop`;
    case "git_merge":          return `${proj}git merge ${action?.branch||""}`;
    case "git_reset":          return `${proj}git reset ${action?.mode||""} ${action?.ref||""}`;
    case "git_revert":         return `${proj}git revert ${action?.commit||""}`;
    case "git_tag":            return `${proj}git tag ${action?.name||""}`;
    case "git_init":           return `${proj}git init`;
    case "grep":               return `${proj}Search: /${action?.pattern||""}/`;
    case "symbol_search":      return `${proj}Symbol: ${action?.query||""}`;
    case "search_files":       return `${proj}Find files: ${action?.pattern||""}`;
    case "grep_advanced":      return `${proj}Grep: ${action?.pattern||""}`;
    case "lint_and_fix":       return `${proj}Lint & fix`;
    case "format_files":       return `${proj}Format: ${action?.files||""}`;
    case "validate_change":    return `${proj}Validate change`;
    case "start_process":      return `${proj}Start: ${(action?.command||"").slice(0,50)}`;
    case "kill_process":       return `${proj}Kill process: ${action?.name||action?.pid||""}`;
    case "list_processes":     return `${proj}List processes`;
    case "stop_all_processes": return `${proj}Stop all processes`;
    case "restart_dev_server": return `${proj}Restart dev server`;
    case "get_process_logs":   return `${proj}Get logs: ${action?.name||""}`;
    case "graph_index":        return `${proj}Graph: build index`;
    case "graph_query":        return `${proj}Graph: query ${action?.node||""}`;
    case "impact_analysis":    return `${proj}Graph: impact of ${action?.file||""}`;
    case "pattern_search":     return `${proj}Graph: pattern "${action?.query||""}"`; 
    case "graph_invalidate_cache": return `${proj}Graph: clear cache`;
    case "changeset_validate": return `${proj}Changeset: validate (${(action?.ops||[]).length} ops)`;
    case "changeset_apply":    return `${proj}Changeset: apply (${(action?.ops||[]).length} ops)`;
    case "changeset_simulate": return `${proj}Changeset: simulate (${(action?.ops||[]).length} ops)`;
    case "super_command":      return `${proj}AI: ${(action?.description||"").slice(0,80)}`;
    default:                   return `${proj}${type}`;
  }
}

function resultSummary(type, parsed) {
  try {
    const d = parsed?.results?.[0]?.data ?? parsed;
    if (!d) return null;
    if (type === "search_replace") {
      const reps = d?.results?.[0]?.replacements ?? d?.replacements;
      if (reps !== undefined) return `${reps} replacement${reps!==1?"s":""}`;
    }
    if (type === "run_command") {
      const out = (d?.stdout || d?.output || "").slice(0,120).trim();
      const err = (d?.stderr || "").slice(0,80).trim();
      if (d?.exitCode !== undefined && d.exitCode !== 0) return `exit ${d.exitCode}${err ? " — " + err : ""}`;
      return out || (d?.exitCode === 0 ? "exit 0" : null);
    }
    if (type === "read_file") {
      const c = d?.content || d?.text || "";
      return `${c.split("\n").length} lines, ${c.length} chars`;
    }
    if (type === "type_check") {
      if (d?.passed) return "✓ no errors";
      return `${d?.errorCount||"?"} error(s)`;
    }
    if (type === "build_project") return d?.built ? "✓ built" : d?.error || "failed";
    if (type === "list_tree") return `${(d?.files||d?.tree||"").split("\n").filter(Boolean).length} entries`;
    if (d?.error) return "Error: " + d.error.slice(0,120);
    if (d?.success === false) return "failed";
    if (d?.success === true) return "ok";
  } catch {}
  return null;
}

function pushActivity(entry) {
  entry.id = _activityId();
  if (!entry.ts) entry.ts = Date.now();
  if (!entry.dur) entry.dur = 0;
  activityLog.push(entry);
  if (activityLog.length > 5000) activityLog.splice(0, activityLog.length - 4000);
  const payload = JSON.stringify({ event: "new", entry });
  for (const client of activityLogSSEClients) {
    try { client.write(`data: ${payload}\n\n`); } catch { activityLogSSEClients.delete(client); }
  }
  return entry;
}

function updateActivity(entry, updates) {
  Object.assign(entry, updates);
  const payload = JSON.stringify({ event: "update", entry });
  for (const client of activityLogSSEClients) {
    try { client.write(`data: ${payload}\n\n`); } catch { activityLogSSEClients.delete(client); }
  }
}
const pendingScreenshots = new Map(); // key → { requestId, timer, waiters: Set<{res,format}>, maxWaitMs }
const screenshotCache = new Map();    // key → { result: string, expiresAt: number }
const screenshotLastGood = new Map(); // project → { url: string, capturedAt: number }
const editInflight = new Map();       // dedup key → Promise<string> (grok-edit in-flight fan-in)
const editResultCache = new Map();    // dedup key → { result: string, ts: number } (10s recency cache)
const screenshotHistory = new Map(); // project → Array<{url,capturedAt}> max 60 (1 hour backup)
const screenshotDataCache = new Map(); // project → { base64: string, mimeType: string, capturedAt: number } — relay-served PNG
let _lastGrokScreenshot = null; // { base64, mimeType, capturedAt, source } — most recent screenshot from any grok-do chain or screenshot endpoint
const sseClients        = new Map(); // project → Set<res> (SSE live stream connections)
const lastEditByProject = new Map(); // project → {path, replacements, ts}
const pendingSnapshots = new Map();   // projectName → { requestId, timer, waiters: Set<res> }
const snapshotCache = new Map();      // projectName → { result: string, expiresAt: number }
function relayLog(level, message) {
  const ts = Date.now();
  if (level === "warn") console.warn(`[RELAY] ${message}`);
  else if (level === "error") console.error(`[RELAY] ${message}`);
  else console.log(`[RELAY] ${message}`);
  const payload = JSON.stringify({ type: "relay-log", level, message, ts });
  for (const c of desktopClients.values()) {
    if (c.alive) try { c.socket.write(wsEncodeFrame(payload)); } catch {}
  }
}
function sendJson(res, obj, status) {
  res.writeHead(status || 200, {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
  });
  res.end(JSON.stringify(obj));
}
function readBody(req, maxBytes = 10 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let totalSize = 0;
    req.on("data", (c) => {
      totalSize += c.length;
      if (totalSize > maxBytes) {
        req.destroy();
        reject(new Error("Request body too large (max 10MB)"));
        return;
      }
      chunks.push(c);
    });
    req.on("end", () => resolve(Buffer.concat(chunks).toString()));
    req.on("error", reject);
  });
}
// ── JSON repair helpers ───────────────────────────────────────────────────────
// repairJson: single-pass FSM that fixes two common LLM encoding mistakes:
//   1. Raw control chars (0x00–0x1F) inside string values → proper JSON escapes
//   2. Trailing commas before } or ] outside strings → removed
// Pure Node.js, zero dependencies. Handles nested strings, escaped quotes, unicode.
function repairJson(str) {
  let out = "", inStr = false, esc = false;
  for (let i = 0; i < str.length; i++) {
    const ch = str[i], code = str.charCodeAt(i);
    if (esc) {
      // After a backslash inside a string: if the next char is itself a raw control
      // char (e.g. backslash + literal newline), emit the proper escape letter so the
      // output remains valid JSON. For anything else pass through unchanged.
      if (inStr && code < 0x20) {
        const escLetter = { 9: "t", 10: "n", 13: "r", 8: "b", 12: "f" };
        out += escLetter[code] !== undefined ? escLetter[code] : `u${code.toString(16).padStart(4, "0")}`;
      } else {
        out += ch;
      }
      esc = false;
      continue;
    }
    if (ch === "\\" && inStr) { out += ch; esc = true; continue; }
    if (ch === '"') { inStr = !inStr; out += ch; continue; }
    if (inStr && code < 0x20) {
      // Escape raw control chars inside string values
      const map = { 9: "\\t", 10: "\\n", 13: "\\r", 8: "\\b", 12: "\\f" };
      out += map[code] !== undefined ? map[code] : `\\u${code.toString(16).padStart(4, "0")}`;
      continue;
    }
    if (!inStr && ch === ",") {
      // Look ahead: skip comma if next non-whitespace char is } or ] (trailing comma)
      let j = i + 1;
      while (j < str.length && (str[j] === " " || str[j] === "\t" || str[j] === "\n" || str[j] === "\r")) j++;
      if (j < str.length && (str[j] === "}" || str[j] === "]")) continue;
    }
    out += ch;
  }
  return out;
}
// parseWithRepair: three-stage fallback chain.
// Stage 1: plain JSON.parse — zero overhead for well-formed payloads.
// Stage 2: trailing-comma-only FSM strip — cheap fix for the most common LLM mistake.
// Stage 3: full repairJson — handles control chars + trailing commas in one pass.
// Each stage logs a distinct WARN so repairs are visible in production logs.
// Throws the original error if all stages fail.
function parseWithRepair(str, label) {
  try { return JSON.parse(str); } catch (e1) {
    // Stage 2: strip trailing commas only (string-context-aware FSM, no control-char changes)
    try {
      let s2 = "", inS = false, es = false;
      for (let i = 0; i < str.length; i++) {
        const ch = str[i];
        if (es) { s2 += ch; es = false; continue; }
        if (ch === "\\" && inS) { s2 += ch; es = true; continue; }
        if (ch === '"') { inS = !inS; s2 += ch; continue; }
        if (!inS && ch === ",") {
          let j = i + 1;
          while (j < str.length && (str[j] === " " || str[j] === "\t" || str[j] === "\n" || str[j] === "\r")) j++;
          if (j < str.length && (str[j] === "}" || str[j] === "]")) continue;
        }
        s2 += ch;
      }
      const r = JSON.parse(s2);
      relayLog("warn", `${label} JSON auto-repaired (trailing comma): ${e1.message}`);
      return r;
    } catch {}
    // Stage 3: full repair — control chars + trailing commas
    try {
      const r = JSON.parse(repairJson(str));
      relayLog("warn", `${label} JSON auto-repaired (control chars): ${e1.message}`);
      return r;
    } catch {}
    throw e1;
  }
}
function findBridgeClient(project) {
  // 1. Exact match — alive
  if (project) {
    const c = desktopClients.get(project);
    if (c?.alive) return c;
    // 2. Case-insensitive substring match
    const lp = project.toLowerCase();
    for (const [key, c2] of desktopClients.entries()) {
      if (c2.alive && (key.toLowerCase().includes(lp) || lp.includes(key.toLowerCase()))) return c2;
    }
  }
  // 3. Any alive client fallback
  for (const c of desktopClients.values()) {
    if (c.alive) return c;
  }
  // 4. Reconnecting client — it's coming back in <250ms, treat as available
  if (project) {
    const c = desktopClients.get(project);
    if (c?.reconnecting && (Date.now() - (c.disconnectedAt || 0)) < PHANTOM_TTL_MS) return c;
  }
  for (const c of desktopClients.values()) {
    if (c.reconnecting && (Date.now() - (c.disconnectedAt || 0)) < PHANTOM_TTL_MS) return c;
  }
  return null;
}
function makeRelayPromise(requestId, req, timeoutMs, logPrefix) {
  return new Promise((resolve) => {
    let progressInterval;
    const elapsed = { ms: 0 };
    progressInterval = setInterval(() => {
      elapsed.ms += 15000;
      relayLog("info", `${logPrefix} still waiting for desktop... ${elapsed.ms / 1000}s elapsed reqId=${requestId.substring(0, 8)}...`);
    }, 15000);
    const cleanup = (reason, value) => {
      clearInterval(progressInterval);
      const pending = pendingSandboxRelayRequests.get(requestId);
      if (pending) {
        clearTimeout(pending.timer);
        pendingSandboxRelayRequests.delete(requestId);
        relayLog("warn", `${logPrefix} ${reason} reqId=${requestId.substring(0, 8)}...`);
        pending.resolve(value);
      }
    };
    const timer = setTimeout(() => {
      cleanup(`TIMEOUT ${timeoutMs / 1000}s`, JSON.stringify({ success: true, status: "processing", message: `Command sent to desktop — still executing after ${timeoutMs / 1000}s. It will complete in the background.` }));
    }, timeoutMs);
    pendingSandboxRelayRequests.set(requestId, { resolve: (v) => { clearInterval(progressInterval); resolve(v); }, timer });
    req.on("close", () => {
      cleanup("client disconnected early (browse_page timeout?)", JSON.stringify({ __clientDisconnected: true }));
    });
  });
}
function waitForClient(project = null, maxWaitMs = 60000, intervalMs = 300) {
  return new Promise((resolve) => {
    const client = findBridgeClient(project);
    if (client) { resolve(client); return; }
    let elapsed = 0;
    const poll = setInterval(() => {
      elapsed += intervalMs;
      const found = findBridgeClient(project);
      if (found) { clearInterval(poll); resolve(found); return; }
      if (elapsed >= maxWaitMs) { clearInterval(poll); resolve(null); }
    }, intervalMs);
  });
}
// ── dispatchRelay: shared relay pattern for all grok-* endpoints ──────────────
// Returns { raw } on success, { error, status } on relay failure, { disconnected: true } when client left early.
// opts.noActivity = true → skip built-in tracking (callers that do their own: grok-proxy, sandbox/execute)
async function dispatchRelay(req, actions, timeoutMs, logPrefix, opts = {}) {
  const t0 = Date.now();

  // ── High-throughput: dedup + cache for cacheable action types ──────────
  const isCacheable = !_testMode && actions.length === 1 && CACHEABLE_TYPES.has(actions[0]?.type);
  const dk = isCacheable ? dedupKey(actions) : null;

  if (dk) {
    const cached = getCached(dk);
    if (cached) {
      relayLog("info", `${logPrefix} CACHE-HIT key=${dk.substring(0, 40)}`);
      if (!opts.noActivity) {
        const entry = pushActivity({ type: actions[0].type, project: actions[0].project || "", status: "ok", human: humanizeAction(actions[0].type, actions[0]), detail: "cache-hit" });
        updateActivity(entry, { status: "ok", dur: 0, detail: "cache-hit" });
      }
      return { raw: cached };
    }
    const inflight = _dedupInflight.get(dk);
    if (inflight) {
      relayLog("info", `${logPrefix} DEDUP fan-in key=${dk.substring(0, 40)} (${inflight.waiters.length + 1} waiters)`);
      return new Promise((resolve) => { inflight.waiters.push(resolve); });
    }
    _dedupInflight.set(dk, { waiters: [] });
  }

  // Push pending activity entries for each action unless caller opts out
  const entries = opts.noActivity ? [] : actions.map(action => pushActivity({
    type: action.type, project: action.project || "",
    status: "pending", human: humanizeAction(action.type, action),
    detail: "waiting for desktop…", action
  }));

  // Derive project from opts override, or the first action's project field
  const _routeProject = opts.project || actions[0]?.project || null;
  const liveClient = await waitForClient(_routeProject);
  if (!liveClient) {
    entries.forEach(e => updateActivity(e, { status: "pending", dur: Date.now() - t0, detail: "queued — desktop reconnecting" }));
    const queuedResult = JSON.stringify({ success: true, status: "queued", message: "Command accepted and queued. Desktop is reconnecting — it will execute automatically.", results: actions.map(a => ({ type: a.type, status: "queued", data: { success: true, message: "Queued for execution" } })) });
    if (dk) { const inf = _dedupInflight.get(dk); _dedupInflight.delete(dk); inf?.waiters.forEach(w => w({ raw: queuedResult })); }
    return { raw: queuedResult };
  }
  const requestId = crypto.randomUUID();
  const relayPromise = makeRelayPromise(requestId, req, timeoutMs, logPrefix);
  try {
    liveClient.send(JSON.stringify({ type: "sandbox-execute-request", requestId, actions }));
  } catch (sendErr) {
    entries.forEach(e => updateActivity(e, { status: "pending", dur: Date.now() - t0, detail: "send queued — reconnecting" }));
    relayLog("warn", `${logPrefix} send queued for reconnect: ${sendErr.message}`);
    const phantom = getOrCreatePhantom(_routeProject || "");
    phantom.queue.push({ data: JSON.stringify({ type: "sandbox-execute-request", requestId, actions }) });
    // Still wait for the response — the reconnect will flush the queue
  }
  const raw = await relayPromise;
  const dur = Date.now() - t0;

  // ── Fan-out dedup results + cache ─────────────────────────────────────
  if (dk) {
    const ttl = CACHE_TTL_MS[actions[0]?.type] || 2000;
    try { const p = parseWithRepair(raw, "cache-check"); if (!p?.__clientDisconnected && !p?.error) setCache(dk, raw, ttl); } catch {}
    const inf = _dedupInflight.get(dk);
    _dedupInflight.delete(dk);
    if (inf) {
      relayLog("info", `${logPrefix} DEDUP fan-out ${inf.waiters.length} waiters key=${dk.substring(0, 40)}`);
      inf.waiters.forEach(w => w({ raw }));
    }
  }

  try {
    const parsed = parseWithRepair(raw, `${logPrefix} disconnect-check`);
    if (parsed?.__clientDisconnected) {
      entries.forEach(e => updateActivity(e, { status: "fail", dur, detail: "client disconnected" }));
      return { disconnected: true };
    }
    // Update each pending entry with the desktop result
    entries.forEach((entry, i) => {
      const at = actions[i]?.type;
      const res = parsed?.results?.[i];
      const rd = res?.data;
      const ok = res?.status !== "error" && !res?.error && !rd?.error;
      const detail = resultSummary(at, res ? { results: [res] } : parsed) || (res?.error ? String(res.error).slice(0, 150) : rd?.error ? String(rd.error).slice(0, 150) : ok ? "ok" : "?");
      updateActivity(entry, { status: ok ? "ok" : "fail", dur, human: humanizeAction(at, actions[i], rd), detail });
    });
  } catch {
    entries.forEach(e => updateActivity(e, { status: "ok", dur, detail: "ok" }));
  }
  relayLog("info", `${logPrefix} ←Desktop responded reqId=${requestId.substring(0, 8)}... dur=${dur}ms size=${raw.length}`);
  return { raw };
}
// Build _bridge metadata block for every new endpoint response
function buildBridgeMeta(req, project) {
  const host = req.headers.host || `localhost:${PORT}`;
  const proto = req.headers["x-forwarded-proto"] || "https";
  const base = `${proto}://${host}`;
  // When project is specified, only mark connected if that exact project's client is alive
  const _bcExact = project ? desktopClients.get(project) : null;
  const _bc = (_bcExact?.alive ? _bcExact : null) || findBridgeClient(null);
  const p = project || _bc?.project || null;
  return {
    _bridge: {
      connected: project ? !!(_bcExact?.alive) : !!(_bc?.alive),
      project: p || null,
      ts: Date.now(),
      readyUrls: p ? {
        grokDo:  `${base}/api/grok-do?chain=run:COMMAND|wait:3000|snapshot`,
        grokDoNote: "USE grok-do?chain= for ALL desktop control (browser, apps, shell). Pipe-separated steps: run:CMD|wait:MS|snapshot|click:SEL|nav:URL|eval:JS|type_text:SEL>>>TEXT|screenshot:TITLE|focus:TITLE|launch:PATH|paste:TEXT|keys:KEYS|click_at:X,Y|list_windows|tabs",
        read:    `${base}/api/grok-read?project=${p}&path=FILE`,
        write:   `${base}/api/grok-write?project=${p}&path=FILE&search=OLD&replace=NEW`,
        tree:    `${base}/api/grok-tree?project=${p}`,
        git:     `${base}/api/grok-git?project=${p}&action=status`,
        process: `${base}/api/grok-process?project=${p}&action=list`,
        search:  `${base}/api/grok-search?project=${p}&q=PATTERN`,
        run:     `${base}/api/grok-run?project=${p}&cmd=COMMAND`,
        diag:    `${base}/api/diag?project=${p}`,
      } : null,
    }
  };
}
// Inject _bridge into a raw JSON string from the desktop
function injectBridgeMeta(raw, bridgeMeta, logPrefix) {
  try {
    const parsed = parseWithRepair(raw, `${logPrefix} bridge-meta`);
    return JSON.stringify(Object.assign({}, parsed, bridgeMeta));
  } catch {
    return raw; // never break response if injection fails
  }
}
function wsEncodeFrame(data) {
  const payload = Buffer.from(data, "utf-8");
  const len = payload.length;
  let header;
  if (len < 126) {
    header = Buffer.alloc(2);
    header[0] = 0x81;
    header[1] = len;
  } else if (len < 65536) {
    header = Buffer.alloc(4);
    header[0] = 0x81;
    header[1] = 126;
    header.writeUInt16BE(len, 2);
  } else {
    header = Buffer.alloc(10);
    header[0] = 0x81;
    header[1] = 127;
    header.writeBigUInt64BE(BigInt(len), 2);
  }
  return Buffer.concat([header, payload]);
}
function wsDecodeFrame(buf) {
  if (buf.length < 2) return { data: null, bytesConsumed: 0 };
  const opcode = buf[0] & 0x0f;
  const masked = (buf[1] & 0x80) !== 0;
  let payloadLen = buf[1] & 0x7f;
  let offset = 2;
  if (payloadLen === 126) {
    if (buf.length < 4) return { data: null, bytesConsumed: 0 };
    payloadLen = buf.readUInt16BE(2);
    offset = 4;
  } else if (payloadLen === 127) {
    if (buf.length < 10) return { data: null, bytesConsumed: 0 };
    payloadLen = Number(buf.readBigUInt64BE(2));
    offset = 10;
  }
  if (masked) {
    if (buf.length < offset + 4 + payloadLen) return { data: null, bytesConsumed: 0 };
    const mask = buf.slice(offset, offset + 4);
    offset += 4;
    const payload = Buffer.alloc(payloadLen);
    for (let i = 0; i < payloadLen; i++) {
      payload[i] = buf[offset + i] ^ mask[i % 4];
    }
    return { data: payload.toString("utf-8"), opcode, bytesConsumed: offset + payloadLen };
  }
  if (buf.length < offset + payloadLen) return { data: null, bytesConsumed: 0 };
  return { data: buf.slice(offset, offset + payloadLen).toString("utf-8"), opcode, bytesConsumed: offset + payloadLen };
}
function pushScreenshotAndBroadcast(project, url, capturedAt) {
  if (!screenshotHistory.has(project)) screenshotHistory.set(project, []);
  const hist = screenshotHistory.get(project);
  hist.push({ url, capturedAt });
  if (hist.length > 60) hist.splice(0, hist.length - 60);
  const clients = sseClients.get(project);
  if (!clients || clients.size === 0) return;
  const lastEdit = lastEditByProject.get(project) || null;
  const evt = `event: screenshot\ndata: ${JSON.stringify({ url, capturedAt, lastEdit })}\n\n`;
  for (const r of clients) { try { r.write(evt); } catch { clients.delete(r); } }
}
// findClientForProject: prefer the desktop client registered for this project;
// falls back to any alive client — intentional open-routing for single-desktop setups
// where the desktop may not have sent a project param on WS connect.
// TODO (future hardening): in strict multi-desktop/multi-project environments the
// fallback can route background captures to a non-owning client. When strict per-project
// isolation is needed, remove the second loop and return null if no exact match found.
function findClientForProject(project) {
  if (project) {
    const c = desktopClients.get(project);
    if (c?.alive) return c;
  }
  // Fallback: any alive client (open-routing for single-desktop setups)
  for (const c of desktopClients.values()) {
    if (c.alive) return c;
  }
  return null;
}
function buildZip(files) {
  const _crcTable = (() => {
    const t = new Uint32Array(256);
    for (let i = 0; i < 256; i++) {
      let c = i;
      for (let j = 0; j < 8; j++) c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
      t[i] = c;
    }
    return t;
  })();
  function crc32(buf) {
    let c = 0xffffffff;
    for (let i = 0; i < buf.length; i++) c = (c >>> 8) ^ _crcTable[(c ^ buf[i]) & 0xff];
    return (c ^ 0xffffffff) >>> 0;
  }
  const now = new Date();
  const dosTime = ((now.getHours() << 11) | (now.getMinutes() << 5) | (now.getSeconds() >> 1)) >>> 0;
  const dosDate = (((now.getFullYear() - 1980) << 9) | ((now.getMonth() + 1) << 5) | now.getDate()) >>> 0;
  const localParts = [];
  const centralDirs = [];
  let offset = 0;
  for (const { name, data } of files) {
    const nameBytes = Buffer.from(name, "utf8");
    const raw = Buffer.isBuffer(data) ? data : Buffer.from(data, "utf8");
    const compressed = zlib.deflateRawSync(raw, { level: 6 });
    const crc = crc32(raw);
    const lh = Buffer.alloc(30 + nameBytes.length);
    lh.writeUInt32LE(0x04034b50, 0); lh.writeUInt16LE(20, 4); lh.writeUInt16LE(0, 6);
    lh.writeUInt16LE(8, 8); lh.writeUInt16LE(dosTime, 10); lh.writeUInt16LE(dosDate, 12);
    lh.writeUInt32LE(crc, 14); lh.writeUInt32LE(compressed.length, 18); lh.writeUInt32LE(raw.length, 22);
    lh.writeUInt16LE(nameBytes.length, 26); lh.writeUInt16LE(0, 28);
    nameBytes.copy(lh, 30);
    localParts.push(lh, compressed);
    const cd = Buffer.alloc(46 + nameBytes.length);
    cd.writeUInt32LE(0x02014b50, 0); cd.writeUInt16LE(20, 4); cd.writeUInt16LE(20, 6); cd.writeUInt16LE(0, 8);
    cd.writeUInt16LE(8, 10); cd.writeUInt16LE(dosTime, 12); cd.writeUInt16LE(dosDate, 14);
    cd.writeUInt32LE(crc, 16); cd.writeUInt32LE(compressed.length, 20); cd.writeUInt32LE(raw.length, 24);
    cd.writeUInt16LE(nameBytes.length, 28); cd.writeUInt16LE(0, 30); cd.writeUInt16LE(0, 32);
    cd.writeUInt16LE(0, 34); cd.writeUInt16LE(0, 36); cd.writeUInt32LE(0, 38); cd.writeUInt32LE(offset, 42);
    nameBytes.copy(cd, 46);
    centralDirs.push(cd);
    offset += lh.length + compressed.length;
  }
  const cdBuf = Buffer.concat(centralDirs);
  const eocd = Buffer.alloc(22);
  eocd.writeUInt32LE(0x06054b50, 0); eocd.writeUInt16LE(0, 4); eocd.writeUInt16LE(0, 6);
  eocd.writeUInt16LE(files.length, 8); eocd.writeUInt16LE(files.length, 10);
  eocd.writeUInt32LE(cdBuf.length, 12); eocd.writeUInt32LE(offset, 16); eocd.writeUInt16LE(0, 20);
  return Buffer.concat([...localParts, cdBuf, eocd]);
}
// Detect and fix double-encoded URL params produced by browse_page.
// browse_page re-encodes the entire URL before fetching, so a param value Grok
// already percent-encoded (e.g. %2F for a slash) becomes %252F in the raw URL.
// Node's URLSearchParams decodes once: %252F → %2F. We need one more round.
//
// Detection heuristic: if the URLSearchParams-parsed value still contains any
// %XX sequence (e.g. %2F, %0A, %09, %25...) it was double-encoded.
// This is safe for code content — stray %XX in source code is very rare,
// and the decodeURIComponent call falls back to the original if it throws.
function smartDecode(value) {
  if (!value) return value;
  if (/%[0-9A-Fa-f]{2}/.test(value)) {
    try { return decodeURIComponent(value); } catch { return value; }
  }
  return value;
}

const SKIP_DIRS = new Set(["node_modules", ".pnpm", ".bin", ".git", "dist", ".cache", "__pycache__", ".venv", "build"]);
function walkDir(dir, baseLen, out = []) {
  let entries;
  try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { return out; }
  for (const e of entries) {
    const full = path.join(dir, e.name);
    if (e.isDirectory()) {
      if (!SKIP_DIRS.has(e.name)) walkDir(full, baseLen, out);
    } else if (e.isFile()) {
      try {
        const data = fs.readFileSync(full);
        out.push({ name: full.slice(baseLen).replace(/\\/g, "/"), data });
      } catch {}
    }
  }
  return out;
}
function handleWsUpgrade(req, socket, clientProject) {
  const rawKey = req.headers["sec-websocket-key"] || "";
  const bridgeKey = rawKey.substring(0, 12) || "desktop";
  const acceptKey = crypto
    .createHash("sha1")
    .update(rawKey + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11")
    .digest("base64");
  socket.write(
    "HTTP/1.1 101 Switching Protocols\r\n" +
    "Upgrade: websocket\r\n" +
    "Connection: Upgrade\r\n" +
    `Sec-WebSocket-Accept: ${acceptKey}\r\n` +
    "\r\n"
  );
  // ── TCP-level keepalive: prevent Cloudflare/proxy idle kills ──
  socket.setKeepAlive(true, 5000);
  socket.setNoDelay(true);
  socket.setTimeout(0); // never timeout at TCP level — we handle it ourselves
  const _projectKey = clientProject || "";
  relayLog("info", `Desktop connected${clientProject ? " project=" + clientProject : ""}`);
  pushActivity({ type: "connect", project: clientProject, status: "ok", human: `Desktop connected${clientProject ? " — " + clientProject : ""}`, detail: clientProject || "no project" });
  const existingClient = desktopClients.get(_projectKey);
  if (existingClient) {
    relayLog("info", `Replacing existing desktop connection for project=${_projectKey}`);
    existingClient.alive = false;
    try { existingClient.socket.on("error", () => {}); } catch {}
  }
  const client = { socket, bridgeKey, project: _projectKey, lastPing: Date.now(), alive: true };
  desktopClients.set(_projectKey, client);
  // Flush any commands that were queued while bridge was reconnecting
  flushPhantom(_projectKey, client);
  client.send = (data) => {
    try {
      socket.write(wsEncodeFrame(data));
    } catch (err) {
      relayLog("error", `Send failed key=${bridgeKey.substring(0, 8)}... err=${err.message} — queueing for reconnect`);
      // DON'T mark dead or delete — queue for the reconnect that's coming in <1s
      const phantom = getOrCreatePhantom(_projectKey);
      phantom.queue.push({ data });
    }
  };
  let keepaliveInterval;
  const sendPing = () => {
    if (!client.alive) { clearInterval(keepaliveInterval); return; }
    try {
      socket.write(wsEncodeFrame(JSON.stringify({ type: "ping", ts: Date.now() })));
    } catch {
      // swallow — don't kill client over a failed ping
    }
  };
  sendPing();
  keepaliveInterval = setInterval(sendPing, 5000);
  let buffer = Buffer.alloc(0);
  socket.on("data", (chunk) => {
    buffer = Buffer.concat([buffer, chunk]);
    while (buffer.length > 0) {
      const { data, opcode, bytesConsumed } = wsDecodeFrame(buffer);
      if (data === null) break;
      buffer = buffer.slice(bytesConsumed);
      if (opcode === 0x8) { socket.end(); return; }
      if (opcode === 0x9) {
        const pong = Buffer.alloc(2);
        pong[0] = 0x8a;
        pong[1] = 0;
        try { socket.write(pong); } catch {}
        continue;
      }
      try {
        const msg = parseWithRepair(data, "←Desktop WS");
        client.lastPing = Date.now();
        if (msg.type === "snapshot-response" && msg.requestId) {
          const snapshotResult = msg.snapshot || "Error: Empty snapshot response from desktop.";
          relayLog("info", `←Desktop snapshot-response reqId=${msg.requestId.substring(0, 8)}... snapshotLen=${snapshotResult.length}`);
          // Fan-out: find which project this requestId belongs to
          let fanned = false;
          for (const [proj, ps] of pendingSnapshots) {
            if (ps.requestId === msg.requestId) {
              clearTimeout(ps.timer);
              pendingSnapshots.delete(proj);
              snapshotCache.set(proj, { result: snapshotResult, expiresAt: Date.now() + 15000 });
              relayLog("info", `SNAPSHOT fan-out to ${ps.waiters.size} waiter(s) project=${proj}`);
              for (const r of ps.waiters) {
                if (!r.writableEnded) {
                  r.writeHead(200, { "Content-Type": "text/plain; charset=utf-8", "Access-Control-Allow-Origin": "*" });
                  r.end(snapshotResult);
                }
              }
              fanned = true;
              break;
            }
          }
          if (!fanned) {
            relayLog("warn", `←Desktop snapshot-response reqId=${msg.requestId.substring(0, 8)}... NO PENDING SNAPSHOT — already timed out or duplicate`);
          }
        } else if (msg.type === "sandbox-execute-response" && msg.requestId) {
          // ── Intercept screenshotBase64: store in relay, replace with relay-served URL ──
          let _rawResult = msg.result || {};
          try {
            const _d = _rawResult?.results?.[0]?.data;
            if (_d?.screenshotBase64) {
              // Resolve project from the pending screenshot entry (more reliable than clientProject which may be empty)
              let _proj = clientProject || "";
              for (const [sk, sc] of pendingScreenshots) {
                if (sc.requestId === msg.requestId) { _proj = sk.split(":")[0] || _proj; break; }
              }
              if (!_proj) _proj = "unknown";
              const _proto = req.headers["x-forwarded-proto"] || "https";
              const _wsHost = req.headers.host || `localhost:${PORT}`;
              screenshotDataCache.set(_proj, { base64: _d.screenshotBase64, mimeType: _d.mimeType || "image/png", capturedAt: Date.now() });
              const _relayUrl = `${_proto}://${_wsHost}/api/screenshot-data/${_proj}`;
              _d.screenshotUrl = _relayUrl;
              _d.relayServed = true;
              delete _d.screenshotBase64; // strip large base64 before forwarding to Grok
              const _ssBytes = screenshotDataCache.get(_proj)?.base64?.length || 0;
              relayLog("info", `SCREENSHOT-RELAY stored project=${_proj} bytes=${_ssBytes} url=${_relayUrl}`);
              // Rate-limit screenshot entries in the activity log (auto shots fire every 1s — only log 1 per 30s)
              const _ssLastLog = _lastScreenshotLog.get(_proj) || 0;
              if (Date.now() - _ssLastLog > 30000) {
                _lastScreenshotLog.set(_proj, Date.now());
                pushActivity({ type: "screenshot_preview", project: _proj, status: "ok", human: `[${_proj}] Screenshot captured`, detail: `${Math.round(_ssBytes * 3/4 / 1024)} KB PNG` });
              }
            }
          } catch (e) { relayLog("warn", `SCREENSHOT-RELAY intercept error: ${e.message}`); }
          const resultStr = JSON.stringify(_rawResult);
          relayLog("info", `←Desktop sandbox-execute-response reqId=${msg.requestId.substring(0, 8)}... resultLen=${resultStr.length} preview=${resultStr.substring(0, 120)}`);
          let handledByScreenshot = false;
          for (const [sk, sc] of pendingScreenshots) {
            if (sc.requestId === msg.requestId) {
              clearTimeout(sc.timer);
              pendingScreenshots.delete(sk);
              screenshotCache.set(sk, { result: resultStr, expiresAt: Date.now() + 30000 });
              // Extract screenshotUrl for plain-text / redirect formats and last-good cache
              let screenshotUrl = null;
              try {
                const parsed = JSON.parse(resultStr);
                screenshotUrl = parsed?.results?.[0]?.data?.screenshotUrl || null;
              } catch {}
              const project = sk.split(":")[0];
              if (screenshotUrl) {
                const _capturedAt = Date.now();
                screenshotLastGood.set(project, { url: screenshotUrl, capturedAt: _capturedAt });
                relayLog("info", `SCREENSHOT last-good stored project=${project} url=${screenshotUrl}`);
                pushScreenshotAndBroadcast(project, screenshotUrl, _capturedAt);
              }
              relayLog("info", `SCREENSHOT fan-out to ${sc.waiters.size} waiter(s) key=${sk}`);
              for (const w of sc.waiters) {
                const r = w.res || w;
                const fmt = w.format || "json";
                if (r.writableEnded) continue;
                try {
                  if (fmt === "text") {
                    const url = screenshotUrl || (screenshotLastGood.get(project)?.url) || "";
                    r.writeHead(200, { "Content-Type": "text/plain", "Access-Control-Allow-Origin": "*" });
                    r.end(url || "Error: no screenshot URL available");
                  } else if (fmt === "redirect") {
                    const url = screenshotUrl || (screenshotLastGood.get(project)?.url) || null;
                    if (url) {
                      r.writeHead(302, { "Location": url, "Access-Control-Allow-Origin": "*" });
                      r.end();
                    } else {
                      r.writeHead(200, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" });
                      r.end(JSON.stringify({ success: true, status: "processing", message: "Screenshot is being captured — try again shortly." }));
                    }
                  } else {
                    r.writeHead(200, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" });
                    r.end(resultStr);
                  }
                } catch {}
              }
              handledByScreenshot = true;
              break;
            }
          }
          if (!handledByScreenshot) {
          const pending = pendingSandboxRelayRequests.get(msg.requestId);
          if (pending) {
            clearTimeout(pending.timer);
            pendingSandboxRelayRequests.delete(msg.requestId);
            pending.resolve(JSON.stringify(msg.result || { error: "Empty sandbox response from desktop." }));
          } else {
            relayLog("warn", `←Desktop sandbox-execute-response reqId=${msg.requestId.substring(0, 8)}... NO PENDING REQUEST — already timed out`);
          }
          }
        } else if (msg.type === "console-logs-response" && msg.requestId) {
          relayLog("info", `←Desktop console-logs-response reqId=${msg.requestId.substring(0, 8)}...`);
          const pending = pendingConsoleLogRequests.get(msg.requestId);
          if (pending) {
            clearTimeout(pending.timer);
            pendingConsoleLogRequests.delete(msg.requestId);
            pending.resolve(msg.logs || { stdout: "", stderr: "", entries: [] });
          } else {
            relayLog("warn", `←Desktop console-logs-response reqId=${msg.requestId.substring(0, 8)}... NO PENDING REQUEST — already timed out`);
          }
        } else if (msg.type === "ping") {
          relayLog("info", `←Desktop ping key=${bridgeKey.substring(0, 8)}... sending pong`);
          client.send(JSON.stringify({ type: "pong" }));
        } else if (msg.type === "pong") {
          relayLog("info", `←Desktop pong key=${bridgeKey.substring(0, 8)}...`);
        } else if (msg.type === "hello") {
          if (msg.desktopName) client.desktopName = msg.desktopName;
          if (msg.projectName) client.projectName = msg.projectName;
          if (msg.previewPort) client.previewPort = msg.previewPort;
          relayLog("info", `←Desktop hello desktop=${msg.desktopName || "?"} project=${msg.projectName || "?"} port=${msg.previewPort || "none"}`);
        } else {
          relayLog("warn", `←Desktop UNKNOWN msg type="${msg.type}" reqId=${msg.requestId || "(none)"} keys=${Object.keys(msg).join(",")}`);
        }
      } catch (parseErr) {
        relayLog("error", `←Desktop JSON parse error: ${parseErr.message} raw(200)=${data.substring(0, 200)}`);
      }
    }
  });
  socket.on("close", () => {
    relayLog("warn", `Desktop socket closed key=${bridgeKey.substring(0, 8)}... — NOT deleting client, connector auto-reconnects in <250ms`);
    client.alive = false;
    client.reconnecting = true;
    client.disconnectedAt = Date.now();
    clearInterval(keepaliveInterval);
    getOrCreatePhantom(_projectKey);
  });
  socket.on("error", (err) => {
    relayLog("warn", `Socket error key=${bridgeKey.substring(0, 8)}... err=${err.message} — NOT deleting client, connector auto-reconnects in <250ms`);
    client.alive = false;
    client.reconnecting = true;
    client.disconnectedAt = Date.now();
    clearInterval(keepaliveInterval);
    getOrCreatePhantom(_projectKey);
  });
}
const server = http.createServer({ maxHeaderSize: 1048576 }, async (req, res) => {
  const url = new URL(req.url || "/", `http://${req.headers.host || "localhost"}`);
  const pathname = url.pathname;
  const silent = pathname === "/" || pathname === "/api/status" || pathname === "/api/bridge-status" || pathname === "/health" || pathname === "/healthz";
  if (!silent) {
    relayLog("info", `HTTP ${req.method} ${pathname} connected=${desktopClients.size > 0 ? "yes" : "no"}(${[...desktopClients.keys()].join(",") || "none"})`);
  }
  if (req.method === "OPTIONS") {
    res.writeHead(204, {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
    });
    res.end();
    return;
  }
  if (pathname === "/health" || pathname === "/healthz") {
    const _hClients = [...desktopClients.values()].filter(c => c.alive);
    sendJson(res, {
      status: "ok",
      service: "Lamby Bridge Relay",
      bridge: _hClients.length > 0 ? "connected" : "waiting-for-desktop",
      connectedClients: _hClients.length,
      uptime: process.uptime(),
    });
    return;
  }
  if (pathname === "/api/status") {
    const _stClients = [...desktopClients.values()].filter(c => c.alive);
    sendJson(res, {
      status: "ok",
      bridge: _stClients.length > 0 ? "connected" : "waiting-for-desktop",
      connectedClients: _stClients.length,
      uptime: process.uptime(),
      clients: _stClients.map(c => ({
        connected: c.alive,
        lastPing: c.lastPing,
        desktopName: c.desktopName || null,
        project: c.project || null,
        projectName: c.projectName || c.project || null,
        previewPort: c.previewPort || null,
      })),
      auditTotal: sandboxAuditLog.length,
      recentAudit: sandboxAuditLog.slice(-5),
    });
    return;
  }
  if (pathname === "/") {
    const host = req.headers.host || `localhost:${PORT}`;
    const protocol = req.headers["x-forwarded-proto"] || "https";
    const baseUrl = `${protocol}://${host}`;
    const html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Lamby Bridge Relay — Activity</title>
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      background: #0d1117;
      color: #e6edf3;
      min-height: 100vh;
      padding: 24px 16px;
    }
    .container { max-width: 900px; margin: 0 auto; }
    header { display: flex; align-items: center; gap: 14px; margin-bottom: 20px; }
    .logo {
      width: 42px; height: 42px; border-radius: 10px;
      background: linear-gradient(135deg, #7c3aed, #2563eb);
      display: flex; align-items: center; justify-content: center;
      font-size: 20px; flex-shrink: 0;
    }
    h1 { font-size: 19px; font-weight: 600; color: #f0f6fc; }
    h1 span { font-size: 12px; font-weight: 400; color: #8b949e; display: block; margin-top: 2px; }
    .badge {
      margin-left: auto; padding: 4px 12px; border-radius: 20px;
      font-size: 12px; font-weight: 600; letter-spacing: 0.04em; flex-shrink: 0;
    }
    .badge.connected { background: #0d3a22; color: #3fb950; border: 1px solid #238636; }
    .badge.waiting { background: #2d1f00; color: #e3b341; border: 1px solid #9e6a03; }
    .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 12px; }
    @media(max-width:600px){ .grid { grid-template-columns: 1fr; } }
    .card { background: #161b22; border: 1px solid #30363d; border-radius: 12px; padding: 16px 18px; }
    .card-title { font-size: 10px; font-weight: 700; letter-spacing: .09em; text-transform: uppercase; color: #8b949e; margin-bottom: 10px; }
    .stat-row { display: flex; gap: 20px; flex-wrap: wrap; }
    .stat { flex: 1; min-width: 70px; }
    .stat-value { font-size: 26px; font-weight: 700; color: #f0f6fc; line-height: 1; }
    .stat-label { font-size: 11px; color: #8b949e; margin-top: 3px; }
    .sse-dot { width: 8px; height: 8px; border-radius: 50%; background: #e3b341; display: inline-block; margin-right: 5px; transition: background .3s; vertical-align: middle; }
    .sse-dot.live { background: #3fb950; animation: pulse 2s infinite; }
    @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:.5} }
    .key-box {
      background: #0d1117; border: 1px solid #30363d; border-radius: 8px;
      padding: 9px 12px; font-family: monospace; font-size: 12px;
      color: #79c0ff; display: flex; align-items: center; justify-content: space-between;
      gap: 8px; word-break: break-all; margin-bottom: 8px;
    }
    .key-box:last-child { margin-bottom: 0; }
    .copy-btn { background: #21262d; border: 1px solid #30363d; border-radius: 5px; color: #c9d1d9; font-size: 11px; padding: 3px 9px; cursor: pointer; flex-shrink: 0; transition: background 0.15s; }
    .copy-btn:hover { background: #30363d; }
    .copy-btn.copied { color: #3fb950; border-color: #238636; }
    .feed-header { display: flex; align-items: center; gap: 8px; margin-bottom: 10px; flex-wrap: wrap; }
    .feed-title { font-size: 10px; font-weight: 700; letter-spacing: .09em; text-transform: uppercase; color: #8b949e; margin-right: auto; }
    .filter-tabs { display: flex; gap: 4px; flex-wrap: wrap; }
    .tab { font-size: 11px; padding: 3px 10px; border-radius: 20px; cursor: pointer; border: 1px solid #30363d; background: transparent; color: #8b949e; transition: all .15s; }
    .tab:hover { border-color: #58a6ff; color: #58a6ff; }
    .tab.active { background: #1f2937; border-color: #58a6ff; color: #e6edf3; }
    .tab.err { color: #f85149; border-color: #f8514944; }
    .tab.err.active { background: #2d0f0e; border-color: #f85149; color: #f85149; }
    .feed-controls { display: flex; gap: 6px; align-items: center; }
    .ctrl-btn { font-size: 11px; padding: 3px 9px; border-radius: 6px; cursor: pointer; border: 1px solid #30363d; background: #21262d; color: #8b949e; transition: all .15s; }
    .ctrl-btn:hover { border-color: #8b949e; color: #e6edf3; }
    .feed { font-size: 12px; font-family: monospace; max-height: 680px; overflow-y: auto; background: #0d1117; border: 1px solid #21262d; border-radius: 8px; }
    .feed.paused { border-color: #9e6a03; }
    .entry { display: grid; grid-template-columns: 62px 20px 1fr auto; gap: 0 8px; padding: 6px 12px; border-bottom: 1px solid #161b22; align-items: start; cursor: pointer; transition: background .1s; }
    .entry:last-child { border-bottom: none; }
    .entry:hover { background: #161b22; }
    .entry.expanded { background: #161b22; }
    .entry-ts { color: #484f58; font-size: 10px; padding-top: 2px; white-space: nowrap; }
    .entry-icon { font-size: 12px; padding-top: 1px; }
    .entry-body { min-width: 0; }
    .entry-human { color: #e6edf3; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; font-size: 12px; }
    .entry-detail { color: #8b949e; font-size: 11px; margin-top: 1px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .entry-dur { color: #484f58; font-size: 10px; white-space: nowrap; padding-top: 2px; text-align: right; }
    .entry-expand { display: none; margin-top: 8px; padding: 8px; background: #0a0d11; border-radius: 6px; border: 1px solid #21262d; white-space: pre-wrap; word-break: break-all; color: #8b949e; font-size: 11px; grid-column: 1 / -1; max-height: 300px; overflow-y: auto; }
    .entry.expanded .entry-expand { display: block; }
    .s-ok    .entry-human { color: #e6edf3; }
    .s-fail  .entry-human { color: #f85149; }
    .s-warn  .entry-human { color: #e3b341; }
    .s-pending .entry-human { color: #8b949e; }
    .s-ok    .entry-icon::after { content: "✅"; }
    .s-fail  .entry-icon::after { content: "❌"; }
    .s-warn  .entry-icon::after { content: "⚠"; }
    .s-pending .entry-icon::after { content: "⏳"; }
    .s-connect .entry-icon::after { content: "🔌"; }
    .s-connect .entry-human { color: #3fb950; }
    .s-disconnect .entry-icon::after { content: "🔌"; }
    .s-disconnect .entry-human { color: #e3b341; }
    .empty-feed { color: #484f58; font-size: 12px; font-style: italic; text-align: center; padding: 40px 16px; }
    .client-row { display: flex; align-items: center; gap: 10px; padding: 7px 0; border-bottom: 1px solid #21262d; font-size: 13px; }
    .client-row:last-child { border-bottom: none; }
    .dot { width: 8px; height: 8px; border-radius: 50%; background: #3fb950; flex-shrink: 0; animation: pulse 2s infinite; }
    .client-key { font-family: monospace; color: #79c0ff; }
    .client-snap { font-family: monospace; color: #8b949e; font-size: 12px; margin-left: auto; }
    .empty { color: #8b949e; font-size: 13px; font-style: italic; }
    footer { text-align: center; color: #484f58; font-size: 11px; margin-top: 20px; }
    .page-nav { display: flex; gap: 6px; margin-bottom: 10px; }
    .page-tab { font-size: 12px; font-weight: 600; padding: 5px 16px; border-radius: 8px; cursor: pointer; border: 1px solid #30363d; background: transparent; color: #8b949e; transition: all .15s; letter-spacing: .02em; }
    .page-tab:hover { border-color: #58a6ff; color: #58a6ff; }
    .page-tab.active { background: #1f2937; border-color: #58a6ff; color: #e6edf3; }
    #journal-panel { display: none; }
    .journal-card { background: #161b22; border: 1px solid #30363d; border-radius: 12px; padding: 16px 18px; }
    .journal-toolbar { display: flex; align-items: center; gap: 8px; margin-bottom: 12px; }
    .journal-title { font-size: 10px; font-weight: 700; letter-spacing: .09em; text-transform: uppercase; color: #8b949e; flex: 1; }
    .journal-count { font-size: 11px; color: #484f58; }
    .journal-feed { max-height: 680px; overflow-y: auto; }
    .jentry { border-bottom: 1px solid #21262d; padding: 10px 4px; }
    .jentry:last-child { border-bottom: none; }
    .jentry-header { display: flex; align-items: baseline; gap: 8px; margin-bottom: 4px; }
    .jentry-from { font-size: 11px; font-weight: 700; color: #79c0ff; text-transform: uppercase; letter-spacing: .05em; }
    .jentry-tag { font-size: 10px; color: #3fb950; background: #0d3a22; border: 1px solid #238636; border-radius: 10px; padding: 1px 7px; }
    .jentry-ts { font-size: 10px; color: #484f58; margin-left: auto; font-family: monospace; }
    .jentry-note { font-size: 13px; color: #e6edf3; line-height: 1.5; white-space: pre-wrap; word-break: break-word; }
    .journal-empty { color: #484f58; font-size: 13px; font-style: italic; text-align: center; padding: 40px 16px; }
  </style>
</head>
<body>
  <div class="container">
    <header>
      <div class="logo">🌉</div>
      <div>
        <h1>Lamby Bridge Relay <span>Live Activity Dashboard</span></h1>
      </div>
      <div id="badge" class="badge waiting">Waiting</div>
    </header>

    <div class="grid">
      <div class="card">
        <div class="card-title">Status</div>
        <div class="stat-row">
          <div class="stat"><div class="stat-value" id="clients">—</div><div class="stat-label">Connected</div></div>
          <div class="stat"><div class="stat-value" id="uptime">—</div><div class="stat-label">Uptime</div></div>
          <div class="stat"><div class="stat-value" id="total-actions">0</div><div class="stat-label">Total actions</div></div>
          <div class="stat"><div class="stat-value" id="fail-count" style="color:#f85149">0</div><div class="stat-label">Failures</div></div>
        </div>
      </div>
      <div class="card">
        <div class="card-title">Connected Desktops</div>
        <div id="clients-list"><span class="empty">No desktops connected</span></div>
      </div>
    </div>

    <div class="card" style="margin-bottom:12px; border-color:#7c3aed44; background:linear-gradient(135deg,#1a1030,#161b22);">
      <div class="card-title" style="color:#d2a8ff;">For Grok — browse this to get command docs:</div>
      <div class="key-box">
        <span id="grok-docs-url">${baseUrl}/api/grok</span>
        <button class="copy-btn" onclick="copy(this,document.getElementById('grok-docs-url').textContent)">Copy</button>
      </div>
      <div class="key-box">
        <span id="grok-ref-url">${baseUrl}/api/grok-reference</span>
        <button class="copy-btn" onclick="copy(this,document.getElementById('grok-ref-url').textContent)">Copy</button>
      </div>
      <div class="key-box">
        <span>WebSocket: wss://${host}/bridge-ws?project=YOUR_PROJECT</span>
        <button class="copy-btn" onclick="copy(this,'wss://${host}/bridge-ws?project=YOUR_PROJECT')">Copy</button>
      </div>
    </div>

    <div class="page-nav">
      <button class="page-tab active" onclick="showPage('activity',this)">Activity</button>
      <button class="page-tab" onclick="showPage('journal',this)">Collaboration Journal</button>
    </div>

    <div id="activity-panel">
    <div class="card" style="padding-bottom:0">
      <div class="feed-header">
        <div class="feed-title">
          <span class="sse-dot" id="sse-dot"></span>
          Live Activity Feed
        </div>
        <div class="filter-tabs">
          <button class="tab active" onclick="setFilter('all',this)">All</button>
          <button class="tab err" onclick="setFilter('fail',this)">Errors</button>
          <button class="tab" onclick="setFilter('warn',this)">Warnings</button>
          <button class="tab" onclick="setFilter('file',this)">Files</button>
          <button class="tab" onclick="setFilter('screenshot_preview',this)">Screenshots</button>
          <button class="tab" onclick="setFilter('command',this)">Commands</button>
          <button class="tab" onclick="setFilter('connect',this)">Connections</button>
        </div>
        <div class="feed-controls">
          <button class="ctrl-btn" onclick="clearFeed()">Clear</button>
          <button class="ctrl-btn" id="pause-btn" onclick="togglePause()">Pause</button>
        </div>
      </div>
      <div class="feed" id="feed">
        <div class="empty-feed">Connecting to live stream…</div>
      </div>
    </div>

    </div><!-- /activity-panel -->

    <div id="journal-panel">
      <div class="journal-card">
        <div class="journal-toolbar">
          <div class="journal-title">Collaboration Journal</div>
          <span class="journal-count" id="journal-count"></span>
          <button class="ctrl-btn" onclick="clearJournal()">Clear All</button>
          <button class="ctrl-btn" onclick="refreshJournal()">Refresh</button>
        </div>
        <div class="journal-feed" id="journal-feed">
          <div class="journal-empty">No journal entries yet. Grok writes here via /api/coord.</div>
        </div>
      </div>
    </div><!-- /journal-panel -->

    <footer style="margin-top:14px">
      <a href="/api/download/source.zip" download="lamby-bridge-source.zip" style="background:#238636;color:#fff;text-decoration:none;padding:4px 12px;border-radius:5px;font-size:12px;font-weight:600;margin-right:8px">⬇ Bridge Source ZIP</a>
      <a href="/api/download/app.zip" download="lamby-app-source.zip" style="background:#1f6feb;color:#fff;text-decoration:none;padding:4px 12px;border-radius:5px;font-size:12px;font-weight:600;margin-right:8px">⬇ Lamby App Source ZIP</a>
      <a href="/api/grok-chat-prompt" target="_blank" style="background:#6e40c9;color:#fff;text-decoration:none;padding:4px 12px;border-radius:5px;font-size:12px;font-weight:600;margin-right:12px">📋 Grok Chat Prompt</a>
      &nbsp;·&nbsp; Lamby Bridge Relay &nbsp;·&nbsp; Zero dependencies
    </footer>
  </div>
  <script>
    function copy(btn, text) {
      navigator.clipboard.writeText(text).then(() => {
        btn.textContent = "Copied!"; btn.classList.add("copied");
        setTimeout(() => { btn.textContent = "Copy"; btn.classList.remove("copied"); }, 1500);
      });
    }
    function fmt(s) {
      const h=Math.floor(s/3600),m=Math.floor((s%3600)/60),ss=Math.floor(s%60);
      return h?h+"h "+m+"m":m?m+"m "+ss+"s":ss+"s";
    }
    function tsStr(ms) {
      return new Date(ms).toLocaleTimeString([],{hour12:false,hour:"2-digit",minute:"2-digit",second:"2-digit"});
    }
    function durStr(ms) {
      if(!ms||ms<1) return "";
      if(ms<1000) return ms+"ms";
      return (ms/1000).toFixed(1)+"s";
    }
    function esc(s) {
      return String(s||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
    }

    let entries=[], filter="all", paused=false, stickBottom=true;
    const MAX_ENTRIES=3000;
    const FILE_TYPES=new Set(["read_file","read_multiple_files","write_file","write_file_chunk","search_replace","apply_patch","list_tree"]);
    const CMD_TYPES=new Set(["run_command","git_status","git_commit","git_diff","git_log","git_push","build_project","type_check","install_deps","add_dependency","remove_dependency"]);

    function matches(e) {
      if(filter==="all") return true;
      if(filter==="fail") return e.status==="fail";
      if(filter==="warn") return e.status==="warn";
      if(filter==="screenshot_preview") return e.type==="screenshot_preview";
      if(filter==="file") return FILE_TYPES.has(e.type);
      if(filter==="command") return CMD_TYPES.has(e.type);
      if(filter==="connect") return e.type==="connect"||e.type==="disconnect";
      return true;
    }
    function sClass(e) {
      if(e.type==="connect") return "s-connect";
      if(e.type==="disconnect") return "s-disconnect";
      return "s-"+(e.status||"pending");
    }
    function makeRow(e) {
      const expandData = [];
      if(e.action && Object.keys(e.action).length>0) {
        const compact = Object.assign({},e.action);
        delete compact.content; // skip large file content in expand view
        expandData.push("Request: "+JSON.stringify(compact,null,2).slice(0,2000));
      }
      if(e.detail && e.detail.length>0) expandData.push("Result:  "+e.detail);
      const expandHtml = esc(expandData.join(" ▸ "));
      return '<div class="entry '+sClass(e)+'" id="e-'+esc(e.id)+'" onclick="this.classList.toggle(\\'expanded\\')">'
        +'<div class="entry-ts">'+tsStr(e.ts)+'</div>'
        +'<div class="entry-icon"></div>'
        +'<div class="entry-body">'
          +'<div class="entry-human">'+esc(e.human||e.type)+'</div>'
          +(e.detail?'<div class="entry-detail">'+esc(e.detail)+'</div>':"")
        +'</div>'
        +'<div class="entry-dur">'+durStr(e.dur)+'</div>'
        +'<div class="entry-expand">'+expandHtml+'</div>'
        +'</div>';
    }

    let rAF=false;
    function schedRender() { if(!rAF){rAF=true;requestAnimationFrame(doRender);} }
    function doRender() {
      rAF=false;
      if(paused) return;
      const feed=document.getElementById("feed");
      const vis=entries.filter(matches);
      if(vis.length===0){
        feed.innerHTML='<div class="empty-feed">No entries match the current filter.</div>';
        updateStats(); return;
      }
      const existIds=new Set([...feed.querySelectorAll(".entry[id]")].map(el=>el.id.replace("e-","")));
      if(existIds.size===0||vis.length>existIds.size+100){
        // full rebuild
        feed.innerHTML=vis.map(makeRow).join("");
      } else {
        // incremental: append new, update changed
        const visSet=new Set(vis.map(e=>e.id));
        // remove stale
        for(const el of feed.querySelectorAll(".entry[id]")){
          if(!visSet.has(el.id.replace("e-",""))) el.remove();
        }
        for(const e of vis){
          if(!existIds.has(e.id)){
            feed.insertAdjacentHTML("beforeend",makeRow(e));
          } else {
            const el=document.getElementById("e-"+e.id);
            if(el){
              const wasExpanded=el.classList.contains("expanded");
              const fresh=document.createElement("div");
              fresh.innerHTML=makeRow(e);
              const nr=fresh.firstChild;
              if(wasExpanded) nr.classList.add("expanded");
              el.replaceWith(nr);
            }
          }
        }
      }
      if(stickBottom) feed.scrollTop=feed.scrollHeight;
      updateStats();
    }
    function updateStats() {
      document.getElementById("total-actions").textContent=entries.length;
      const fc=entries.filter(e=>e.status==="fail").length;
      const wc=entries.filter(e=>e.status==="warn").length;
      document.getElementById("fail-count").textContent=fc+(wc?" / "+wc+"w":"");
    }

    function connectSSE() {
      const dot=document.getElementById("sse-dot");
      dot.className="sse-dot";
      const since=entries.length>0?entries[entries.length-1].ts:0;
      const src=new EventSource("/api/activity-stream?since="+since);
      src.onopen=()=>{ dot.className="sse-dot live"; };
      src.onmessage=(ev)=>{
        try {
          const {event,entry}=JSON.parse(ev.data);
          if(event==="new"){
            entries.push(entry);
            if(entries.length>MAX_ENTRIES) entries.splice(0,entries.length-MAX_ENTRIES);
          } else if(event==="update"){
            for(var _i=entries.length-1;_i>=0;_i--){if(entries[_i].id===entry.id){entries[_i]=entry;break;}}
          }
          schedRender();
        } catch(e){}
      };
      src.onerror=()=>{ dot.className="sse-dot"; src.close(); setTimeout(connectSSE,3000); };
      const feed=document.getElementById("feed");
      feed.addEventListener("scroll",()=>{
        stickBottom=feed.scrollTop+feed.clientHeight>=feed.scrollHeight-40;
      });
    }

    async function refreshStatus() {
      try {
        const d=await(await fetch("/api/status")).json();
        const conn=d.connectedClients>0;
        const badge=document.getElementById("badge");
        badge.textContent=conn?d.connectedClients+" Connected":"Waiting";
        badge.className="badge "+(conn?"connected":"waiting");
        document.getElementById("clients").textContent=d.connectedClients;
        document.getElementById("uptime").textContent=fmt(d.uptime);
        const cl=document.getElementById("clients-list");
        cl.innerHTML=d.clients&&d.clients.length
          ?d.clients.map(c=>'<div class="client-row"><div class="dot"></div><span class="client-key">'+(c.desktopName||"Lamby Desktop")+'<span style="margin-left:6px;opacity:.55;font-size:10px">› '+(c.projectName||c.project||"—")+(c.previewPort?' :'+c.previewPort:'')+'</span></span></div>').join("")
          :'<span class="empty">No desktops connected</span>';
      } catch(e){}
    }

    function setFilter(f,btn){
      filter=f;
      document.querySelectorAll(".tab").forEach(t=>t.classList.remove("active"));
      btn.classList.add("active");
      schedRender();
    }
    function clearFeed(){ entries=[]; schedRender(); }
    function togglePause(){
      paused=!paused;
      document.getElementById("pause-btn").textContent=paused?"Resume":"Pause";
      document.getElementById("feed").classList.toggle("paused",paused);
      if(!paused) schedRender();
    }

    connectSSE();
    refreshStatus();
    setInterval(refreshStatus,5000);

    // --- Journal (coord board) ---
    let currentPage = "activity";
    let journalAutoRefresh = null;

    function showPage(page, btn) {
      currentPage = page;
      document.querySelectorAll(".page-tab").forEach(t => t.classList.remove("active"));
      btn.classList.add("active");
      const ap = document.getElementById("activity-panel");
      const jp = document.getElementById("journal-panel");
      if (page === "journal") {
        ap.style.display = "none";
        jp.style.display = "block";
        refreshJournal();
        if (!journalAutoRefresh) journalAutoRefresh = setInterval(refreshJournal, 5000);
      } else {
        ap.style.display = "block";
        jp.style.display = "none";
        if (journalAutoRefresh) { clearInterval(journalAutoRefresh); journalAutoRefresh = null; }
      }
    }

    function tsRelative(ms) {
      const diff = Math.floor((Date.now() - ms) / 1000);
      if (diff < 60) return diff + "s ago";
      if (diff < 3600) return Math.floor(diff/60) + "m ago";
      return Math.floor(diff/3600) + "h ago";
    }

    async function refreshJournal() {
      try {
        const d = await (await fetch("/api/coord")).json();
        const feed = document.getElementById("journal-feed");
        const count = document.getElementById("journal-count");
        const items = (d.items || []).slice().reverse(); // newest first
        count.textContent = d.total + " total";
        if (items.length === 0) {
          feed.innerHTML = '<div class="journal-empty">No journal entries yet. Grok writes here via /api/coord.</div>';
          return;
        }
        feed.innerHTML = items.map(e =>
          '<div class="jentry">'
          + '<div class="jentry-header">'
          + '<span class="jentry-from">' + esc(e.from || "grok") + '</span>'
          + (e.tag ? '<span class="jentry-tag">' + esc(e.tag) + '</span>' : "")
          + '<span class="jentry-ts">' + tsRelative(e.ts) + ' &nbsp;·&nbsp; ' + tsStr(e.ts) + '</span>'
          + '</div>'
          + '<div class="jentry-note">' + esc(e.note) + '</div>'
          + '</div>'
        ).join("");
      } catch(err) {}
    }

    async function clearJournal() {
      try { await fetch("/api/coord?clear=1"); refreshJournal(); } catch(err) {}
    }
  </script>
</body>
</html>`;

    res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
    res.end(html);
    return;
  }
  if (pathname === "/api/connectivity-test") {
    const ip = req.headers["x-forwarded-for"] || req.socket?.remoteAddress || "?";
    const ua = req.headers["user-agent"] || "";
    relayLog("info", `CONNECTIVITY-TEST from ip=${ip} ua=${ua.substring(0, 60)}`);
    sendJson(res, { ok: true, relay: "lamby-bridge", ts: Date.now(), ip, wsUrl: `wss://${req.headers.host || "bridge-relay.replit.app"}/bridge-ws?project=YOUR_PROJECT` });
    return;
  }
  if (pathname === "/api/remote-update" && req.method === "POST") {
    let body = "";
    req.on("data", chunk => body += chunk);
    req.on("end", () => {
      try {
        const { file, content } = JSON.parse(body);
        if (!file || !content) { sendJson(res, { error: "requires file and content" }); return; }
        const projectRoot = path.resolve(path.dirname(process.argv[1]), "..");
        const allowed = ["server/bridge-relay-local.cjs", "server/sandbox-dispatcher.cjs", "server/bridge-connector.cjs",
          "public/grok-prompt-template.txt", "public/grok-lamby-knowledge.txt", "public/grok-desktop-playbook.txt",
          "electron-browser/src/main.js", "electron-browser/src/local-server.js", "electron-browser/src/claw-tools.js",
          "electron-browser/src/grok-ipc-handlers.js", "electron-browser/src/claw-ipc-handlers.js",
          "electron-browser/src/anthropic-compat.js", "electron-browser/src/prompt-formatter.js", "lamby-bridge/index.js"];
        if (!allowed.includes(file)) { sendJson(res, { error: `File not in allowed list: ${file}` }); return; }
        const dest = path.join(projectRoot, file);
        const dir = path.dirname(dest);
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
        fs.writeFileSync(dest, content, "utf8");
        const size = fs.statSync(dest).size;
        relayLog("info", `REMOTE-UPDATE: ${file} updated (${size} bytes)`);
        sendJson(res, { success: true, file, size, message: `${file} updated (${size} bytes). Restart relay to apply changes to bridge-relay-local.cjs.` });
      } catch (e) { sendJson(res, { error: e.message }); }
    });
    return;
  }
  if (pathname === "/api/remote-update" && req.method === "GET") {
    const fileParam = url.searchParams.get("file");
    const projectRoot = path.resolve(path.dirname(process.argv[1]), "..");
    if (fileParam === "status") {
      const relay = path.join(projectRoot, "server/bridge-relay-local.cjs");
      const relaySize = fs.existsSync(relay) ? fs.statSync(relay).size : 0;
      sendJson(res, { success: true, relaySize, projectRoot, testMode: _testMode });
      return;
    }
    sendJson(res, { success: true, endpoint: "/api/remote-update", method: "POST", body: '{"file":"server/bridge-relay-local.cjs","content":"..."}', allowedFiles: 14 });
    return;
  }
  if (pathname === "/api/download/source.zip") {
    try {
      const __dir = path.dirname(new URL(`file://${process.argv[1]}`).pathname);
      const projectRoot = path.resolve(__dir, "..");
      const readFrom = (relPath) => { try { return fs.readFileSync(path.join(projectRoot, relPath)); } catch { return Buffer.alloc(0); } };
      const filesToBundle = [
        "server/bridge-relay-local.cjs",
        "server/sandbox-dispatcher.cjs",
        "server/bridge-connector.cjs",
        "lamby-bridge/index.js",
        "public/grok-prompt-template.txt",
        "public/grok-lamby-knowledge.txt",
        "public/grok-desktop-playbook.txt",
        "electron-browser/src/main.js",
        "electron-browser/src/local-server.js",
        "electron-browser/src/claw-tools.js",
        "electron-browser/src/grok-ipc-handlers.js",
        "electron-browser/src/claw-ipc-handlers.js",
        "electron-browser/src/anthropic-compat.js",
        "electron-browser/src/prompt-formatter.js",
      ];
      const zipFiles = filesToBundle.map(f => ({ name: f, data: readFrom(f) })).filter(f => f.data.length > 0);
      if (!zipFiles.length) { res.writeHead(500); res.end("No files found"); return; }
      const zipBuf = buildZip(zipFiles);
      res.writeHead(200, {
        "Content-Type": "application/zip",
        "Content-Disposition": 'attachment; filename="lamby-bridge-source.zip"',
        "Content-Length": zipBuf.length,
        "Access-Control-Allow-Origin": "*",
      });
      res.end(zipBuf);
    } catch (e) {
      res.writeHead(500); res.end("ZIP build error: " + e.message);
    }
    return;
  }
  if (pathname === "/api/download/app.zip") {
    try {
      const __dir = path.dirname(new URL(`file://${process.argv[1]}`).pathname);
      const appDir = path.join(__dir, "lamby-app");
      const baseLen = appDir.length + 1;
      const zipFiles = walkDir(appDir, baseLen);
      if (!zipFiles.length) { res.writeHead(404); res.end("lamby-app folder not found"); return; }
      const zipBuf = buildZip(zipFiles);
      res.writeHead(200, {
        "Content-Type": "application/zip",
        "Content-Disposition": 'attachment; filename="lamby-app-source.zip"',
        "Content-Length": zipBuf.length,
        "Access-Control-Allow-Origin": "*",
      });
      res.end(zipBuf);
    } catch (e) {
      res.writeHead(500); res.end("ZIP build error: " + e.message);
    }
    return;
  }
  if (pathname === "/api/snapshot-key") {
    const host = req.headers.host || `localhost:${PORT}`;
    const protocol = req.headers["x-forwarded-proto"] || "https";
    const baseUrl = `${protocol}://${host}`;
    sendJson(res, {
      baseUrl,
      connected: [...desktopClients.values()].some(c => c.alive),
      project: (() => { for (const c of desktopClients.values()) { if (c.alive && c.project) return c.project; } return null; })(),
      snapshotUrl: `${baseUrl}/api/snapshot/PROJECT_NAME`,
      commandEndpoint: `${baseUrl}/api/sandbox/execute`,
      consoleLogsEndpoint: `${baseUrl}/api/console-logs`,
      bridgeWs: `wss://${host}/bridge-ws?project=PROJECT_NAME`,
    });
    return;
  }
  if (pathname === "/api/bridge-status") {
    const clients = [...desktopClients.values()].filter(c => c.alive).map(c => ({
      connected: c.alive,
      lastPing: c.lastPing,
      desktopName: c.desktopName || null,
      project: c.project || null,
      projectName: c.projectName || c.project || null,
      previewPort: c.previewPort || null,
    }));
    sendJson(res, {
      connectedClients: clients.length,
      clients,
    });
    return;
  }
  if (pathname.startsWith("/api/snapshot/")) {
    if (req.method !== "GET") { res.writeHead(405); res.end("Method not allowed"); return; }
    const pathParts = pathname.replace("/api/snapshot/", "").split("/").filter(Boolean);
    const projectName = pathParts[0] || "";
    // ?format=graph routes to graph snapshot; cache key includes format to prevent cross-format pollution
    const snapshotFormat = url.searchParams.get("format") || "";
    const snapshotCacheKey = snapshotFormat ? `${projectName}:${snapshotFormat}` : projectName;

    // 1. Cache hit
    const cached = snapshotCache.get(snapshotCacheKey);
    if (cached && cached.expiresAt > Date.now()) {
      relayLog("info", `SNAPSHOT cache hit project=${projectName} format=${snapshotFormat||"default"} expiresIn=${Math.round((cached.expiresAt - Date.now()) / 1000)}s`);
      res.writeHead(200, { "Content-Type": "text/plain; charset=utf-8", "Access-Control-Allow-Origin": "*" });
      res.end(cached.result);
      return;
    }

    // 2. Already in-flight for this project+format — join the waiters
    if (pendingSnapshots.has(snapshotCacheKey)) {
      const existing = pendingSnapshots.get(snapshotCacheKey);
      existing.waiters.add(res);
      req.on("close", () => existing.waiters.delete(res));
      relayLog("info", `SNAPSHOT fan-in project=${projectName} format=${snapshotFormat||"default"} waiters=${existing.waiters.size}`);
      return; // response delivered by WS fan-out
    }

    // 3. New request — need a connected desktop (route to the project's desktop)
    const matchedClient = findBridgeClient(projectName);
    if (!matchedClient) {
      res.writeHead(200, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" });
      res.end(JSON.stringify({ success: true, status: "queued", message: "Command accepted — desktop is reconnecting. It will execute automatically." }));
      return;
    }

    const requestId = crypto.randomUUID();
    const waiters = new Set([res]);
    req.on("close", () => waiters.delete(res));

    const timer = setTimeout(() => {
      const ps = pendingSnapshots.get(snapshotCacheKey);
      if (ps && ps.requestId === requestId) {
        pendingSnapshots.delete(snapshotCacheKey);
        relayLog("warn", `SNAPSHOT TIMEOUT 60s project=${projectName} format=${snapshotFormat||"default"} waiters=${ps.waiters.size}`);
        const errStr = "Error: Relay timeout — desktop app did not respond within 60 seconds.";
        for (const r of ps.waiters) {
          if (!r.writableEnded) {
            r.writeHead(200, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" });
            r.end(JSON.stringify({ success: true, status: "processing", message: "Screenshot is still being captured — desktop is processing." }));
          }
        }
      }
    }, 60000);

    pendingSnapshots.set(snapshotCacheKey, { requestId, timer, waiters });

    try {
      relayLog("info", `→Desktop snapshot-request project=${projectName} format=${snapshotFormat||"default"} reqId=${requestId.substring(0, 8)}...`);
      matchedClient.send(JSON.stringify({ type: "snapshot-request", requestId, projectName, format: snapshotFormat || undefined }));
    } catch (sendErr) {
      pendingSnapshots.delete(snapshotCacheKey);
      clearTimeout(timer);
      relayLog("error", `SNAPSHOT send failed: ${sendErr.message}`);
      res.writeHead(200, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" });
      res.end(JSON.stringify({ success: true, status: "queued", message: "Command queued — desktop is reconnecting automatically." }));
    }
    return; // response delivered by WS fan-out
  }
  if (pathname === "/api/console-logs") {
    if (req.method !== "GET") { res.writeHead(405); res.end("Method not allowed"); return; }
    const projectName = url.searchParams.get("project") || "";
    const matchedClient = findBridgeClient(projectName || null);
    if (!matchedClient) {
      sendGrokOk(res, "queued", "Command queued — desktop is reconnecting automatically.");
      return;
    }
    const requestId = crypto.randomUUID();
    const relayPromise = new Promise((resolve) => {
      const timer = setTimeout(() => {
        pendingConsoleLogRequests.delete(requestId);
        resolve({ success: true, status: "timeout", message: "Desktop is processing — check again shortly." });
      }, 15000);
      pendingConsoleLogRequests.set(requestId, { resolve, timer });
    });
    try {
      relayLog("info", `→Desktop console-logs-request project=${projectName} reqId=${requestId.substring(0, 8)}...`);
      matchedClient.send(JSON.stringify({ type: "console-logs-request", requestId, projectName }));
    } catch {
      sendGrokOk(res, "queued", "Command queued — desktop is reconnecting automatically.");
      return;
    }
    const logs = await relayPromise;
    sendJson(res, logs);
    return;
  }
  if (pathname === "/api/sandbox/execute") {
    if (req.method !== "POST") { res.writeHead(405); res.end("Method not allowed"); return; }
    try {
      const matchedClient = findBridgeClient();
      relayLog("info", `EXECUTE hasClient=${!!matchedClient} aliveClients=${desktopClients.size}`);
      let rawBody;
      try {
        rawBody = await readBody(req);
        relayLog("info", `EXECUTE body received size=${rawBody.length} bytes`);
      } catch (bodyErr) {
        relayLog("error", `EXECUTE body read error: ${bodyErr.message}`);
        sendGrokOk(res, "needs_params", "Body too large: " + bodyErr.message);
        return;
      }
      let body;
      try {
        body = parseWithRepair(rawBody, "EXECUTE");
      } catch (parseErr) {
        relayLog("error", `EXECUTE JSON parse error: ${parseErr.message} raw(200)=${rawBody.substring(0, 200)}`);
        sendGrokOk(res, "needs_params", "Invalid JSON body");
        return;
      }
      const actions = body.actions ?? body.types ?? body.commands ?? body.data ?? body.payload;
      if (!Array.isArray(actions) || actions.length === 0) {
        relayLog("warn", `EXECUTE 400 actions missing or empty. Body keys: ${Object.keys(body).join(", ")}`);
        sendGrokOk(res, "needs_params", "actions array required"); return;
      }
      if (actions.length > 100) { sendGrokOk(res, "needs_params", "Max 100 actions per request"); return; }
      const validatedActions = [];
      for (const action of actions) {
        const v = grokValidateStep(action);
        if (v.rejected) {
          relayLog("warn", `EXECUTE REJECTED ${action.type}: ${v.reason}`);
          continue;
        }
        validatedActions.push(action);
      }
      if (validatedActions.length === 0 && actions.length > 0) {
        sendGrokOk(res, "needs_params", "All actions were rejected due to missing required parameters. Check each action has the required fields (e.g. launch_exe needs path, run_command needs command, cdp_navigate needs url).");
        return;
      }
      relayLog("info", `EXECUTE actions(${validatedActions.length}/${actions.length}): ${validatedActions.map(a => a.type + (a.project ? "@" + a.project : "")).join(", ")}`);
      const _execProject = validatedActions[0]?.project || null;
      const liveClient = await waitForClient(_execProject);
      if (!liveClient) {
        relayLog("warn", `EXECUTE 503 no alive client found after wait. aliveClients=${desktopClients.size}`);
        sendGrokOk(res, "queued", "Command accepted and queued — desktop is reconnecting. It will execute automatically.");
        return;
      }
      const requestId = crypto.randomUUID();
      const relayPromise = makeRelayPromise(requestId, req, 120000, "EXECUTE");
      try {
        relayLog("info", `→Desktop EXECUTE reqId=${requestId.substring(0, 8)}... actions=[${validatedActions.map(a => a.type).join(",")}]`);
        liveClient.send(JSON.stringify({ type: "sandbox-execute-request", requestId, actions: validatedActions }));
        relayLog("info", `→Desktop EXECUTE sent OK, waiting for response... reqId=${requestId.substring(0, 8)}...`);
      } catch (sendErr) {
        relayLog("error", `→Desktop EXECUTE send failed: ${sendErr.message} reqId=${requestId.substring(0, 8)}...`);
        sendGrokOk(res, "queued", "Command queued — desktop is reconnecting automatically.");
        return;
      }
      const _execT0 = Date.now();
      const _execEntries = validatedActions.map(action => pushActivity({
        type: action.type, project: action.project || "", status: "pending",
        human: humanizeAction(action.type, action), detail: "waiting for desktop…", action
      }));
      const result = await relayPromise;
      try { if (parseWithRepair(result, "EXECUTE disconnect-check").__clientDisconnected) { relayLog("info", `EXECUTE dropping result — client already gone reqId=${requestId.substring(0, 8)}...`); return; } } catch {}
      relayLog("info", `←Desktop EXECUTE responded reqId=${requestId.substring(0, 8)}... size=${result.length} preview=${result.substring(0, 120)}`);
      try {
        const parsed = parseWithRepair(result, "EXECUTE result");
        const dur = Date.now() - _execT0;
        _execEntries.forEach((entry, i) => {
          const actionType = validatedActions[i]?.type;
          const rData = parsed?.results?.[i]?.data;
          const ok = rData?.success !== false && !rData?.error;
          const detail = resultSummary(actionType, parsed?.results?.[i] ? { results: [parsed.results[i]] } : parsed) || (rData?.error ? rData.error.slice(0,150) : ok ? "ok" : "unknown");
          updateActivity(entry, { status: ok ? "ok" : "fail", dur, human: humanizeAction(actionType, validatedActions[i], rData), detail });
        });
      } catch {}
      res.writeHead(200, { "Content-Type": "application/json" });
      res.end(result);
    } catch (err) {
      relayLog("error", `EXECUTE unhandled error: ${err.message}`);
      sendGrokOk(res, "processing", "Command received and processing. " + (err.message || ""));
    }
    return;
  }
  if (pathname === "/api/sandbox/audit-log") {
    if (req.method !== "GET") { res.writeHead(405); res.end("Method not allowed"); return; }
    sendJson(res, { entries: activityLog.slice(-200) });
    return;
  }
  if (pathname === "/api/activity-log") {
    if (req.method !== "GET") { res.writeHead(405); res.end("Method not allowed"); return; }
    const _alLimit = Math.min(parseInt(url.searchParams.get("limit") || "500", 10), 5000);
    const _alProject = url.searchParams.get("project") || "";
    const _alStatus = url.searchParams.get("status") || "";
    const _alType = url.searchParams.get("type") || "";
    const _alSince = parseInt(url.searchParams.get("since") || "0", 10);
    let _alEntries = activityLog.slice();
    if (_alProject) _alEntries = _alEntries.filter(e => e.project === _alProject);
    if (_alStatus) _alEntries = _alEntries.filter(e => e.status === _alStatus);
    if (_alType) _alEntries = _alEntries.filter(e => e.type === _alType);
    if (_alSince) _alEntries = _alEntries.filter(e => e.ts > _alSince);
    _alEntries = _alEntries.slice(-_alLimit);
    const _alCountByStatus = {};
    for (const e of activityLog) { _alCountByStatus[e.status] = (_alCountByStatus[e.status] || 0) + 1; }
    res.writeHead(200, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*", "Cache-Control": "no-cache" });
    res.end(JSON.stringify({ total: activityLog.length, returned: _alEntries.length, countByStatus: _alCountByStatus, entries: _alEntries }));
    return;
  }
  if (pathname === "/api/activity-stream") {
    if (req.method !== "GET") { res.writeHead(405); res.end("Method not allowed"); return; }
    const _asSince = parseInt(url.searchParams.get("since") || "0", 10);
    res.writeHead(200, { "Content-Type": "text/event-stream", "Cache-Control": "no-cache", "Connection": "keep-alive", "Access-Control-Allow-Origin": "*" });
    res.write(": connected\n\n");
    // Send backfill of entries since `since`
    const _backfill = _asSince ? activityLog.filter(e => e.ts > _asSince) : activityLog.slice(-200);
    for (const e of _backfill) {
      try { res.write(`data: ${JSON.stringify({ event: "new", entry: e })}\n\n`); } catch { break; }
    }
    activityLogSSEClients.add(res);
    const _asKA = setInterval(() => { try { res.write(": ka\n\n"); } catch { clearInterval(_asKA); activityLogSSEClients.delete(res); } }, 20000);
    const _asClean = () => { activityLogSSEClients.delete(res); clearInterval(_asKA); };
    req.on("close", _asClean); req.on("error", _asClean);
    return;
  }
  if (pathname === "/api/grok-docs") {
    const docsPath = path.join(__dirname, "GROK-BRIDGE-DOCS.md");
    try {
      const content = fs.readFileSync(docsPath, "utf8");
      res.writeHead(200, { "Content-Type": "text/markdown; charset=utf-8", "Access-Control-Allow-Origin": "*" });
      res.end(content);
    } catch (e) {
      res.writeHead(404, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ error: "GROK-BRIDGE-DOCS.md not found", path: docsPath }));
    }
    return;
  }
  if (pathname === "/api/grok") {
    const host = req.headers.host || `localhost:${PORT}`;
    const protocol = req.headers["x-forwarded-proto"] || "https";
    const baseUrl = `${protocol}://${host}`;
    const proxyBase = `${baseUrl}/api/grok-proxy?payload=`;
    // Detect actual connected project name — Grok reads examples and copies the
    // project field literally into its real API calls. Using "my-app" placeholder
    // causes every command to fail with 503 because no such project is connected.
    const connectedProject = (() => { for (const c of desktopClients.values()) { if (c.alive && c.project) return c.project; } return null; })();
    const _P = connectedProject || "YOUR_PROJECT_NAME";
    const commands = [
      { type: "list_projects", desc: "⭐ CALL THIS FIRST if unsure of project name — lists all projects found under PROJECT_DIR with their directory path, hasDev flag, and active dev port. Returns {projects:[{name, dir, hasDev, activePort}]}. Use the 'name' field as the project value in all subsequent commands.", example: { type: "list_projects" } },
      { type: "list_tree", desc: "List files in a project directory", example: { type: "list_tree", project: "my-app", path: "src" } },
      { type: "read_file", desc: "Read a file's full content", example: { type: "read_file", project: "my-app", path: "src/index.html" } },
      { type: "read_multiple_files", desc: "Read several files at once", example: { type: "read_multiple_files", project: "my-app", paths: ["src/index.html","src/main.js"] } },
      { type: "write_file", desc: "Write/overwrite a file — use ONLY for content under 2 KB (config files, small scripts). For larger files use write_file_chunk. CAUTION: Before writing App.tsx read src/index.tsx first — it may import from 'components/App' not 'App', meaning the real file is src/components/App.tsx.", example: { type: "write_file", project: "my-app", path: "src/config.json", content: "{}" } },
      { type: "write_file_chunk", desc: "Write a large file in pieces — REQUIRED for any content > 2 KB (full components, pages, etc.). Split content into chunks of ~1500 chars each. Send one action per chunk; file is assembled and written when the final chunk arrives. CAUTION: Before writing App.tsx read src/index.tsx first to find the correct path (may be src/components/App.tsx not src/App.tsx).", example: { type: "write_file_chunk", project: "my-app", path: "src/App.tsx", chunk_index: 0, total_chunks: 3, content: "import React..." } },
      { type: "create_file", desc: "Create a new file", example: { type: "create_file", project: "my-app", path: "src/new.js", content: "" } },
      { type: "delete_file", desc: "Delete a file", example: { type: "delete_file", project: "my-app", path: "src/old.js" } },
      { type: "search_replace", desc: "Find and replace text in a file (best for small edits)", example: { type: "search_replace", project: "my-app", path: "src/index.html", search: "old text", replace: "new text" } },
      { type: "bulk_write", desc: "Write multiple files at once", example: { type: "bulk_write", project: "my-app", files: [{ path: "a.js", content: "..." }] } },
      { type: "apply_patch", desc: "Apply a unified diff patch", example: { type: "apply_patch", project: "my-app", patch: "--- a/src/index.html\n+++ b/src/index.html\n..." } },
      { type: "move_file", desc: "Move/rename a file", example: { type: "move_file", project: "my-app", from: "src/old.js", to: "src/new.js" } },
      { type: "copy_file", desc: "Copy a file", example: { type: "copy_file", project: "my-app", from: "src/a.js", to: "src/b.js" } },
      { type: "delete_folder", desc: "Delete a folder", example: { type: "delete_folder", project: "my-app", path: "src/unused" } },
      { type: "create_folder", desc: "Create a folder", example: { type: "create_folder", project: "my-app", path: "src/new-dir" } },
      { type: "bulk_delete", desc: "Delete multiple files", example: { type: "bulk_delete", project: "my-app", paths: ["src/a.js","src/b.js"] } },
      { type: "grep", desc: "Regex search across files", example: { type: "grep", project: "my-app", pattern: "TODO", path: "src" } },
      { type: "grep_advanced", desc: "Grep with include/exclude globs", example: { type: "grep_advanced", project: "my-app", pattern: "console\\.log", include: "**/*.js" } },
      { type: "search_files", desc: "Full-text search across project", example: { type: "search_files", project: "my-app", query: "background-color" } },
      { type: "symbol_search", desc: "Find function/class definitions", example: { type: "symbol_search", project: "my-app", query: "handleClick" } },
      { type: "find_usages", desc: "Find all usages of a symbol", example: { type: "find_usages", project: "my-app", symbol: "fetchUser" } },
      { type: "run_command", desc: "Run a shell command in the project", example: { type: "run_command", project: "my-app", command: "npm run build" } },
      { type: "run_command_advanced", desc: "Run command with cwd/env options", example: { type: "run_command_advanced", project: "my-app", command: "ls -la", cwd: "src" } },
      { type: "install_deps", desc: "Install all dependencies", example: { type: "install_deps", project: "my-app" } },
      { type: "add_dependency", desc: "Add an npm package", example: { type: "add_dependency", project: "my-app", package: "lodash" } },
      { type: "remove_dependency", desc: "Remove an npm package", example: { type: "remove_dependency", project: "my-app", package: "lodash" } },
      { type: "type_check", desc: "Run TypeScript type checker", example: { type: "type_check", project: "my-app" } },
      { type: "lint_and_fix", desc: "Lint and auto-fix code", example: { type: "lint_and_fix", project: "my-app" } },
      { type: "format_files", desc: "Format files with Prettier", example: { type: "format_files", project: "my-app", paths: ["src/index.ts"] } },
      { type: "git_status", desc: "git status", example: { type: "git_status", project: "my-app" } },
      { type: "git_diff", desc: "git diff (staged or unstaged)", example: { type: "git_diff", project: "my-app" } },
      { type: "git_add", desc: "git add files", example: { type: "git_add", project: "my-app", paths: ["."] } },
      { type: "git_commit", desc: "git commit with message", example: { type: "git_commit", project: "my-app", message: "fix: update styles" } },
      { type: "git_log", desc: "git log (recent commits)", example: { type: "git_log", project: "my-app", limit: 10 } },
      { type: "git_branch", desc: "List or create branches", example: { type: "git_branch", project: "my-app" } },
      { type: "git_checkout", desc: "Checkout a branch", example: { type: "git_checkout", project: "my-app", branch: "main" } },
      { type: "git_push", desc: "git push", example: { type: "git_push", project: "my-app" } },
      { type: "git_pull", desc: "git pull", example: { type: "git_pull", project: "my-app" } },
      { type: "git_merge", desc: "Merge a branch", example: { type: "git_merge", project: "my-app", branch: "feature-x" } },
      { type: "git_stash", desc: "Stash changes", example: { type: "git_stash", project: "my-app" } },
      { type: "git_stash_pop", desc: "Pop stash", example: { type: "git_stash_pop", project: "my-app" } },
      { type: "git_reset", desc: "git reset", example: { type: "git_reset", project: "my-app", mode: "soft", ref: "HEAD~1" } },
      { type: "git_revert", desc: "git revert a commit", example: { type: "git_revert", project: "my-app", commit: "abc1234" } },
      { type: "git_tag", desc: "Create/list git tags", example: { type: "git_tag", project: "my-app", tag: "v1.0.0" } },
      { type: "git_init", desc: "git init", example: { type: "git_init", project: "my-app" } },
      { type: "detect_structure", desc: "Detect project framework/structure", example: { type: "detect_structure", project: "my-app" } },
      { type: "project_analyze", desc: "Deep project analysis", example: { type: "project_analyze", project: "my-app" } },
      { type: "component_tree", desc: "React component tree", example: { type: "component_tree", project: "my-app" } },
      { type: "extract_theme", desc: "Extract design tokens/theme", example: { type: "extract_theme", project: "my-app" } },
      { type: "extract_colors", desc: "Extract all colors used", example: { type: "extract_colors", project: "my-app" } },
      { type: "extract_imports", desc: "Map all import dependencies", example: { type: "extract_imports", project: "my-app", path: "src/index.ts" } },
      { type: "dependency_graph", desc: "Full dependency graph", example: { type: "dependency_graph", project: "my-app" } },
      { type: "dead_code_detection", desc: "Find unused code", example: { type: "dead_code_detection", project: "my-app" } },
      { type: "tailwind_audit", desc: "Audit Tailwind CSS usage", example: { type: "tailwind_audit", project: "my-app" } },
      { type: "build_project", desc: "Build the project", example: { type: "build_project", project: "my-app" } },
      { type: "run_tests", desc: "Run test suite", example: { type: "run_tests", project: "my-app" } },
      { type: "get_build_metrics", desc: "Bundle size and build info", example: { type: "get_build_metrics", project: "my-app" } },
      { type: "start_process", desc: "Start a background process", example: { type: "start_process", project: "my-app", command: "npm run dev" } },
      { type: "start_process_named", desc: "Start named background process", example: { type: "start_process_named", project: "my-app", name: "devserver", command: "npm run dev" } },
      { type: "kill_process", desc: "Kill a process by PID or name", example: { type: "kill_process", project: "my-app", pid: 1234 } },
      { type: "list_processes", desc: "List running processes", example: { type: "list_processes", project: "my-app" } },
      { type: "monitor_process", desc: "Get process status/cpu/mem", example: { type: "monitor_process", project: "my-app", name: "devserver" } },
      { type: "get_process_logs", desc: "Get stdout/stderr of a process", example: { type: "get_process_logs", project: "my-app", name: "devserver" } },
      { type: "stop_all_processes", desc: "Stop all running processes", example: { type: "stop_all_processes", project: "my-app" } },
      { type: "list_open_ports", desc: "List ports in use", example: { type: "list_open_ports", project: "my-app" } },
      { type: "restart_dev_server", desc: "Restart dev server", example: { type: "restart_dev_server", project: "my-app" } },
      { type: "switch_port", desc: "⛔ NOT AVAILABLE IN STANDALONE CONNECTOR MODE — use manage_scripts to update port in package.json scripts, then call restart_dev_server", example: { type: "switch_port", project: "my-app", port: 3001 } },
      { type: "set_env_var", desc: "Set an environment variable", example: { type: "set_env_var", project: "my-app", key: "API_URL", value: "https://api.example.com" } },
      { type: "get_env_vars", desc: "List env vars", example: { type: "get_env_vars", project: "my-app" } },
      { type: "capture_preview", desc: "Get the live preview URL (alias for get_preview_url — returns the running dev server URL)", example: { type: "capture_preview", project: "YOUR_PROJECT_NAME" } },
      { type: "get_preview_url", desc: "Get the live preview URL — auto-detects Vite/CRA/Next dev server port from process stdout", example: { type: "get_preview_url", project: "YOUR_PROJECT_NAME" } },
      { type: "get_dom_snapshot", desc: "curl the running dev server and return raw HTML — useful for checking what the server actually renders. Requires a dev server running.", example: { type: "get_dom_snapshot", project: "my-app" } },
      { type: "get_console_errors", desc: "Scan all tracked process logs for error/warn lines and return them grouped by process. Zero prerequisites.", example: { type: "get_console_errors", project: "my-app" } },
      { type: "visual_diff", desc: "Pixel diff two URLs — needs puppeteer installed (npm i puppeteer). Without it returns {available:false}. With it saves .visual-diffs/ PNGs and reports diffPercent.", example: { type: "visual_diff", project: "my-app", beforeUrl: "http://localhost:3000", afterUrl: "http://localhost:3000" } },
      { type: "capture_component", desc: "Screenshot a component by URL+selector — needs puppeteer. Without puppeteer returns {available:false,note:'npm i puppeteer'}. With it saves .component-captures/ PNG.", example: { type: "capture_component", project: "YOUR_PROJECT_NAME", url: "http://localhost:3000", selector: "#root" } },
      { type: "rollback_last_change", desc: "Undo last file change", example: { type: "rollback_last_change", project: "my-app" } },
      { type: "generate_component", desc: "⚠️ REQUIRES XAI_API env var on desktop. If set, uses AI to generate the component. If not set, returns {error:'XAI_API not set'}. Alternative: write_file or create_file.", example: { type: "generate_component", project: "my-app", name: "PricingCard", description: "A pricing card with title, price, and CTA button" } },
      { type: "generate_page", desc: "⚠️ REQUIRES XAI_API env var on desktop. Uses AI to generate a full page. Alternative: write_file.", example: { type: "generate_page", project: "my-app", name: "Landing", description: "Hero + features + CTA" } },
      { type: "generate_test", desc: "⚠️ REQUIRES XAI_API env var on desktop. Uses AI to generate test files. Alternative: write_file.", example: { type: "generate_test", project: "my-app", path: "src/Button.tsx" } },
      { type: "refactor_file", desc: "⚠️ REQUIRES XAI_API env var on desktop. Uses AI to refactor a file. Alternative: search_replace + write_file for targeted edits.", example: { type: "refactor_file", project: "my-app", path: "src/utils.ts", instruction: "split into separate modules" } },
      { type: "optimize_code", desc: "⚠️ REQUIRES XAI_API env var on desktop. Uses AI to suggest optimizations. Alternative: type_check + lint_and_fix.", example: { type: "optimize_code", project: "my-app", path: "src/heavy.ts" } },
      { type: "validate_change", desc: "Lint+type-check after a change", example: { type: "validate_change", project: "my-app" } },
      { type: "super_command", desc: "⚠️ REQUIRES XAI_API env var on desktop. Natural language description executed by AI. Pass description field. Also available as GET /api/grok-super?project=P&describe=TEXT", example: { type: "super_command", project: "my-app", description: "Add a dark mode toggle to the header" } },
      { type: "update_package_json", desc: "Edit package.json fields", example: { type: "update_package_json", project: "my-app", fields: { version: "1.2.0" } } },
      { type: "manage_scripts", desc: "Add/edit npm scripts", example: { type: "manage_scripts", project: "my-app", scripts: { preview: "vite preview" } } },
      { type: "bundle_analyzer", desc: "Analyze the built dist/ folder — file sizes by type, largest files, totals. Run build_project first. Zero browser prerequisites.", example: { type: "bundle_analyzer", project: "my-app" } },
      { type: "security_scan", desc: "Scan for security issues via npm audit", example: { type: "security_scan", project: "my-app" } },
      { type: "accessibility_audit", desc: "Static source analysis of JSX/HTML — finds missing alt, aria-label, role, tabIndex, label patterns. Zero browser prerequisites.", example: { type: "accessibility_audit", project: "my-app" } },
      { type: "react_profiler", desc: "Static source analysis — finds React components missing React.memo, useEffect deps, useMemo opportunities. Zero prerequisites.", example: { type: "react_profiler", project: "my-app" } },
      { type: "memory_leak_detection", desc: "Static source analysis — finds addEventListener without removeEventListener, setInterval/setTimeout leaks, WebSocket without close(). Zero prerequisites.", example: { type: "memory_leak_detection", project: "my-app" } },
      { type: "console_error_analysis", desc: "Scans all tracked process logs for error/warn/deprecated patterns, grouped by process. Zero prerequisites.", example: { type: "console_error_analysis", project: "my-app" } },
      { type: "runtime_error_trace", desc: "Static source analysis — finds ErrorBoundary components, try/catch blocks, uncaught throw patterns. Zero prerequisites.", example: { type: "runtime_error_trace", project: "my-app" } },
      { type: "network_monitor", desc: "Runs netstat/ss to show active TCP connections on the Windows machine.", example: { type: "network_monitor", project: "my-app" } },
      // ── Commands implemented in connector but missing from this list ─────
      { type: "screenshot_preview", desc: "Take a screenshot of the running dev server. Connector captures PNG via headless Chrome, sends base64 to relay, relay serves it at /api/screenshot-data/PROJECT — 100% reliable, no external upload needed. Returns {captured:true, screenshotUrl:'https://RELAY/api/screenshot-data/project', relayServed:true}.", example: { type: "screenshot_preview", project: "my-app", fullPage: true, waitMs: 3000 } },
      { type: "glob_search", desc: "Glob pattern search across project files", example: { type: "glob_search", project: "my-app", pattern: "**/*.tsx" } },
      { type: "grep_search", desc: "Regex search across files (alias for grep)", example: { type: "grep_search", project: "my-app", pattern: "useState", path: "src" } },
      { type: "rename_file", desc: "Rename a file (alias for move_file)", example: { type: "rename_file", project: "my-app", from: "src/old.ts", to: "src/new.ts" } },
      { type: "move_folder", desc: "Move or rename a folder", example: { type: "move_folder", project: "my-app", from: "src/components", to: "src/ui" } },
      { type: "rename_folder", desc: "Rename a folder (alias for move_folder)", example: { type: "rename_folder", project: "my-app", from: "src/old-dir", to: "src/new-dir" } },
      { type: "list_tree_filtered", desc: "List files filtered by extension or query", example: { type: "list_tree_filtered", project: "my-app", extension: ".tsx", query: "Button" } },
      { type: "git_revert", desc: "Revert a commit", example: { type: "git_revert", project: "my-app", commit: "abc1234" } },
      { type: "git_tag", desc: "Create or list git tags", example: { type: "git_tag", project: "my-app", tag: "v1.0.0" } },
      { type: "git_init", desc: "Initialize a git repository", example: { type: "git_init", project: "my-app" } },
      { type: "browser_interact", desc: "⛔ NOT AVAILABLE IN STANDALONE CONNECTOR MODE — requires the full Electron desktop app with embedded Chromium. Use screenshot_preview + write_file for edits instead.", example: { type: "browser_interact", project: "my-app", action: "click", selector: "#btn" } },
    ];
    // Build example payloads using the real connected project name
    const exampleReadPayload = Buffer.from(JSON.stringify({ actions: [{ type: "read_file", project: _P, path: "src/index.html" }] })).toString("base64");
    const exampleReplacePayload = Buffer.from(JSON.stringify({ actions: [{ type: "search_replace", project: _P, path: "src/index.html", search: "old text", replace: "new text" }] })).toString("base64");
    const _grokResponseObj = {

      // ═══════════════════════════════════════════════════════════════════
      // 1. CONNECTION STATE — read this first
      // ═══════════════════════════════════════════════════════════════════
      connection: {
        status: connectedProject ? "CONNECTED" : "WAITING",
        connectedProject: _P,
        connectedDesktops: [...desktopClients.values()].filter(c => c.alive).length,
        relayBaseUrl: baseUrl,
        note: connectedProject
          ? `Desktop is live — project "${_P}" detected. All examples below already use this project name. Do NOT change it.`
          : "No desktop connected yet. Start the connector on the Windows machine. Examples show YOUR_PROJECT_NAME — replace once connected.",
      },

      // ═══════════════════════════════════════════════════════════════════
      // 2. DESKTOP CONTROL — YOUR PRIMARY TOOL (grok-do chains)
      // ═══════════════════════════════════════════════════════════════════
      desktopControl: {
        overview: "grok-do is your primary tool. It supports TASK MACROS for common workflows (1 call does everything) and CHAINS for custom multi-step tasks. Individual endpoints are rate-limited to 30/minute — always use grok-do instead.",
        taskMacros: {
          description: "Pre-built workflows that run 5-15 steps automatically. USE THESE FIRST.",
          "sketchfab-search": `${baseUrl}/api/grok-do?task=sketchfab-search&query=low+poly+fox`,
          "sketchfab-download": `${baseUrl}/api/grok-do?task=sketchfab-download&url=SKETCHFAB_MODEL_URL`,
          "sketchfab-to-blender": `${baseUrl}/api/grok-do?task=sketchfab-to-blender&query=low+poly+fox`,
          "open-in-blender": `${baseUrl}/api/grok-do?task=open-in-blender&file=C:\\Users\\Aiden\\Desktop\\model\\scene.glb`,
          "download-file": `${baseUrl}/api/grok-do?task=download-file&url=https://example.com/file.glb&dest=C:\\Users\\Aiden\\Desktop\\file.glb`,
          "web-search": `${baseUrl}/api/grok-do?task=web-search&query=weather+today`,
        },
        endpoint: `${baseUrl}/api/grok-do?chain=STEP1|STEP2|STEP3`,
        method: "GET (browse_page) or POST",
        stepTypes: {
          "run:COMMAND": "Run a shell command (cmd.exe on Windows)",
          "wait:MILLISECONDS": "Wait N ms between steps",
          "snapshot": "Get Chrome page DOM snapshot with all selectors (no value needed)",
          "click:CSS_SELECTOR": "Click an element in Chrome using CSS selector",
          "nav:URL": "Navigate Chrome to a URL",
          "eval:JAVASCRIPT": "Execute JavaScript in the Chrome page",
          "type_text:SELECTOR>>>TEXT": "Type text into a browser input field",
          "screenshot:TITLE": "Screenshot a window by partial title match",
          "focus:TITLE": "Bring a window to the front",
          "launch:PATH": "Launch an exe (use PATH>>>ARGS for arguments)",
          "paste:TEXT": "Paste text into the active desktop window (+ Enter)",
          "keys:KEYSTROKES": "Send keystrokes ({ENTER}, ^c, etc.)",
          "click_at:X,Y": "Click at screen coordinates",
          "list_windows": "List all open windows (no value needed)",
          "tabs": "List Chrome tabs (no value needed)",
        },
        examples: {
          openWebsite: `${baseUrl}/api/grok-do?chain=run:start chrome https://google.com|wait:5000|snapshot`,
          googleSearch: `${baseUrl}/api/grok-do?chain=run:start chrome https://www.google.com/search?q=weather+today|wait:6000|snapshot`,
          playSoundCloud: `${baseUrl}/api/grok-do?chain=run:start chrome https://soundcloud.com/search?q=fleetwood+mac+dreams|wait:8000|click:a.sc-button-play`,
          createFileNotepad: `${baseUrl}/api/grok-do?chain=run:echo Hello > C:\\Users\\Aiden\\Desktop\\note.txt|launch:C:\\Windows\\System32\\notepad.exe>>>C:\\Users\\Aiden\\Desktop\\note.txt|wait:3000|screenshot:note.txt`,
          runPython: `${baseUrl}/api/grok-do?chain=run:echo print("hello") > C:\\Users\\Aiden\\Desktop\\test.py|run:python C:\\Users\\Aiden\\Desktop\\test.py`,
          fillWebForm: `${baseUrl}/api/grok-do?chain=nav:https://example.com/form|wait:5000|type_text:input[name='email']>>>user@example.com|click:button[type='submit']|wait:3000|snapshot`,
          installApp: `${baseUrl}/api/grok-do?chain=run:winget install NickeManarin.ScreenToGif --silent --accept-package-agreements|wait:15000|run:where ScreenToGif`,
          sendTelegram: `${baseUrl}/api/grok-do?chain=focus:Telegram|wait:1000|paste:Hello from Grok!`,
          systemInfo: `${baseUrl}/api/grok-do?chain=run:systeminfo | findstr /C:"OS Name" /C:"Total Physical Memory"`,
          screenshotWindow: `${baseUrl}/api/grok-do?chain=list_windows|screenshot:Blender`,
        },
        responseFormat: '{ success:true, stepsExecuted:N, stepsTotal:N, results:[{ step:0, type:"run_command", status:"success", data:{...} }, ...] }',
        rules: [
          "ALWAYS use ?chain= for multi-step desktop tasks. It runs steps sequentially in ONE call.",
          "Use snapshot to see what's on the page — it returns DOM text, buttons, inputs, links with CSS selectors.",
          "USE THE SELECTORS from snapshot results to click/type. Never guess selectors.",
          "When Chrome is already open, use nav:URL instead of run:start chrome URL (avoids extra tabs).",
          "Add wait:5000-8000 after opening pages to let them load before snapshot/click.",
          "Most tasks need 1-3 chain calls total. Do NOT make 10+ individual calls.",
        ],
      },

      // ═══════════════════════════════════════════════════════════════════
      // 3. SYSTEM ARCHITECTURE — how the project-editing chain works
      // ═══════════════════════════════════════════════════════════════════
      architecture: {
        overview: "Lamby Bridge Relay — zero-dependency WebSocket bridge between Grok (cloud AI) and a local Windows desktop running Node.js. For desktop control (browser, apps, shell) use grok-do chains above. For code editing use the combined endpoints below.",
        requestChain: [
          "1. For desktop control: GET /api/grok-do?chain=run:COMMAND|wait:5000|snapshot (pipe-separated steps)",
          "2. For code editing: GET /api/grok-read, /api/grok-write, /api/grok-create, etc. (combined endpoints)",
          "3. For advanced/batch code ops: GET /api/grok-proxy?payload=BASE64 (base64-encoded action array)",
          "4. All requests go through the relay (Replit cloud) → WebSocket → desktop connector (Windows)",
        ],
        constraints: [
          "Grok is GET-only — every request must be a GET URL via browse_page.",
          "URL length limit ~8 KB total — file content > 2 KB WILL be silently truncated in the URL.",
          "Desktop connector runs on Windows — use PowerShell syntax for run_command shell commands.",
          "Do NOT make many parallel calls — commands queue on one WebSocket connection.",
        ],
        projectResolution: "The connector resolves project names to disk paths. Given project='groks-app', it looks for: PROJECT_DIR/projects/groks-app → then PROJECT_DIR/groks-app. PROJECT_DIR is the root set in the connector's .env (default: cwd). File paths in commands are relative to the resolved project root.",
        hmr: "Vite uses Hot Module Replacement — writing a file via write_file or write_file_chunk triggers an instant browser update with no server restart needed, ONLY if you write to the correct file (the one actually imported by index.tsx).",
      },

      // ═══════════════════════════════════════════════════════════════════
      // 3. CRITICAL RULES — violations cause silent failures
      // ═══════════════════════════════════════════════════════════════════
      criticalRules: [
        "RULE 1 — LARGE FILES: Any file content > 2 KB (React components, pages, full modules) MUST use write_file_chunk. Split into ~1500-char chunks, send chunk_index 0..N-1, total_chunks=N. One action per chunk. File assembles and writes only when final chunk arrives. write_file on large content silently truncates the URL and corrupts the file.",
        "RULE 2 — ENTRY POINT: Before writing App.tsx (or any root component) ALWAYS read src/index.tsx first. Projects often import from 'components/App' not 'App', so the real file is src/components/App.tsx. Writing to src/App.tsx when nothing imports it has zero visible effect — the app won't change.",
        "RULE 3 — ADD DEPENDENCY: add_dependency only edits package.json. You MUST follow it with install_deps to actually install the package into node_modules. Without install_deps, imports will fail at build time.",
        "RULE 4 — SEARCH_REPLACE ZERO MATCHES: If search_replace returns {zeroReplacements:true}, the exact string was NOT found in the file. Read the file first with read_file, copy the exact target text (including whitespace/newlines), then retry.",
        "RULE 5 — PROJECT NAME: Always use the exact connected project name from connection.connectedProject. Never substitute 'my-app', 'YOUR_PROJECT_NAME', or any guess. Every command will 503 if the project field doesn't match the connected project.",
        "RULE 6 — WINDOWS SHELL: run_command runs on Windows. Use PowerShell syntax: Set-Location not cd, Get-ChildItem not ls, $env:VAR not $VAR. Avoid Unix-only tools (grep, awk, sed, tail) — use Select-String, Get-Content, etc.",
        "RULE 7 — VERIFY CHANGES: After any file edit, confirm the change took effect by either: (a) read_file and check the content, or (b) take a screenshot_preview. Never assume an edit worked without verification.",
      ],

      // ═══════════════════════════════════════════════════════════════════
      // 4. HOW TO MAKE A REQUEST
      // ═══════════════════════════════════════════════════════════════════
      howToRequest: {
        endpoint: `${baseUrl}/api/grok-proxy`,
        method: "GET",
        params: {
          payload: "base64(JSON.stringify({actions:[{type,project,...params}]}))"
        },
        encoding: {
          step1: "Build actions array: [{type:'read_file', project:'groks-app', path:'src/index.tsx'}]",
          step2: "JSON.stringify the wrapper: JSON.stringify({actions:[...]})",
          step3: "base64 encode: btoa(step2)  — or Buffer.from(step2).toString('base64') in Node",
          step4: "URL-encode the base64 if it contains + or = characters",
          step5: `GET ${baseUrl}/api/grok-proxy?payload=ENCODED_BASE64`,
        },
        autoRepair: "Relay auto-fixes common encoding mistakes: escapes raw control chars, strips trailing commas, accepts 'types'/'commands'/'data'/'payload' as aliases for 'actions'.",
        batchActions: "You can chain up to 10 actions in one request. All execute sequentially on the desktop. Results come back as results[0], results[1], etc.",
        exampleUrls: {
          readFile: `${proxyBase}${exampleReadPayload}`,
          searchReplace: `${proxyBase}${exampleReplacePayload}`,
        },
      },

      // ═══════════════════════════════════════════════════════════════════
      // 5. RESPONSE FORMAT — how to parse every response
      // ═══════════════════════════════════════════════════════════════════
      responseFormat: {
        successWrapper: '{ "success": true, "results": [ { "type": "command_type", "data": { ...command-specific fields... } } ] }',
        errorWrapper: '{ "success": false, "error": "description" }',
        accessPattern: "results[N].data — where N matches the position of your action in the actions array",
        commandSchemas: {
          list_tree:          '{ success:true, fileTree:"index.html\\nsrc/\\n  components/\\n    App.tsx\\n  index.tsx\\n..." }',
          read_file:          '{ success:true, content:"full file text", path:"src/index.tsx", size:1234 }',
          read_multiple_files:'{ success:true, files:[{path,content,size},...] }',
          write_file:         '{ success:true, path:"src/config.json", bytesWritten:42 }',
          write_file_chunk:   'buffering: { received:N, waiting_for:M, done:false } | final chunk: { done:true, bytes:7024, path:"src/App.tsx" }',
          search_replace:     '{ success:true, replacements:1, path:"src/App.tsx" } | { zeroReplacements:true } = string not found — read file first',
          create_file:        '{ success:true, path:"src/new.tsx" }',
          delete_file:        '{ success:true, path:"src/old.tsx" }',
          grep:               '{ success:true, results:[{file,line,col,match,context},...], count:N }',
          run_command:        '{ success:true, stdout:"...", stderr:"...", exitCode:0, command:"..." }',
          install_deps:       '{ success:true, stdout:"...", stderr:"...", packageManager:"pnpm" }',
          add_dependency:     '{ success:true, package:"react-markdown" } — WARNING: only updates package.json; run install_deps after',
          type_check:         '{ passed:true, errorCount:0 } | { passed:false, errorCount:N, errors:[{file,line,col,code,message}] }',
          lint_and_fix:       '{ success:true, output:"...", fixed:true }',
          build_project:      '{ built:true, stdout:"...", stderr:"..." } | { built:false, stderr:"error output..." }',
          get_build_metrics:  '{ totalKb:165, files:[{name,kb},...] }',
          git_status:         '{ success:true, modified:[...], untracked:[...], staged:[...], branch:"main" }',
          git_add:            '{ success:true }',
          git_commit:         '{ success:true, hash:"abc1234", message:"..." }',
          git_log:            '{ success:true, commits:[{hash,author,date,message},...] }',
          screenshot_preview: '{ captured:true, screenshotUrl:"https://RELAY/api/screenshot-data/project", relayServed:true } — PNG served from relay memory, no external upload. Browse screenshotUrl directly to see the app.',
          get_preview_url:    '{ success:true, url:"http://localhost:PORT", port:PORT }',
          detect_structure:   '{ success:true, framework:"react-vite", packageManager:"pnpm", hasTypeScript:true, hasTailwind:true }',
          project_analyze:    '{ success:true, fileCount:N, dependencyCount:N, framework:"...", ... }',
        },
        timeouts: "Desktop has 30s to respond. Long operations (pnpm install, build) may use more — use run_command with explicit timeout-safe commands if needed.",
      },

      // ═══════════════════════════════════════════════════════════════════
      // 6. WORKFLOW GUIDES — step-by-step for common tasks
      // ═══════════════════════════════════════════════════════════════════
      workflowGuides: {
        editUIComponent: {
          goal: "Change visible text, styles, or logic in the running app",
          steps: [
            "1. list_tree — map the project file structure",
            "2. read_file src/index.tsx (or src/main.tsx) — find which file it imports for the root component",
            "3. read_file on the actual component path found in step 2",
            "4a. search_replace — for targeted edits (change a class, rename a string). PREFERRED for small changes.",
            "4b. write_file_chunk — for full rewrites of components > 2 KB. Split into ~1500-char chunks.",
            "5. read_file the edited file — verify the content looks correct",
            "6. screenshot_preview or GET /api/screenshot-url/PROJECT — confirm the visual change",
          ],
          note: "Vite HMR updates the browser instantly when a file changes — no server restart needed.",
        },
        installAndUsePackage: {
          goal: "Add a new npm package and use it in code",
          steps: [
            "1. add_dependency — adds package to package.json",
            "2. install_deps — actually installs it into node_modules (REQUIRED — add_dependency alone is not enough)",
            "3. write_file_chunk or search_replace — add the import and usage to the component",
            "4. type_check — confirm no TS errors",
            "5. build_project — confirm it compiles clean",
          ],
        },
        debugBuildFailure: {
          goal: "Fix a build or type error",
          steps: [
            "1. build_project — get the full error output from stderr",
            "2. grep or read_file the file mentioned in the error",
            "3. search_replace — fix the specific error location",
            "4. type_check — verify errors are gone",
            "5. build_project — confirm clean build",
          ],
        },
        fullComponentRewrite: {
          goal: "Replace a React component with new code (> 2 KB)",
          steps: [
            "1. read_file src/index.tsx — find the correct component path (e.g. components/App)",
            "2. Build the full new component text locally",
            "3. Split into chunks: every ~1500 chars = one chunk",
            "4. Send write_file_chunk for chunk_index 0, total_chunks=N",
            "5. Send write_file_chunk for chunk_index 1..N-1",
            "6. Final chunk response will have {done:true, bytes:N} — file is now written",
            "7. read_file to verify the assembled content is correct",
            "8. type_check — confirm no errors",
            "9. screenshot_preview — confirm the UI updated",
          ],
        },
        gitWorkflow: {
          goal: "Commit changes to git",
          steps: [
            "1. git_status — see what changed",
            "2. git_add {paths:['.']} — stage all",
            "3. git_commit {message:'feat: description'} — commit",
            "4. (optional) git_push — push to remote",
          ],
        },
      },

      // ═══════════════════════════════════════════════════════════════════
      // 7. KNOWN GOTCHAS — things that fail silently or confusingly
      // ═══════════════════════════════════════════════════════════════════
      knownGotchas: [
        "WRONG APP FILE: Writing to src/App.tsx when index.tsx imports from 'components/App' → file is written but app never changes. Always read index.tsx first.",
        "LARGE WRITE TRUNCATION: write_file with content > ~2 KB → URL is silently truncated by the browser/proxy → file on disk is a corrupted partial. Use write_file_chunk.",
        "ADD_DEPENDENCY WITHOUT INSTALL: add_dependency → package.json updated but pnpm/npm install NOT run → TypeScript can't find the module → build fails. Always follow with install_deps.",
        "ZERO REPLACEMENTS: search_replace returns {zeroReplacements:true} → the exact search string (including whitespace, quotes, semicolons) was not found in the file → read_file first, copy exact text, retry.",
        "WRONG PROJECT NAME: Using 'my-app' or any name other than the connected project → relay returns 503. If unsure, call list_projects first — it scans the desktop and returns all known project names and their disk paths. Use the 'name' field from that result.",
        "UNIX COMMANDS ON WINDOWS: run_command with grep/ls/cat/sed/awk → PowerShell doesn't have these → use Select-String, Get-ChildItem, Get-Content, etc.",
        "CHUNK ORDER MATTERS: write_file_chunk with out-of-order chunk_index → file assembles incorrectly. Always send chunks 0, 1, 2, ... in order.",
        "STALE CHUNKS: If you start a chunked write but don't finish it within 5 minutes, the relay purges the partial buffer. Start again from chunk_index 0.",
        "SCREENSHOT: screenshot_preview now sends PNG as base64 over WebSocket → relay caches it and serves at /api/screenshot-data/PROJECT (no catbox.moe, no external network, always works). screenshotUrl in the response IS this relay URL. Just browse it.",
        "DEV SERVER NOT RUNNING: get_preview_url returns no port → dev server is not started. Use run_command 'pnpm run dev' or restart_dev_server.",
        "TYPE ERRORS AFTER EDIT: search_replace changed a type signature → import still uses old type → type_check will catch it. Always run type_check after structural changes.",
        "VITE CACHE: In rare cases Vite caches old module despite file change → run restart_dev_server to force a full reload.",
      ],

      // ═══════════════════════════════════════════════════════════════════
      // 8. ENDPOINTS REFERENCE — COMBINED ENDPOINTS FIRST (PREFERRED)
      // ═══════════════════════════════════════════════════════════════════
      endpoints: {

        // ── DESKTOP CONTROL (PRIMARY — use for all desktop/browser tasks) ──
        grokDo: {
          url: `${baseUrl}/api/grok-do?chain=run:dir|wait:3000|snapshot`,
          use: "⭐⭐⭐ CHAINED EXECUTOR — your primary tool for desktop control. Pipe-separated steps execute sequentially. See desktopControl section above for all step types and examples.",
          method: "GET",
          params: { chain: "pipe-separated steps: run:COMMAND|wait:MS|snapshot|click:SELECTOR|nav:URL|eval:JS|type_text:SEL>>>TEXT|screenshot:TITLE|focus:TITLE|launch:PATH|paste:TEXT|keys:KEYS|click_at:X,Y|list_windows|tabs" },
        },

        // ── COMBINED ENDPOINTS (for code editing — no encoding needed) ──────────
        grokRead: {
          url: `${baseUrl}/api/grok-read?project=${_P}&path=FILE`,
          use: "⭐ Read a single file. Multi-read: ?files=src/A.tsx,src/B.tsx",
          method: "GET",
          params: { project: "required", path: "single file path", files: "comma-separated paths for multi-read" },
        },
        grokWrite: {
          url: `${baseUrl}/api/grok-write?project=${_P}&path=FILE&search=OLD&replace=NEW`,
          use: "⭐ search_replace + auto-verify read in one call. ?verify=false to skip verify. ?patch= for apply_patch mode.",
          method: "GET",
          params: { project: "required", path: "required", search: "text to find", replace: "replacement", searchB64: "base64 search", replaceB64: "base64 replace", patch: "unified diff for apply_patch", verify: "false to skip verification read" },
        },
        grokCreate: {
          url: `${baseUrl}/api/grok-create?project=${_P}&path=FILE&content=CONTENT`,
          use: "⭐ Create or fully overwrite a file. No base64 needed — content is URL-encoded automatically. Use ?contentB64= for URL-safe base64.",
          method: "GET",
          params: { project: "required", path: "required", content: "full file content (URL-encoded)", contentB64: "URL-safe base64 alternative" },
        },
        grokCreateChunk: {
          url: `${baseUrl}/api/grok-create-chunk?project=${_P}&path=FILE&content=CHUNK&chunk=0&total=N`,
          use: "⭐ Write a large file in ~1500-char pieces using write_file_chunk. All chunks (0..N-1) required in order. Desktop accumulates chunks in memory and writes to disk only on the final chunk. Returns {done:true} on last chunk.",
          method: "GET",
          params: { project: "required", path: "required", content: "chunk content (URL-encoded)", contentB64: "URL-safe base64 alternative", chunk: "0-indexed chunk number (send 0..total-1 in order)", total: "total chunk count" },
          important: "ALL chunks use write_file_chunk internally. The file is NOT written until the final chunk arrives. Chunks must be sent in order (0, 1, 2, ...). Do not skip chunks.",
        },
        grokDelete: {
          url: `${baseUrl}/api/grok-delete?project=${_P}&path=FILE`,
          use: "Delete a file. Returns {success:true} on success.",
          method: "GET",
          params: { project: "required", path: "required" },
        },
        grokTree: {
          url: `${baseUrl}/api/grok-tree?project=${_P}`,
          use: "⭐ List file tree. ?filter=src to filter by name/path. ?ext=.tsx to filter by extension.",
          method: "GET",
        },
        grokRun: {
          url: `${baseUrl}/api/grok-run?project=${_P}&cmd=COMMAND`,
          use: "⭐ Run a shell command. ?flags=F routes to run_command_advanced.",
          method: "GET",
          params: { project: "required", cmd: "shell command", flags: "optional — routes to run_command_advanced" },
        },
        grokGit: {
          url: `${baseUrl}/api/grok-git?project=${_P}&action=status`,
          use: "⭐ All 16 git ops via ?action=. Values: status|add|commit|diff|log|branch|checkout|stash|stash-pop|push|pull|merge|reset|revert|tag|init",
          method: "GET",
          params: { action: "status|add|commit|diff|log|branch|checkout|stash|stash-pop|push|pull|merge|reset|revert|tag|init", msg: "commit message (default: auto-commit)", ref: "branch/ref for checkout|reset", branch: "for merge", commit: "for revert", name: "for tag (required) or branch", count: "for log (default: 10)" },
          checkoutModes: {
            branchSwitch: "action=checkout&ref=BRANCH  →  git checkout BRANCH",
            fileRestore:  "action=checkout&paths=src/App.tsx,src/index.tsx  →  git checkout HEAD -- src/App.tsx src/index.tsx",
            fileRestoreRef: "action=checkout&ref=abc1234&paths=src/App.tsx  →  git checkout abc1234 -- src/App.tsx",
            rawArgs:      "action=checkout&args=HEAD -- src/App.tsx  →  git checkout HEAD -- src/App.tsx  (raw pass-through)",
          },
        },
        grokProcess: {
          url: `${baseUrl}/api/grok-process?project=${_P}&action=list`,
          use: "⭐ Process management via ?action=. Values: start|start-named|stop|list|monitor|logs|stop-all|restart",
          method: "GET",
          params: { action: "start|start-named|stop|list|monitor|logs|stop-all|restart", cmd: "for start/start-named", name: "process name" },
        },
        grokSearch: {
          url: `${baseUrl}/api/grok-search?project=${_P}&q=PATTERN`,
          use: "⭐ Unified search via ?type=. Values: text (default)|symbol|file|usages",
          method: "GET",
          params: { q: "search pattern or query", type: "text (grep)|symbol|file|usages", path: "optional directory to search in" },
        },
        grokQuality: {
          url: `${baseUrl}/api/grok-quality?project=${_P}`,
          use: "⭐ Batch quality checks in parallel. ?checks=all (default) or any of: type,lint,format",
          method: "GET",
        },
        grokDeps: {
          url: `${baseUrl}/api/grok-deps?project=${_P}&action=install`,
          use: "Dependency management. ?action=install (install all deps) | add (add package, ?pkg=NAME&dev=1) | remove (remove package, ?pkg=NAME). Each action dispatches directly to the desktop; no auto-install chaining.",
          method: "GET",
          params: { action: "install|add|remove", pkg: "package name for add/remove" },
        },
        grokSuper: {
          url: `${baseUrl}/api/grok-super?project=${_P}&describe=TEXT`,
          use: "⭐ POWER TOOL — describe any job in plain English, AI plans the exact action sequence. Requires XAI_API env var on desktop.",
          method: "GET",
          params: { describe: "natural language description of the job (canonical)", instruction: "alias for describe (legacy)", project: "required" },
          example: `${baseUrl}/api/grok-super?project=${_P}&describe=add+dark+mode+toggle+to+the+header`,
        },
        grokMacroStatus: {
          url: `${baseUrl}/api/grok-macro/project-status?project=${_P}`,
          use: "Project overview in one call: tree + package.json + git status + preview URL (all parallel)",
          method: "GET",
        },
        grokMacroContext: {
          url: `${baseUrl}/api/grok-macro/read-context?project=${_P}&path=src/App.tsx`,
          use: "Read a file + extract its imports + batch-read imported local files — 3-10 calls in 1",
          method: "GET",
        },
        diag: {
          url: `${baseUrl}/api/diag?project=${_P}`,
          use: "Relay + desktop diagnostics. Runs live list_tree round-trip timing. Shows all endpoint URLs for the connected project.",
          method: "GET",
        },
        coord: {
          url: `${baseUrl}/api/coord`,
          use: "In-memory coordination notes (50-entry ring buffer). ?note=TEXT&from=SOURCE to push. ?clear=1 to clear. No params → last 20. DEDUP: identical note+from within 60 s is silently ignored (idempotent). Use ?force=1 to bypass.",
          method: "GET",
          dedupRule: "Do NOT re-post the same coord note when retrying. If browse_page returns 503 and you already posted a status note, do NOT post it again — the relay deduplicates but the board still shows the duplicate attempt in logs.",
        },

        // ── RAW PROXY (specialized fallback — for action types not in combined endpoints) ──
        grokProxy: {
          url: `${baseUrl}/api/grok-proxy?payload=BASE64`,
          use: "Execute any action(s) by type name. Use for: write_file_chunk, generate_component, deploy_preview, import_project, set_env_var, component_tree, etc.",
          method: "GET",
          encoding: "base64(JSON.stringify({actions:[{type,project,...}]}))",
          note: "All combined endpoints above are wrappers around this — use them first.",
        },
        grokEdit: {
          url: `${baseUrl}/api/grok-edit?project=${_P}&path=FILE&search=OLD&replace=NEW`,
          use: "Legacy search-and-replace shortcut. Prefer grok-write (has auto-verify).",
          method: "GET",
        },

        // ── SCREENSHOT / VISUAL ───────────────────────────────────────────
        screenshotData: {
          url: `${baseUrl}/api/screenshot-data/${_P}`,
          use: "⭐ Serves the latest screenshot PNG from relay memory. Browse this URL to see the app.",
          method: "GET",
        },
        screenshotUrl: {
          url: `${baseUrl}/api/screenshot-url/${_P}?fullPage=true&waitMs=30000`,
          use: "Triggers a new screenshot, returns the /api/screenshot-data URL as plain text.",
          method: "GET",
        },
        liveView: {
          url: `${baseUrl}/live/${_P}`,
          use: "Auto-refreshing screenshot view. Human monitoring.",
        },
        bridgeStatus: {
          url: `${baseUrl}/api/bridge-status`,
          use: "Public health check — shows connected desktop count and project names.",
        },
        commands: {
          url: `${baseUrl}/api/commands`,
          use: "Flat list of all supported action type strings.",
        },
        grokInteract: {
          url: `${baseUrl}/api/grok-interact?project=${_P}&action=click&selector=%23btn`,
          use: "⛔ STANDALONE CONNECTOR MODE — requires full Electron app with Chromium. Returns {supported:false}.",
        },
      },

      // ═══════════════════════════════════════════════════════════════════
      // 9. COMMAND CATEGORIES — organized by purpose
      // ═══════════════════════════════════════════════════════════════════
      commandCategories: {
        desktopControl: {
          desc: "⭐ DESKTOP CONTROL — use /api/grok-do?chain= for all browser, app, shell, and system tasks. See desktopControl section above.",
          endpoint: "/api/grok-do?chain=STEP1|STEP2|STEP3",
          stepTypes: ["run", "wait", "snapshot", "click", "nav", "eval", "type_text", "screenshot", "focus", "launch", "paste", "keys", "click_at", "list_windows", "tabs"],
          note: "Do NOT call individual desktop endpoints. Use grok-do chains instead — they run faster (no throttle between steps) and let you do multi-step tasks in one call.",
        },
        discovery: {
          desc: "Understand the project structure before making any changes",
          commands: ["list_tree", "list_tree_filtered", "read_file", "read_multiple_files", "detect_structure", "project_analyze", "extract_imports", "dependency_graph", "component_tree", "extract_theme", "extract_colors"],
        },
        search: {
          desc: "Find code, patterns, or symbols across files",
          commands: ["grep", "grep_search", "grep_advanced", "search_files", "glob_search", "symbol_search", "find_usages", "dead_code_detection"],
        },
        fileWrite: {
          desc: "Write files — choose based on content size",
          commands: ["search_replace", "write_file", "write_file_chunk", "create_file", "bulk_write", "apply_patch"],
          sizeGuide: "< 2 KB → write_file | > 2 KB → write_file_chunk (chunks of ~1500 chars) | targeted edit → search_replace (preferred)",
        },
        fileManage: {
          desc: "Move, copy, rename, delete files and folders",
          commands: ["delete_file", "move_file", "copy_file", "rename_file", "move_folder", "rename_folder", "create_folder", "delete_folder", "bulk_delete", "rollback_last_change"],
        },
        dependencies: {
          desc: "Manage npm/pnpm packages — always install_deps after add_dependency",
          commands: ["install_deps", "add_dependency", "remove_dependency", "update_package_json", "manage_scripts", "security_scan"],
          warning: "add_dependency alone only edits package.json — must follow with install_deps to actually install",
        },
        quality: {
          desc: "Type checking, linting, formatting, testing",
          commands: ["type_check", "lint_and_fix", "format_files", "validate_change", "run_tests", "tailwind_audit"],
        },
        build: {
          desc: "Build and deploy",
          commands: ["build_project", "get_build_metrics"],
        },
        shell: {
          desc: "Run arbitrary commands on Windows (PowerShell)",
          commands: ["run_command", "run_command_advanced"],
          note: "Use PowerShell syntax. Project cwd is auto-set. Avoid Unix-only tools.",
        },
        processes: {
          desc: "Manage dev servers and background processes",
          commands: ["restart_dev_server", "get_preview_url", "list_open_ports", "start_process", "start_process_named", "kill_process", "list_processes", "stop_all_processes", "monitor_process", "get_process_logs"],
        },
        git: {
          desc: "Full git workflow",
          commands: ["git_status", "git_diff", "git_add", "git_commit", "git_log", "git_branch", "git_checkout", "git_push", "git_pull", "git_merge", "git_stash", "git_stash_pop", "git_reset", "git_revert", "git_tag", "git_init"],
        },
        environment: {
          desc: "Environment variables",
          commands: ["set_env_var", "get_env_vars"],
        },
        screenshot: {
          desc: "Visual verification — use HTTP endpoints, not commands, for screenshots",
          note: "Use GET /api/screenshot-url or /api/screenshot-image. screenshot_preview available via grok-proxy action.",
          available: ["screenshot_preview (via grok-proxy)", "get_dom_snapshot (via grok-proxy)", "capture_preview (via grok-proxy)", "get_console_errors (via grok-proxy)"],
          puppeteerRequired: ["capture_component (needs npm i puppeteer)", "visual_diff (needs npm i puppeteer)"],
          unavailable: ["browser_interact ⛔ (requires Electron Chromium)"],
        },
        aiRequired: {
          desc: "Commands that require XAI_API env var set on the desktop connector",
          commands: ["generate_component", "generate_page", "generate_test", "refactor_file", "optimize_code", "super_command"],
          shortcut: "Use /api/grok-super?describe=TEXT to invoke super_command as a plain GET. Other AI commands require grok-proxy with the action type + XAI_API set.",
        },
        unavailable: {
          desc: "Commands that require full Electron app with Chromium — not available in standalone connector",
          commands: ["browser_interact", "switch_port"],
          workaround: "Use screenshot_preview + search_replace/write_file for edit-and-verify loop. Use manage_scripts to change the dev server port.",
        },
      },

      // ═══════════════════════════════════════════════════════════════════
      // 10. WRITE_FILE_CHUNK DEEP DIVE
      // ═══════════════════════════════════════════════════════════════════
      writeFileChunkGuide: {
        when: "Any file content > 2 KB — React components, pages, full TypeScript modules, CSS files, JSON config",
        why: "GET URLs max out at ~8 KB total. A 5 KB component in a write_file URL gets truncated mid-file. The written file is corrupted and the app breaks silently.",
        howItWorks: [
          "Split content into chunks of ~1500 chars each (safe below URL limit with encoding overhead)",
          "Send chunk_index:0 first, then 1, 2, ... up to total_chunks-1",
          "Relay buffers chunks in memory keyed by 'project:path'",
          "On final chunk: relay assembles in order, writes the complete file atomically",
          "Returns {done:true, bytes:N} on the final chunk",
          "Intermediate chunks return {received:N, waiting_for:M, done:false}",
        ],
        chunkFields: {
          type: "write_file_chunk",
          project: "groks-app",
          path: "src/components/App.tsx",
          chunk_index: "0-based index of this chunk",
          total_chunks: "total number of chunks",
          content: "the ~1500-char slice of the file content",
        },
        staleness: "Incomplete writes are purged after 5 minutes. If you start a chunked write, finish it.",
        verification: "After done:true, always read_file to confirm the assembled content is correct before running type_check or build.",
      },

      // ═══════════════════════════════════════════════════════════════════
      // 11. FULL COMMAND LIST
      // ═══════════════════════════════════════════════════════════════════
      totalCommands: commands.length,
      commands,
    };
    // Replace all placeholder project names with the real connected project.
    // Grok copies the "project" field from examples literally into its API calls —
    // if they say "my-app" or "YOUR_PROJECT_NAME", every command will fail.
    const _grokJson = JSON.stringify(_grokResponseObj)
      .replace(/"my-app"/g, JSON.stringify(_P))
      .replace(/"YOUR_PROJECT_NAME"/g, JSON.stringify(_P))
      .replace(/YOUR_PROJECT_NAME/g, _P);
    res.writeHead(200, {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
    });
    res.end(_grokJson);
    return;
  }
  if (pathname === "/api/grok-chat-prompt") {
    const host = req.headers.host || `localhost:${PORT}`;
    const protocol = req.headers["x-forwarded-proto"] || "https";
    const base = `${protocol}://${host}`;
    const connectedProject = (() => { for (const c of desktopClients.values()) { if (c.alive && c.project) return c.project; } return null; })();
    const P = url.searchParams.get("project") || connectedProject || "YOUR_PROJECT_NAME";
    const snapshotUrl   = `${base}/api/snapshot/${P}`;
    const consoleUrl    = `${base}/api/console-logs?project=${P}`;
    const editUrl       = `${base}/api/grok-edit?project=${P}`;
    const interactUrl   = `${base}/api/grok-interact?project=${P}`;
    const proxyUrl      = `${base}/api/grok-proxy?project=${P}`;
    const screenshotUrl = `${base}/api/screenshot/${P}?fullPage=true&waitMs=8000`;
    const discoveryUrl  = `${base}/api/grok`;
    const readUrl    = `${base}/api/grok-read?project=${P}&path=`;
    const writeUrl   = `${base}/api/grok-write?project=${P}&path=`;
    const treeUrl    = `${base}/api/grok-tree?project=${P}`;
    const gitUrl     = `${base}/api/grok-git?project=${P}&action=`;
    const runUrl     = `${base}/api/grok-run?project=${P}&cmd=`;
    const searchUrl  = `${base}/api/grok-search?project=${P}&q=`;
    const qualityUrl = `${base}/api/grok-quality?project=${P}`;
    const superUrl   = `${base}/api/grok-super?project=${P}&describe=`;
    const diagUrl    = `${base}/api/diag?project=${P}`;
    const prompt = `=== ACTIVE PROJECT: ${P} ===

=== LAMBY WORKSPACE API (YOU HAVE FULL READ/WRITE ACCESS — USE IT) ===
You are Grok-4 working inside Lamby with full bridge-relay access. Your ONLY web tool is browse_page (GET-only).

DISCOVERY (call FIRST to see all live endpoints and confirm desktop is connected):
  GET ${discoveryUrl}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
DESKTOP CONTROL (grok-do chains — YOUR PRIMARY TOOL)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

For ALL desktop interaction (browser, apps, shell, system), use grok-do chains:
  GET ${base}/api/grok-do?chain=STEP1|STEP2|STEP3

Step types: run:COMMAND | wait:MS | snapshot | click:SELECTOR | nav:URL | eval:JS
            type_text:SELECTOR>>>TEXT | screenshot:TITLE | focus:TITLE | launch:PATH
            paste:TEXT | keys:KEYS | click_at:X,Y | list_windows | tabs

Examples:
  Open website:     GET ${base}/api/grok-do?chain=run:start chrome https://google.com|wait:5000|snapshot
  Google search:    GET ${base}/api/grok-do?chain=run:start chrome https://www.google.com/search?q=weather|wait:6000|snapshot
  Run shell cmd:    GET ${base}/api/grok-do?chain=run:dir C:\\Users\\Aiden\\Desktop
  System info:      GET ${base}/api/grok-do?chain=run:systeminfo | findstr /C:"OS Name"
  Screenshot:       GET ${base}/api/grok-do?chain=list_windows|screenshot:Chrome

Rules:
  - ALWAYS use ?chain= for multi-step desktop tasks (1 call instead of many)
  - Use snapshot to see page content — returns DOM text, buttons, inputs, links with CSS selectors
  - Use selectors FROM snapshot results to click/type. Never guess selectors.
  - Add wait:5000-8000 after opening pages to let them load

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
CODE EDITING ENDPOINTS (for project files — no base64 encoding needed)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

READ files — single file:
  GET ${readUrl}src/App.tsx
  Multi-file: GET ${base}/api/grok-read?project=${P}&files=src/App.tsx,src/main.ts

WRITE / EDIT files (search_replace + auto-verify in one call):
  GET ${writeUrl}src/App.tsx&search=oldText&replace=newText
  Base64 variant (special chars): ${writeUrl}src/App.tsx&searchB64=BASE64OLD&replaceB64=BASE64NEW
  Apply patch mode: ${writeUrl}src/App.tsx&patch=UNIFIED_DIFF_CONTENT
  Returns zeroReplacements:true if string not found — read the file first to get exact text.

CREATE / OVERWRITE files (no base64 encoding — content is URL-encoded automatically):
  GET ${base}/api/grok-create?project=${P}&path=src/newFile.ts&content=FILE_CONTENT_HERE
  Overwrites the file completely. Use for new files or full rewrites.
  Special chars: use ?contentB64=URL_SAFE_BASE64 instead of ?content=

CHUNKED FILE WRITE (for files > ~1500 chars — send content in pieces):
  GET ${base}/api/grok-create-chunk?project=${P}&path=src/big.ts&content=CHUNK0&chunk=0&total=3
  GET ${base}/api/grok-create-chunk?project=${P}&path=src/big.ts&content=CHUNK1&chunk=1&total=3
  GET ${base}/api/grok-create-chunk?project=${P}&path=src/big.ts&content=CHUNK2&chunk=2&total=3
  ALL chunks use write_file_chunk. Desktop accumulates in memory; file writes to disk ONLY on final chunk.
  Chunks MUST be sent in order (0, 1, 2, ...). Do NOT skip chunks. Returns {done:true} on last chunk.

DELETE files:
  GET ${base}/api/grok-delete?project=${P}&path=src/oldFile.ts

FILE TREE:
  GET ${treeUrl}
  Path/name filter (relay layer): ${treeUrl}&filter=src      (keeps entries containing "src")
  Extension filter (on desktop):  ${treeUrl}&ext=.tsx        (efficient: only .tsx files returned)
  Combined: ${treeUrl}&filter=components&ext=.tsx

RUN COMMANDS (runs on Windows/PowerShell):
  GET ${runUrl}npm+run+build
  Advanced (with flags): GET ${base}/api/grok-run?project=${P}&cmd=tsc&flags=--noEmit

GIT:
  GET ${gitUrl}status
  GET ${gitUrl}commit&msg=fix%3A+update+styles
  GET ${gitUrl}add    (stages all)
  GET ${gitUrl}push
  GET ${gitUrl}log&count=10
  Branch switch: GET ${gitUrl}checkout&ref=BRANCH
  File restore:  GET ${gitUrl}checkout&paths=src/App.tsx,src/main.tsx    (restores to HEAD)
  File restore at ref: GET ${gitUrl}checkout&ref=abc1234&paths=src/App.tsx
  Raw args:      GET ${gitUrl}checkout&args=HEAD+--+src/App.tsx           (pass-through)
  Other: add|diff|branch|stash|stash-pop|pull|merge&branch=BRANCH|reset|revert&commit=HASH|tag&name=v1.0.0|init

SEARCH (no encoding needed):
  GET ${searchUrl}TODO                     (text/grep — default)
  GET ${searchUrl}handleClick&type=symbol  (find function/class definitions)
  GET ${searchUrl}Button&type=file         (filename search)
  GET ${searchUrl}fetchUser&type=usages    (find all usages of a symbol)

QUALITY (batch type-check + lint + format in one call):
  GET ${qualityUrl}                        (all checks)
  GET ${qualityUrl}&checks=type,lint       (specific checks)

PROJECT STATUS (tree + package.json + git status + preview URL in one call):
  GET ${base}/api/grok-macro/project-status?project=${P}

READ-CONTEXT (read file + its imports + imported files in one call):
  GET ${base}/api/grok-macro/read-context?project=${P}&path=src/App.tsx

AI SUPER COMMAND (describe in plain English — requires XAI_API on desktop):
  GET ${superUrl}add+a+dark+mode+toggle+to+the+header
  Note: Use ?describe= as the param name. Super command uses Grok-3-mini to plan the exact actions.

GRAPH INTELLIGENCE (dependency + impact analysis — builds from source on first call):
  GET ${base}/api/grok-graph?project=${P}&action=index                   (build/rebuild graph)
  GET ${base}/api/grok-graph?project=${P}&action=query&node=src/App.tsx  (inspect node + edges)
  GET ${base}/api/grok-graph?project=${P}&action=impact&file=src/App.tsx (files affected by change)
  GET ${base}/api/grok-graph?project=${P}&action=pattern&q=hooks         (structural pattern search)
  GET ${base}/api/grok-graph?project=${P}&action=invalidate              (clear cached graph)

CHANGESET BATCH OPS (validate/apply/simulate a set of file changes atomically):
  1. Build ops array: JSON.stringify([{type:"write_file",path:"src/App.tsx",content:"..."},])
  2. Encode: btoa(opsJson)  →  OPS_BASE64
  GET ${base}/api/grok-changeset?project=${P}&action=validate&ops=OPS_BASE64          (dry-run: syntax + type-check)
  GET ${base}/api/grok-changeset?project=${P}&action=apply&ops=OPS_BASE64             (validate then write to disk)
  GET ${base}/api/grok-changeset?project=${P}&action=apply&ops=OPS_BASE64&skipValidation=1  (write without check)
  GET ${base}/api/grok-changeset?project=${P}&action=simulate&ops=OPS_BASE64          (validate + build + 8s runtime check)
  Op types supported: write_file, create_file, delete_file, rename_file, move_file

DIAGNOSTICS:
  GET ${diagUrl}  (relay health + live round-trip timing + endpoint URLs)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SNAPSHOT & SCREENSHOTS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

READ THE FULL PROJECT (files, package.json, git status):
  GET ${snapshotUrl}

SCREENSHOT (browse this URL to view the app — always wait 15s after edits):
  GET ${screenshotUrl}

CHECK DEV SERVER LOGS:
  GET ${consoleUrl}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
ADVANCED: RAW PROXY (for actions not in combined endpoints)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Use for: generate_component (XAI_API required), install_deps, set_env_var, and any action not covered by the combined endpoints above.
  Note: For large files prefer grok-create-chunk (no encoding) over write_file_chunk via proxy.
  Option A (easiest): URL-encode raw JSON → ${proxyUrl}&payload=encodeURIComponent(JSON)
  Option B: Base64-encode JSON → ${proxyUrl}&payload=btoa(JSON)
  1. Build: { "actions": [ {type, project:"${P}", ...} ] }
  2. Encode (Option A or B)
  3. Browse: ${proxyUrl}&payload=ENCODED
Max 50 actions per request. Keep JSON under 6000 chars before encoding.

CRITICAL PATIENCE PROTOCOL (MANDATORY):
- Wait 15 seconds after ANY edit before taking a screenshot or performing the next action.
- Always use fullPage=true&waitMs=8000 (or 10000ms for complex pages) on screenshot URLs.
- On 503: This means the bridge is temporarily disconnected but your PREVIOUS commands may have already succeeded. Wait 10s, then verify results (list_windows, check file existence, etc). Do NOT immediately re-send the same command. Only retry after verifying the previous attempt did not work.
- Never claim success unless you saw {"success":true} or results[0].data.success=true.
- For zero replacements: read the file first, copy the EXACT text (whitespace matters), then retry.
- LARGE FILES (> 2KB): use grok-create-chunk. Split into ~1500-char chunks (chunk=0 creates, chunk>0 appends).
- COORD DEDUP: Never re-post the same coord note when retrying. The relay deduplicates (60s window) — posting again returns {deduplicated:true} without adding a new entry. If you really need to force a re-post, add &force=1.

Project name: ${P}
Status: Active project.
=== END WORKSPACE API ===
`;
    res.writeHead(200, {
      "Content-Type": "text/plain; charset=utf-8",
      "Access-Control-Allow-Origin": "*",
      "Cache-Control": "no-store",
    });
    res.end(prompt);
    return;
  }
  if (pathname === "/api/commands") {
    const commands = [
      "list_tree", "read_file", "read_multiple_files", "write_file", "write_file_chunk", "create_file",
      "delete_file", "bulk_delete", "move_file", "copy_file", "copy_folder", "rename_file",
      "grep", "search_files", "search_replace", "apply_patch", "bulk_write",
      "run_command", "install_deps", "add_dependency", "remove_dependency",
      "type_check", "lint_and_fix", "format_files", "get_build_metrics",
      "restart_dev_server", "list_open_ports",
      "git_status", "git_add", "git_commit", "git_diff", "git_log",
      "git_branch", "git_checkout", "git_stash", "git_init", "git_push",
      "git_pull", "git_merge", "git_stash_pop", "git_reset", "git_revert", "git_tag",
      "detect_structure", "start_process", "kill_process", "list_processes",
      "build_project", "run_tests", "archive_project", "export_project",
      "set_env_var", "get_env_vars", "rollback_last_change",
      "project_analyze", "tailwind_audit", "find_usages", "component_tree",
      "extract_theme", "extract_colors", "capture_preview", "get_preview_url",
      "generate_component", "generate_page", "refactor_file",
      "validate_change", "profile_performance",
      "create_folder", "delete_folder", "move_folder", "rename_folder",
      "list_tree_filtered", "dead_code_detection", "dependency_graph",
      "symbol_search", "grep_advanced", "extract_imports",
      "run_command_advanced", "build_with_flags", "clean_build_cache",
      "start_process_named", "monitor_process", "get_process_logs",
      "stop_all_processes", "switch_port",
      "visual_diff", "capture_component", "record_video",
      "get_dom_snapshot", "get_console_errors",
      "generate_test", "generate_storybook", "optimize_code",
      "convert_to_typescript", "add_feature", "migrate_framework",
      "react_profiler", "memory_leak_detection", "console_error_analysis",
      "runtime_error_trace", "bundle_analyzer", "network_monitor",
      "accessibility_audit", "security_scan",
      "set_tailwind_config", "set_next_config", "update_package_json",
      "manage_scripts", "switch_package_manager",
      "deploy_preview", "export_project_zip", "import_project", "super_command",
      "graph_index", "graph_query", "impact_analysis", "pattern_search", "graph_invalidate_cache",
      "changeset_validate", "changeset_apply", "changeset_simulate"
    ];
    sendJson(res, {
      total: commands.length,
      commands,
      usage: "POST /api/sandbox/execute with {actions: [{type: '<command>', project: 'name', ...params}]}",
      grokProxy: {
        endpoint: "GET /api/grok-proxy",
        params: { payload: "raw URL-encoded JSON, base64(JSON), or base64(gzip(JSON))" },
        encodingOptions: "Option A (easiest): pass raw JSON URL-encoded — encodeURIComponent(JSON.stringify({actions:[...]})) — no btoa needed. Option B: btoa(JSON.stringify({actions:[...]})) — base64. Option C: base64(gzip(JSON)) for large payloads.",
        largeFileRule: "For file content > 2 KB use grok-create-chunk (split into ~1500-char chunks, chunk=0..N-1, total=N) — no encoding needed at all."
      }
    });
    return;
  }

  if (pathname === "/api/connector-download") {
    try {
      const connPath = path.join(__dirname, "bridge-connector.cjs");
      const content = fs.readFileSync(connPath, "utf8");
      res.writeHead(200, { "Content-Type": "application/javascript", "Content-Disposition": "attachment; filename=bridge-connector.cjs", "Access-Control-Allow-Origin": "*" });
      res.end(content);
    } catch (err) {
      res.writeHead(500, { "Content-Type": "text/plain" });
      res.end("Connector file not found: " + err.message);
    }
    return;
  }

  // /api/grok-reference — serve the full Grok reference document (docs/grok-reference.md)
  if (pathname === "/api/grok-reference") {
    try {
      const refPath = path.join(__dirname, "docs", "grok-reference.md");
      const content = fs.readFileSync(refPath, "utf8");
      res.writeHead(200, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" });
      res.end(JSON.stringify({ content, path: "docs/grok-reference.md", bytes: Buffer.byteLength(content) }));
    } catch (err) {
      sendGrokOk(res, "noted", "Reference doc not found: " + err.message);
    }
    return;
  }

  if (pathname === "/api/self-test") {
    const startTs = Date.now();
    const checks = [];
    function chk(id, name, pass, ms, err) {
      checks.push({ id, name, pass, ms: ms || 0, ...(err ? { error: err } : {}) });
    }
    // A01 — relay health
    chk("A01", "/health endpoint", true, 0);
    // A02 — bridge-status
    const _diagAlive = [...desktopClients.values()].filter(c => c.alive);
    const connectedCount = desktopClients.size;
    const aliveCount = _diagAlive.length;
    chk("A02", "bridge-status", true, 0);
    // A03 — grok docs built
    chk("A03", "/api/grok docs", true, 0);
    // A05 — JSON repair smoke test
    try {
      const bad = '{"a":1,"b":2,}';
      const repaired = repairJson(bad);
      const parsed = JSON.parse(repaired);
      chk("A05", "JSON auto-repair", parsed.a === 1 && parsed.b === 2, 0);
    } catch (e) { chk("A05", "JSON auto-repair", false, 0, e.message); }
    // A06 — gzip detection (relay decodes gzip payloads)
    try {
      const zlib = require("zlib");
      const sample = JSON.stringify({ actions: [{ type: "list_tree", project: "test" }] });
      const gz = zlib.gzipSync(Buffer.from(sample));
      const b64 = gz.toString("base64");
      const decompressed = zlib.gunzipSync(Buffer.from(b64, "base64")).toString("utf-8");
      const parsed = JSON.parse(decompressed);
      chk("A06", "gzip base64 decode", parsed.actions?.[0]?.type === "list_tree", 0);
    } catch (e) { chk("A06", "gzip base64 decode", false, 0, e.message); }
    // A07 — desktop connected?
    const desktopConnected = aliveCount > 0;
    chk("desktop", "desktop connected", desktopConnected, 0, desktopConnected ? null : `${aliveCount}/${connectedCount} clients alive`);
    // A08 — pending requests maps healthy
    chk("A08", "pending maps empty", pendingRelayRequests.size < 1000, 0);
    // A09 — screenshot cache healthy
    chk("A09", "screenshot cache", screenshotCache.size < 10000, 0);
    // A10 — real desktop roundtrip (dispatch get_preview_url and verify url field)
    if (desktopConnected) {
      const t10 = Date.now();
      try {
        // Find any alive client and the project it's serving
        let liveClientA10, projectA10;
        for (const c of desktopClients.values()) {
          if (c.alive && c.project) { liveClientA10 = c; projectA10 = c.project; break; }
        }
        if (liveClientA10) {
          const requestIdA10 = crypto.randomUUID();
          const promiseA10 = new Promise((resolve) => {
            const timer = setTimeout(() => {
              pendingSandboxRelayRequests.delete(requestIdA10);
              resolve(null); // timeout
            }, 6000);
            // Use the same map the WebSocket response handler resolves from
            pendingSandboxRelayRequests.set(requestIdA10, {
              resolve: (data) => { clearTimeout(timer); pendingSandboxRelayRequests.delete(requestIdA10); resolve(data); },
              timer
            });
          });
          liveClientA10.send(JSON.stringify({ type: "sandbox-execute-request", requestId: requestIdA10, actions: [{ type: "get_preview_url", project: projectA10 }] }));
          const rawA10 = await promiseA10;
          const ms10 = Date.now() - t10;
          if (rawA10 === null) {
            chk("A10", "desktop roundtrip", false, ms10, "timeout after 6s");
          } else {
            try {
              const parsed10 = JSON.parse(rawA10);
              const result10 = parsed10.results?.[0]?.data;
              chk("A10", "desktop roundtrip", !!(result10?.url), ms10, result10?.url ? null : "response missing url field");
            } catch (e) { chk("A10", "desktop roundtrip", false, ms10, "response parse error: " + e.message); }
          }
        } else {
          chk("A10", "desktop roundtrip", false, 0, "no alive client with project found");
        }
      } catch (e) { chk("A10", "desktop roundtrip", false, Date.now() - t10, e.message); }
    } else {
      chk("A10", "desktop roundtrip", false, 0, "skipped — no desktop connected");
    }
    const passed = checks.filter(c => c.pass).length;
    const total = checks.length;
    const relayOk = checks.filter(c => c.id !== "desktop" && c.id !== "A10").every(c => c.pass);
    sendJson(res, {
      relay: relayOk ? "ok" : "degraded",
      checks,
      passed,
      total,
      desktopConnected,
      connectedClients: aliveCount,
      uptimeSec: Math.floor(process.uptime()),
      testedIn: Date.now() - startTs + "ms",
    });
    return;
  }

  // ── Shared screenshot helper ─────────────────────────────────────────────
  // Handles /api/screenshot/, /api/screenshot-url/, /api/screenshot-image/
  // format: "json" | "text" | "redirect"
  async function handleScreenshot(req, res, project, format) {
    const fullPage = url.searchParams.get("fullPage") === "true" || url.searchParams.get("fullPage") === "1";
    const waitMs   = parseInt(url.searchParams.get("waitMs") || "0", 10) || 0;
    const selector = url.searchParams.get("selector") || "";
    // Key excludes waitMs — requests with different waitMs share same dedup slot
    const screenshotKey = `${project}:${fullPage ? "true" : ""}:${selector}`;
    const lastGoodUrl = screenshotLastGood.get(project)?.url || null;

    function flushWaiter(w, resultStr, screenshotUrl) {
      const r = w.res; const fmt = w.format;
      if (r.writableEnded) return;
      try {
        if (fmt === "text") {
          const u = screenshotUrl || lastGoodUrl || "Error: no screenshot URL available";
          r.writeHead(200, { "Content-Type": "text/plain", "Access-Control-Allow-Origin": "*" });
          r.end(u);
        } else if (fmt === "redirect") {
          const u = screenshotUrl || lastGoodUrl;
          if (u) { r.writeHead(302, { "Location": u, "Access-Control-Allow-Origin": "*" }); r.end(); }
          else { r.writeHead(200, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }); r.end(JSON.stringify({ success: true, status: "processing", message: "Screenshot is being captured — try again shortly." })); }
        } else {
          r.writeHead(200, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" });
          r.end(resultStr);
        }
      } catch {}
    }

    // 1. Cache hit
    const cached = screenshotCache.get(screenshotKey);
    if (cached && cached.expiresAt > Date.now()) {
      relayLog("info", `SCREENSHOT cache hit key=${screenshotKey} expiresIn=${Math.round((cached.expiresAt - Date.now()) / 1000)}s`);
      let cachedUrl = null;
      try { cachedUrl = JSON.parse(cached.result)?.results?.[0]?.data?.screenshotUrl || null; } catch {}
      flushWaiter({ res, format }, cached.result, cachedUrl);
      return;
    }

    // 2. In-flight dedup — join existing request (even if still waiting for client)
    if (pendingScreenshots.has(screenshotKey)) {
      const existing = pendingScreenshots.get(screenshotKey);
      existing.maxWaitMs = Math.max(existing.maxWaitMs || 0, waitMs || 0);
      const waiter = { res, format };
      existing.waiters.add(waiter);
      req.on("close", () => existing.waiters.delete(waiter));
      relayLog("info", `SCREENSHOT dedup — joining key=${screenshotKey} waiters=${existing.waiters.size} maxWaitMs=${existing.maxWaitMs} reqId=${existing.requestId ? existing.requestId.substring(0, 8) + "..." : "pending-client"}`);
      return;
    }

    // 3. Register stub entry NOW (before async waitForClient) so concurrent requests join above
    const waiters = new Set();
    const waiter = { res, format };
    waiters.add(waiter);
    req.on("close", () => waiters.delete(waiter));
    pendingScreenshots.set(screenshotKey, { requestId: null, timer: null, waiters, maxWaitMs: waitMs });

    // 4. Wait for desktop client
    const liveClient = await waitForClient(project);
    if (!liveClient) {
      pendingScreenshots.delete(screenshotKey);
      relayLog("warn", `SCREENSHOT 503 no alive client waiters=${waiters.size}`);
      for (const w of waiters) {
        if (w.res.writableEnded) continue;
        try { flushWaiter(w, JSON.stringify({ error: "No desktop client connected.", last_good_url: lastGoodUrl, hint: "Start your Lamby desktop app." }), null); } catch {}
      }
      return;
    }

    // 5. Send to desktop — fill in requestId on the existing entry
    const requestId = crypto.randomUUID();
    const timer = setTimeout(() => {
      const sc = pendingScreenshots.get(screenshotKey);
      if (sc && sc.requestId === requestId) {
        pendingScreenshots.delete(screenshotKey);
        relayLog("warn", `SCREENSHOT TIMEOUT 120s key=${screenshotKey} waiters=${sc.waiters.size}`);
        for (const w of sc.waiters) {
          if (w.res.writableEnded) continue;
          try { flushWaiter(w, JSON.stringify({ error: "Relay timeout — desktop did not respond within 120 seconds.", last_good_url: lastGoodUrl }), null); } catch {}
        }
      }
    }, 120000);

    const entry = pendingScreenshots.get(screenshotKey);
    if (entry) { entry.requestId = requestId; entry.timer = timer; }

    try {
      const effectiveWaitMs = entry ? entry.maxWaitMs : waitMs;
      const screenshotAction = { type: "screenshot_preview", project,
        ...(fullPage         ? { fullPage: true } : {}),
        ...(effectiveWaitMs  ? { waitMs: effectiveWaitMs } : {}),
        ...(selector         ? { selector } : {}) };
      relayLog("info", `SCREENSHOT →Desktop reqId=${requestId.substring(0, 8)}... project=${project} fullPage=${fullPage} waitMs=${effectiveWaitMs}`);
      liveClient.send(JSON.stringify({ type: "sandbox-execute-request", requestId, actions: [screenshotAction] }));
    } catch (sendErr) {
      pendingScreenshots.delete(screenshotKey);
      clearTimeout(timer);
      relayLog("error", `SCREENSHOT send failed: ${sendErr.message}`);
      for (const w of waiters) {
        if (w.res.writableEnded) continue;
        try { flushWaiter(w, JSON.stringify({ error: "Could not reach desktop app." }), null); } catch {}
      }
    }
    // (screenshot result logged inside WS fan-out — see SCREENSHOT-RELAY handler)
    // Response delivered asynchronously by WS fan-out
  }

  if (pathname.startsWith("/api/screenshot/")) {
    const project = pathname.replace("/api/screenshot/", "").split("/").filter(Boolean).join("/") || "";
    if (!project) {
      res.writeHead(400, { "Content-Type": "text/plain", "Access-Control-Allow-Origin": "*" });
      res.end("Usage: GET /api/screenshot/PROJECT?fullPage=true&waitMs=30000");
      return;
    }
    try { await handleScreenshot(req, res, project, "json"); }
    catch (err) {
      relayLog("error", `SCREENSHOT unhandled error: ${err.message}`);
      if (!res.writableEnded) { try { res.writeHead(200, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }); res.end(JSON.stringify({ success: true, status: "processing", message: "Screenshot processing. " + err.message })); } catch {} }
    }
    return;
  }

  // ── /api/screenshot-data/:project — serve PNG from relay memory (no catbox, 100% reliable) ──
  if (pathname.startsWith("/api/screenshot-data/")) {
    const project = pathname.replace("/api/screenshot-data/", "").split("/").filter(Boolean).join("/") || "";
    if (!project) {
      res.writeHead(400, { "Content-Type": "text/plain", "Access-Control-Allow-Origin": "*" });
      res.end("Usage: GET /api/screenshot-data/PROJECT");
      return;
    }
    const cached = screenshotDataCache.get(project);
    if (!cached) {
      res.writeHead(404, { "Content-Type": "text/plain", "Access-Control-Allow-Origin": "*" });
      res.end(`No screenshot cached for project "${project}". Run screenshot_preview via /api/grok-proxy first.`);
      return;
    }
    const buf = Buffer.from(cached.base64, "base64");
    const ageMs = Date.now() - cached.capturedAt;
    res.writeHead(200, {
      "Content-Type": cached.mimeType || "image/png",
      "Content-Length": buf.length,
      "Cache-Control": "no-store",
      "X-Captured-At": new Date(cached.capturedAt).toISOString(),
      "X-Age-Ms": ageMs,
      "Access-Control-Allow-Origin": "*",
    });
    res.end(buf);
    return;
  }

  if (pathname === "/api/grok-last-screenshot") {
    if (!_lastGrokScreenshot) {
      res.writeHead(404, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" });
      res.end(JSON.stringify({ error: "No screenshot available yet. Run a grok-do chain with a screenshot step first.", hint: "Example: /api/grok-do?chain=screenshot:Blender" }));
      return;
    }
    const accept = (req.headers.accept || "").toLowerCase();
    if (accept.includes("image/") || accept.includes("*/*") || url.searchParams.get("format") === "image") {
      const buf = Buffer.from(_lastGrokScreenshot.base64, "base64");
      res.writeHead(200, {
        "Content-Type": _lastGrokScreenshot.mimeType || "image/png",
        "Content-Length": buf.length,
        "Cache-Control": "no-store",
        "X-Captured-At": new Date(_lastGrokScreenshot.capturedAt).toISOString(),
        "X-Source": _lastGrokScreenshot.source || "unknown",
        "Access-Control-Allow-Origin": "*",
      });
      res.end(buf);
      return;
    }
    res.writeHead(200, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" });
    res.end(JSON.stringify({
      available: true,
      capturedAt: new Date(_lastGrokScreenshot.capturedAt).toISOString(),
      ageMs: Date.now() - _lastGrokScreenshot.capturedAt,
      source: _lastGrokScreenshot.source,
      imageUrl: `${baseUrl}/api/grok-last-screenshot?format=image`,
      base64Length: _lastGrokScreenshot.base64.length,
    }));
    return;
  }

  if (pathname.startsWith("/api/screenshot-url/")) {
    const project = pathname.replace("/api/screenshot-url/", "").split("/").filter(Boolean).join("/") || "";
    if (!project) {
      res.writeHead(400, { "Content-Type": "text/plain", "Access-Control-Allow-Origin": "*" });
      res.end("Usage: GET /api/screenshot-url/PROJECT?fullPage=true&waitMs=30000\nReturns: plain-text catbox.moe URL (no JSON parsing needed)");
      return;
    }
    try { await handleScreenshot(req, res, project, "text"); }
    catch (err) {
      relayLog("error", `SCREENSHOT-URL unhandled error: ${err.message}`);
      if (!res.writableEnded) { try { res.writeHead(200, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }); res.end(JSON.stringify({ success: true, status: "processing", message: "Processing. " + err.message })); } catch {} }
    }
    return;
  }

  if (pathname.startsWith("/api/screenshot-image/")) {
    const project = pathname.replace("/api/screenshot-image/", "").split("/").filter(Boolean).join("/") || "";
    if (!project) {
      res.writeHead(400, { "Content-Type": "text/plain", "Access-Control-Allow-Origin": "*" });
      res.end("Usage: GET /api/screenshot-image/PROJECT\nRedirects (302) directly to the screenshot image — browse this URL to view the app screenshot.");
      return;
    }
    try { await handleScreenshot(req, res, project, "redirect"); }
    catch (err) {
      relayLog("error", `SCREENSHOT-IMAGE unhandled error: ${err.message}`);
      if (!res.writableEnded) { try { res.writeHead(200, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }); res.end(JSON.stringify({ success: true, status: "processing", message: "Processing. " + err.message })); } catch {} }
    }
    return;
  }

  if (pathname === "/api/grok-interact") {
    if (req.method !== "GET") { res.writeHead(405); res.end("Method not allowed"); return; }
    try {
      const project = url.searchParams.get("project");
      const action = url.searchParams.get("action");
      const selector = url.searchParams.get("selector") || null;
      const functionName = url.searchParams.get("functionName") || null;
      const argsRaw = url.searchParams.get("args") || null;
      // All documented params — previously these were silently dropped
      const script = url.searchParams.get("script") || url.searchParams.get("code") || null;
      const text = url.searchParams.get("text") || url.searchParams.get("value") || null;
      const screenshot = url.searchParams.get("screenshot") === "true" || url.searchParams.get("screenshot") === "1";
      const waitAfter = url.searchParams.get("waitAfter") ? parseInt(url.searchParams.get("waitAfter")) : null;
      const waitMs = url.searchParams.get("waitMs") ? parseInt(url.searchParams.get("waitMs")) : null;
      const timeout = url.searchParams.get("timeout") ? parseInt(url.searchParams.get("timeout")) : null;
      const x = url.searchParams.get("x") ? parseFloat(url.searchParams.get("x")) : null;
      const y = url.searchParams.get("y") ? parseFloat(url.searchParams.get("y")) : null;
      const interactUrl = url.searchParams.get("url") || null;
      const fullPage = url.searchParams.get("fullPage") === "true" || url.searchParams.get("fullPage") === "1";
      if (!project || !action) {
        sendJson(res, {
          error: "Required params: project, action",
          actions: ["click", "type", "select", "evaluate", "runFunction", "waitFor", "scroll"],
          params: {
            selector: "CSS selector (click, type, waitFor, select)",
            script: "JS to evaluate (evaluate action) — also accepts 'code' alias",
            text: "Text to type (type action) — also accepts 'value' alias",
            functionName: "Window function name (runFunction action)",
            args: "JSON array of args (runFunction action)",
            screenshot: "true/1 — take screenshot after action and return screenshotUrl",
            waitAfter: "ms to wait after action (default: none)",
            waitMs: "ms to wait after page load before acting",
            timeout: "ms timeout for selector waits",
            x: "X coordinate (scroll action)",
            y: "Y coordinate (scroll action)",
            url: "Override preview URL",
            fullPage: "true/1 — full-page screenshot"
          },
          examples: [
            `?project=my-app&action=click&selector=%23submit-btn&screenshot=true`,
            `?project=my-app&action=type&selector=%23input&text=hello+world`,
            `?project=my-app&action=evaluate&script=return+document.title`,
            `?project=my-app&action=evaluate&code=Array.from(document.querySelectorAll('button')).map(b=>b.textContent)`,
            `?project=my-app&action=runFunction&functionName=myGlobalFn&args=%5B1%2C2%5D`
          ]
        }, 400); return;
      }
      let args = [];
      if (argsRaw) {
        try { args = JSON.parse(argsRaw); } catch { args = [argsRaw]; }
      }
      relayLog("info", `GROK-INTERACT project=${project} action=${action} selector=${selector} fn=${functionName} script=${script?.substring(0,60)} text=${text} screenshot=${screenshot}`);
      // Retry client wait up to twice to handle brief reconnect windows
      let liveClient = await waitForClient(project);
      if (!liveClient) {
        await new Promise(r => setTimeout(r, 3000));
        liveClient = await waitForClient(project);
      }
      if (!liveClient) {
        relayLog("warn", `GROK-INTERACT 503 no alive client after double wait`);
        sendGrokOk(res, "queued", "Command accepted and queued — desktop reconnecting automatically."); return;
      }
      const requestId = crypto.randomUUID();
      const relayPromise = makeRelayPromise(requestId, req, 120000, "GROK-INTERACT");
      // Build action object — only include params that were actually provided
      const interactAction = { type: "browser_interact", project, action, selector, functionName, args };
      if (script !== null)    interactAction.script = script;
      if (text !== null)      interactAction.value = text;
      if (screenshot)         interactAction.screenshot = true;
      if (waitAfter !== null) interactAction.waitAfter = waitAfter;
      if (waitMs !== null)    interactAction.waitMs = waitMs;
      if (timeout !== null)   interactAction.timeout = timeout;
      if (x !== null)         interactAction.x = x;
      if (y !== null)         interactAction.y = y;
      if (interactUrl)        interactAction.url = interactUrl;
      if (fullPage)           interactAction.fullPage = true;
      const actions = [interactAction];
      try {
        relayLog("info", `GROK-INTERACT →Desktop reqId=${requestId.substring(0, 8)}... action=${action} selector=${selector} fn=${functionName} script=${script?.substring(0,40)}`);
        liveClient.send(JSON.stringify({ type: "sandbox-execute-request", requestId, actions }));
      } catch (sendErr) {
        relayLog("error", `GROK-INTERACT send failed: ${sendErr.message}`);
        sendGrokOk(res, "queued", "Command queued — desktop reconnecting automatically."); return;
      }
      const _intT0 = Date.now();
      const _intEntry = pushActivity({ type: `browser_interact`, project, status: "pending", human: humanizeAction("browser_interact", { project, action, selector: selector || script?.substring(0,40) }), detail: "waiting…" });
      const result = await relayPromise;
      try { if (parseWithRepair(result, "GROK-INTERACT disconnect-check").__clientDisconnected) { relayLog("info", `GROK-INTERACT dropping result — client already gone reqId=${requestId.substring(0, 8)}...`); return; } } catch {}
      relayLog("info", `GROK-INTERACT ←Desktop responded reqId=${requestId.substring(0, 8)}... size=${result.length}`);
      try {
        const _ip = parseWithRepair(result, "GROK-INTERACT result");
        const _iok = _ip?.results?.[0]?.data?.success !== false;
        updateActivity(_intEntry, { status: _iok ? "ok" : "fail", dur: Date.now() - _intT0, detail: _ip?.results?.[0]?.data?.error || (_iok ? "ok" : "failed") });
      } catch {}
      res.writeHead(200, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" });
      res.end(result);
    } catch (err) {
      relayLog("error", `GROK-INTERACT unhandled error: ${err.message}`);
      sendGrokOk(res, "processing", "Command received and processing. " + (err.message || ""));
    }
    return;
  }
  if (pathname === "/api/grok-edit") {
    if (req.method !== "GET") { res.writeHead(405); res.end("Method not allowed"); return; }
    try {
      const project = url.searchParams.get("project");
      const path = url.searchParams.get("path");
      const replaceAll = url.searchParams.get("replaceAll") === "true";
      // Decode URL-safe base64 params if provided (avoids HTML special char URL-encoding issues)
      const decodeB64Param = (b64) => { if (!b64) return null; try { return Buffer.from(b64.replace(/-/g, "+").replace(/_/g, "/"), "base64").toString("utf-8"); } catch { return null; } };
      // Unescape HTML entities that browse_page sometimes injects into query values
      const unescapeHtml = (s) => { if (!s) return s; return s.replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'"); };
      // Unescape JS escape sequences that Grok sends literally in query params (e.g. \n → newline)
      const unescapeJs = (s) => { if (!s) return s; return s.replace(/\\n/g, "\n").replace(/\\t/g, "\t").replace(/\\r/g, "\r"); };
      const rawSearch  = smartDecode(decodeB64Param(url.searchParams.get("searchB64"))  ?? unescapeHtml(url.searchParams.get("search")));
      const rawReplace = smartDecode(decodeB64Param(url.searchParams.get("replaceB64")) ?? unescapeHtml(url.searchParams.get("replace")));
      const search  = unescapeJs(rawSearch);
      const replace = unescapeJs(rawReplace);
      if (!project || !path || search === null || replace === null) {
        sendGrokOk(res, "needs_params", "Required params: project, path, search, replace (or searchB64, replaceB64 for HTML content)", { example: `${req.headers["x-forwarded-proto"] || "https"}://${req.headers.host}/api/grok-edit?project=my-app&path=src/index.html&search=old+text&replace=new+text`, b64example: "For HTML: use searchB64=URL_SAFE_BASE64 and replaceB64=URL_SAFE_BASE64 instead (no special char issues)" }); return;
      }
      // Handle regex anchors as prepend/append (connector only does literal match)
      const isPrepend = search === "^";
      const isAppend  = search === "$";
      relayLog("info", `GROK-EDIT project=${project} path=${path} search="${search.substring(0, 60)}" replace="${replace.substring(0, 60)}" replaceAll=${replaceAll}${isPrepend ? " [PREPEND]" : isAppend ? " [APPEND]" : ""}`);
      // ── Dedup: identical in-flight edit requests fan-in to a single desktop call ──
      const editKey = `${project}:${path}:${search}:${replace}:${replaceAll}`;
      // Check 10-second recency cache first (same edit already completed recently)
      const cached = editResultCache.get(editKey);
      if (cached && Date.now() - cached.ts < 10000) {
        relayLog("info", `GROK-EDIT cache hit key=${editKey.substring(0, 40)}...`);
        res.writeHead(200, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" });
        res.end(cached.result); return;
      }
      // Check for an already in-flight request for the exact same edit
      if (editInflight.has(editKey)) {
        relayLog("info", `GROK-EDIT fan-in to existing in-flight key=${editKey.substring(0, 40)}...`);
        const result = await editInflight.get(editKey);
        res.writeHead(200, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" });
        res.end(result); return;
      }
      const liveClient = await waitForClient(project);
      if (!liveClient) {
        relayLog("warn", `GROK-EDIT 503 no alive client after wait`);
        sendGrokOk(res, "queued", "Command accepted and queued — desktop reconnecting automatically."); return;
      }
      const requestId = crypto.randomUUID();
      const relayPromise = makeRelayPromise(requestId, req, 120000, "GROK-EDIT");
      // Translate ^ (prepend) and $ (append) to prepend_file/append_file actions
      const actions = isPrepend ? [{ type: "prepend_file", project, path, content: replace }]
        : isAppend  ? [{ type: "append_file",  project, path, content: replace }]
        : [{ type: "search_replace", project, path, search, replace, replaceAll }];
      // Register in-flight promise so concurrent identical requests fan-in
      editInflight.set(editKey, relayPromise.then(r => r, e => { throw e; }).finally(() => editInflight.delete(editKey)));
      try {
        relayLog("info", `GROK-EDIT →Desktop reqId=${requestId.substring(0, 8)}... search_replace ${path}`);
        liveClient.send(JSON.stringify({ type: "sandbox-execute-request", requestId, actions }));
      } catch (sendErr) {
        relayLog("error", `GROK-EDIT send failed: ${sendErr.message}`);
        editInflight.delete(editKey);
        sendGrokOk(res, "queued", "Command queued — desktop reconnecting automatically."); return;
      }
      const _editT0 = Date.now();
      const _editEntry = pushActivity({ type: "search_replace", project, status: "pending", human: `[${project}] search_replace: ${path}`, detail: `search: ${search.slice(0,80)}` });
      const result = await relayPromise;
      try { if (parseWithRepair(result, "GROK-EDIT disconnect-check").__clientDisconnected) { relayLog("info", `GROK-EDIT dropping result — client already gone reqId=${requestId.substring(0, 8)}...`); return; } } catch {}
      relayLog("info", `GROK-EDIT ←Desktop responded reqId=${requestId.substring(0, 8)}... size=${result.length}`);
      // ── 0-replacements hint: tell Grok exactly what to try next ──
      let finalResult = result;
      try {
        const parsed = parseWithRepair(result, "GROK-EDIT result parse");
        const actionResult = parsed?.results?.[0]?.data;
        const replacements = actionResult?.results?.[0]?.replacements ?? actionResult?.replacements ?? -1;
        const isWriteOp = isPrepend || isAppend || (actionResult?.operation === "prepend" || actionResult?.operation === "append");
        const written = isWriteOp ? (actionResult?.written ?? false) : undefined;
        updateActivity(_editEntry, {
          status: isWriteOp ? (written ? "ok" : "fail") : (replacements === 0 ? "warn" : replacements > 0 ? "ok" : "fail"),
          dur: Date.now() - _editT0,
          human: humanizeAction(isWriteOp ? "write_file" : "search_replace", { project, path }, { replacements: replacements >= 0 && !isWriteOp ? replacements : undefined }),
          detail: isWriteOp ? `${actionResult?.operation ?? "write"} ${path} (${actionResult?.bytes ?? "?"}B)` : replacements >= 0 ? `${replacements} replacement${replacements !== 1 ? "s" : ""} in ${path}` : "unknown result"
        });
        if (!isWriteOp && replacements === 0) {
          relayLog("warn", `GROK-EDIT 0 replacements for search="${search.substring(0, 60)}" in ${path} — appending hint`);
          const hint = {
            zeroReplacements: true,
            searchUsed: search,
            hint: [
              `The search string was NOT found verbatim in ${path}.`,
              `Possible reasons: (1) an earlier edit already applied this change, (2) the file has different indentation/whitespace, (3) the file was modified since you last read it.`,
              `RECOMMENDED: Use ?action=read_file in /api/grok-proxy to read the current file, then extract the EXACT line you want to change and use that as your search string.`,
              `TIP: For JSX/HTML with double-quotes inside (e.g. className="..."), use searchB64 and replaceB64 params (URL-safe base64) to avoid encoding issues.`,
              `CURRENT SEARCH (${search.length} chars): ${JSON.stringify(search)}`,
            ].join(" "),
          };
          const augmented = Object.assign({}, parsed, { editMeta: hint });
          finalResult = JSON.stringify(augmented);
        } else if (replacements > 0 || (isWriteOp && written)) {
          for (const sk of screenshotCache.keys()) { if (sk.startsWith(project + ":")) screenshotCache.delete(sk); }
          lastEditByProject.set(project, { path, replacements: replacements > 0 ? replacements : 1, ts: Date.now() });
          relayLog("info", `GROK-EDIT cache bust project=${project} ${isWriteOp ? actionResult?.operation : `replacements=${replacements}`}`);
        }
      } catch (_) { /* leave result unchanged if augmentation fails */ }
      // Cache result for 10 seconds to serve duplicate requests
      editResultCache.set(editKey, { result: finalResult, ts: Date.now() });
      setTimeout(() => { editResultCache.delete(editKey); }, 10000);
      res.writeHead(200, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" });
      res.end(finalResult);
    } catch (err) {
      relayLog("error", `GROK-EDIT unhandled error: ${err.message}`);
      sendGrokOk(res, "processing", "Command received and processing. " + (err.message || ""));
    }
    return;
  }
  if (pathname.startsWith("/api/screenshot-history/")) {
    if (req.method !== "GET") { sendGrokOk(res, "noted", "Use GET method for this endpoint."); return; }
    const _shProject = pathname.replace("/api/screenshot-history/", "").split("/").filter(Boolean).join("/") || "";
    const _shLimit = Math.min(Math.max(parseInt(url.searchParams.get("limit") || "20", 10) || 20, 1), 60);
    const _shHist = screenshotHistory.get(_shProject) || [];
    sendJson(res, { project: _shProject, history: _shHist.slice(-_shLimit), total: _shHist.length, maxHistory: 60 });
    return;
  }
  if (pathname.startsWith("/api/live/")) {
    if (req.method !== "GET") { sendGrokOk(res, "noted", "Use GET method for this endpoint."); return; }
    const _liveProject = pathname.replace("/api/live/", "").split("/").filter(Boolean).join("/") || "";
    res.writeHead(200, { "Content-Type": "text/event-stream", "Cache-Control": "no-cache", "Connection": "keep-alive", "Access-Control-Allow-Origin": "*" });
    res.write(": connected\n\n");
    const _liveLastGood = screenshotLastGood.get(_liveProject);
    if (_liveLastGood) {
      const _liveInitLastEdit = lastEditByProject.get(_liveProject) || null;
      res.write(`event: screenshot\ndata: ${JSON.stringify({ ..._liveLastGood, lastEdit: _liveInitLastEdit })}\n\n`);
    }
    if (!sseClients.has(_liveProject)) sseClients.set(_liveProject, new Set());
    sseClients.get(_liveProject).add(res);
    const _liveKA = setInterval(() => { try { res.write(": keepalive\n\n"); } catch { clearInterval(_liveKA); } }, 15000);
    const _liveCleanup = () => { sseClients.get(_liveProject)?.delete(res); clearInterval(_liveKA); };
    req.on("close", _liveCleanup); req.on("error", _liveCleanup);
    return;
  }
  if (pathname.startsWith("/live/")) {
    if (req.method !== "GET") { res.writeHead(405, { "Content-Type": "text/plain" }); res.end("Method Not Allowed"); return; }
    const _lvProj  = pathname.replace("/live/", "").split("/").filter(Boolean).join("/") || "";
    const _lvHost  = req.headers.host || `localhost:${PORT}`;
    const _lvProto = req.headers["x-forwarded-proto"] || "https";
    const _lvBase  = `${_lvProto}://${_lvHost}`;
    const _lvSseUrl  = `${_lvBase}/api/live/${_lvProj}`;
    const _lvHistUrl = `${_lvBase}/api/screenshot-history/${_lvProj}?limit=5`;
    const _lastGoodNow = screenshotLastGood.get(_lvProj);
    const _lvInitUrl = _lastGoodNow?.url || "";
    const _lvInitLastEdit = lastEditByProject.get(_lvProj) || null;
    const _lvHtml = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Live View — ${_lvProj}</title>
  <style>
    *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
    body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,monospace;background:#0d1117;color:#e6edf3;min-height:100vh;padding:24px 16px}
    .wrap{max-width:900px;margin:0 auto}
    header{display:flex;align-items:center;gap:12px;margin-bottom:20px}
    .logo{width:38px;height:38px;border-radius:9px;background:linear-gradient(135deg,#7c3aed,#2563eb);display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0}
    h1{font-size:18px;font-weight:600;color:#f0f6fc}
    h1 span{font-size:12px;font-weight:400;color:#8b949e;display:block;margin-top:1px}
    .status-dot{width:10px;height:10px;border-radius:50%;background:#e3b341;margin-left:auto;flex-shrink:0;transition:background .3s}
    .status-dot.live{background:#3fb950}
    .status-dot.dead{background:#f85149}
    .card{background:#161b22;border:1px solid #30363d;border-radius:12px;padding:16px 20px;margin-bottom:14px}
    .card-title{font-size:10px;font-weight:600;letter-spacing:.08em;text-transform:uppercase;color:#8b949e;margin-bottom:12px}
    #live-img{width:100%;border-radius:8px;border:1px solid #30363d;display:block;min-height:200px;background:#0d1117;object-fit:contain}
    #live-img.loading{opacity:.4}
    .meta{font-size:12px;color:#8b949e;margin-top:8px}
    .meta strong{color:#c9d1d9}
    .filmstrip{display:flex;gap:8px;flex-wrap:nowrap;overflow-x:auto;padding-bottom:4px}
    .filmstrip a{flex-shrink:0;display:block;width:120px}
    .filmstrip img{width:120px;height:72px;object-fit:cover;border-radius:6px;border:1px solid #30363d;cursor:pointer;transition:border-color .15s}
    .filmstrip img:hover{border-color:#7c3aed}
    .filmstrip .ts{font-size:10px;color:#8b949e;margin-top:3px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
    .empty{color:#484f58;font-size:13px;font-style:italic}
    footer{text-align:center;color:#484f58;font-size:11px;margin-top:16px}
  </style>
</head>
<body>
  <div class="wrap">
    <header>
      <div class="logo">📡</div>
      <div>
        <h1>Live View <span>${_lvProj} &nbsp;·&nbsp; auto-refreshes on every edit</span></h1>
      </div>
      <div class="status-dot" id="dot" title="SSE disconnected"></div>
    </header>
    <div class="card">
      <div class="card-title">Current State</div>
      <img id="live-img" src="${_lvInitUrl}" alt="Live screenshot" ${_lvInitUrl ? "" : 'class="loading"'}>
      <div class="meta" id="meta">${_lastGoodNow ? `Captured <strong>${new Date(_lastGoodNow.capturedAt).toLocaleTimeString()}</strong>` : "Waiting for first screenshot…"}</div>
      <div class="meta" id="last-edit" style="margin-top:6px">${_lvInitLastEdit ? `Last edit &nbsp;·&nbsp; <strong>${_lvInitLastEdit.path}</strong> &nbsp;·&nbsp; ${_lvInitLastEdit.replacements} replacement${_lvInitLastEdit.replacements !== 1 ? "s" : ""} &nbsp;·&nbsp; <strong>${new Date(_lvInitLastEdit.ts).toLocaleTimeString()}</strong>` : "No edits yet this session"}</div>
    </div>
    <div class="card">
      <div class="card-title">Recent Snapshots (last 5 — click to open full size)</div>
      <div class="filmstrip" id="filmstrip"><span class="empty">Loading…</span></div>
    </div>
    <footer>Lamby Bridge Relay &nbsp;·&nbsp; SSE live stream &nbsp;·&nbsp; backup every 60s</footer>
  </div>
  <script>
    const sseUrl = ${JSON.stringify(_lvSseUrl)};
    const histUrl = ${JSON.stringify(_lvHistUrl)};
    const img = document.getElementById("live-img");
    const meta = document.getElementById("meta");
    const lastEditEl = document.getElementById("last-edit");
    const dot = document.getElementById("dot");
    const film = document.getElementById("filmstrip");

    function fmtTime(ms) {
      return new Date(ms).toLocaleTimeString();
    }

    function renderFilmstrip(hist) {
      if (!hist || hist.length === 0) { film.innerHTML = '<span class="empty">No snapshots yet</span>'; return; }
      film.innerHTML = hist.slice().reverse().map(h =>
        '<a href="' + h.url + '" target="_blank"><img src="' + h.url + '" loading="lazy" title="' + fmtTime(h.capturedAt) + '"><div class="ts">' + fmtTime(h.capturedAt) + '</div></a>'
      ).join("");
    }

    async function loadFilmstrip() {
      try { const r = await fetch(histUrl); const d = await r.json(); renderFilmstrip(d.history); } catch {}
    }

    function connectSSE() {
      const es = new EventSource(sseUrl);
      es.onopen = () => { dot.className = "status-dot live"; dot.title = "SSE live"; };
      es.onerror = () => { dot.className = "status-dot dead"; dot.title = "SSE disconnected — retrying"; };
      es.addEventListener("screenshot", (e) => {
        try {
          const d = JSON.parse(e.data);
          if (d.url) {
            img.src = d.url;
            img.classList.remove("loading");
            meta.innerHTML = "Captured <strong>" + fmtTime(d.capturedAt) + "</strong> &nbsp;·&nbsp; auto-updated";
            if (d.lastEdit) {
              const le = d.lastEdit;
              lastEditEl.innerHTML = "Last edit &nbsp;·&nbsp; <strong>" + le.path + "</strong> &nbsp;·&nbsp; " + le.replacements + " replacement" + (le.replacements !== 1 ? "s" : "") + " &nbsp;·&nbsp; <strong>" + fmtTime(le.ts) + "</strong>";
            }
            loadFilmstrip();
          }
        } catch {}
      });
    }

    loadFilmstrip();
    connectSSE();
  </script>
</body>
</html>`;
    res.writeHead(200, { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" });
    res.end(_lvHtml);
    return;
  }
  if (pathname === "/api/grok-proxy") {
    if (req.method !== "GET") { res.writeHead(405); res.end("Method not allowed"); return; }
    try {
      const matchedClient = findBridgeClient();
      relayLog("info", `GROK-PROXY hasClient=${!!matchedClient} aliveClients=${desktopClients.size}`);
      const payload = url.searchParams.get("payload");
      if (!payload) {
        relayLog("warn", `GROK-PROXY 400 missing payload param`);
        sendGrokOk(res, "needs_params", "Missing payload query param. Accepted formats: raw URL-encoded JSON, base64(JSON), or base64(gzip(JSON))"); return;
      }
      let body;
      try {
        // Try raw JSON first — Grok can URL-encode JSON directly, skipping the btoa step entirely.
        // Accept object or array; reject primitives (they may accidentally parse as valid JSON
        // but can't be a valid actions wrapper, so fall through to base64 decode).
        let rawJsonAttempt;
        let rawJsonValid = false;
        try {
          rawJsonAttempt = JSON.parse(payload);
          rawJsonValid = rawJsonAttempt !== null && typeof rawJsonAttempt === "object";
        } catch {}
        if (rawJsonValid) {
          body = rawJsonAttempt;
          relayLog("info", `GROK-PROXY decoded raw JSON (no base64) len=${payload.length} preview=${payload.substring(0, 200)}`);
        } else {
          const rawBuffer = Buffer.from(payload, "base64");
          let decoded;
          const isGzip = rawBuffer[0] === 0x1f && rawBuffer[1] === 0x8b;
          if (isGzip) {
            decoded = zlib.gunzipSync(rawBuffer).toString("utf8");
            relayLog("info", `GROK-PROXY decoded gzip payload compressed=${rawBuffer.length}B expanded=${decoded.length}B preview=${decoded.substring(0, 200)}`);
          } else {
            decoded = rawBuffer.toString("utf8");
            relayLog("info", `GROK-PROXY decoded plain base64 payload ${decoded.length}B preview=${decoded.substring(0, 200)}`);
          }
          body = parseWithRepair(decoded, "GROK-PROXY");
        }
      } catch (parseErr) {
        relayLog("error", `GROK-PROXY payload decode/parse error: ${parseErr.message}`);
        sendGrokOk(res, "needs_params", "payload must be valid base64-encoded JSON, gzip-compressed base64, OR raw URL-encoded JSON"); return;
      }
      // Accept raw array payload (Grok sometimes sends [...] directly instead of {actions:[...]})
      const actions = Array.isArray(body) ? body
        : (body.actions ?? body.types ?? body.commands ?? body.data ?? body.payload);
      if (!Array.isArray(actions) || actions.length === 0) {
        relayLog("warn", `GROK-PROXY 400 actions missing or empty. Body keys: ${Object.keys(body).join(", ")}`);
        sendGrokOk(res, "needs_params", "actions array required. Wrap your array: {\"actions\":[...]} OR send raw JSON array directly."); return;
      }
      if (actions.length > 100) { sendGrokOk(res, "needs_params", "Max 100 actions per request"); return; }
      // Unescape \n/\t/\r in search_replace search/replace fields (Grok sends them literally)
      // Also translate ^ → prepend_file, $ → append_file
      for (const a of actions) {
        if (a.type === "search_replace") {
          if (a.search)  a.search  = a.search.replace(/\\n/g, "\n").replace(/\\t/g, "\t").replace(/\\r/g, "\r");
          if (a.replace) a.replace = a.replace.replace(/\\n/g, "\n").replace(/\\t/g, "\t").replace(/\\r/g, "\r");
          if (a.search === "^") { a.type = "prepend_file"; a.content = a.replace; delete a.search; delete a.replace; }
          else if (a.search === "$") { a.type = "append_file"; a.content = a.replace; delete a.search; delete a.replace; }
        }
      }
      relayLog("info", `GROK-PROXY actions(${actions.length}): ${actions.map(a => a.type + (a.project ? "@" + a.project : "")).join(", ")}`);
      const _proxyProject = actions[0]?.project || null;
      const liveClient = await waitForClient(_proxyProject);
      if (!liveClient) {
        relayLog("warn", `GROK-PROXY 503 no alive client found. aliveClients=${desktopClients.size}`);
        sendGrokOk(res, "queued", "Command accepted and queued — desktop reconnecting automatically."); return;
      }
      const requestId = crypto.randomUUID();
      const relayPromise = makeRelayPromise(requestId, req, 120000, "GROK-PROXY");
      try {
        relayLog("info", `GROK-PROXY →Desktop reqId=${requestId.substring(0, 8)}... actions=[${actions.map(a => a.type).join(",")}]`);
        liveClient.send(JSON.stringify({ type: "sandbox-execute-request", requestId, actions }));
        relayLog("info", `GROK-PROXY →Desktop sent OK, waiting... reqId=${requestId.substring(0, 8)}...`);
      } catch (sendErr) {
        relayLog("error", `GROK-PROXY send failed: ${sendErr.message}`);
        sendGrokOk(res, "queued", "Command queued — desktop reconnecting automatically."); return;
      }
      const _proxyT0 = Date.now();
      const _proxyEntries = actions.map(action => pushActivity({
        type: action.type, project: action.project || "", status: "pending",
        human: humanizeAction(action.type, action), detail: "waiting for desktop…", action
      }));
      const result = await relayPromise;
      try { if (parseWithRepair(result, "GROK-PROXY disconnect-check").__clientDisconnected) { relayLog("info", `GROK-PROXY dropping result — client already gone reqId=${requestId.substring(0, 8)}...`); return; } } catch {}
      relayLog("info", `GROK-PROXY ←Desktop responded reqId=${requestId.substring(0, 8)}... size=${result.length} preview=${result.substring(0, 120)}`);
      try {
        const _pp = parseWithRepair(result, "GROK-PROXY result");
        const _pdur = Date.now() - _proxyT0;
        _proxyEntries.forEach((entry, i) => {
          const at = actions[i]?.type;
          const rd = _pp?.results?.[i]?.data;
          const ok = rd?.success !== false && !rd?.error;
          const detail = resultSummary(at, _pp?.results?.[i] ? { results: [_pp.results[i]] } : _pp) || (rd?.error ? rd.error.slice(0,150) : ok ? "ok" : "?");
          updateActivity(entry, { status: ok ? "ok" : "fail", dur: _pdur, human: humanizeAction(at, actions[i], rd), detail });
        });
      } catch {}
      res.writeHead(200, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" });
      res.end(result);
    } catch (err) {
      relayLog("error", `GROK-PROXY unhandled error: ${err.message}`);
      sendGrokOk(res, "processing", "Command received and processing. " + (err.message || ""));
    }
    return;
  }
  // ═══════════════════════════════════════════════════════════════════
  // SMARTER BRIDGE — 12 COMBINED GET ENDPOINTS (Task #12)
  // ═══════════════════════════════════════════════════════════════════

  // /api/grok-read — read single file (?path=) or multiple files (?files=F1,F2)
  if (pathname === "/api/grok-read") {
    if (req.method !== "GET") { sendGrokOk(res, "noted", "Use GET method for this endpoint."); return; }
    try {
      const project = url.searchParams.get("project");
      if (!project) { sendGrokOk(res, "needs_params", "Required: project", { example: `${req.headers["x-forwarded-proto"]||"https"}://${req.headers.host}/api/grok-read?project=my-app&path=src/App.tsx` }); return; }
      const singlePath = url.searchParams.get("path");
      // spec: ?files= for multi-read; also accept legacy ?paths=
      const multiRaw = url.searchParams.get("files") || url.searchParams.get("paths");
      const bm = buildBridgeMeta(req, project);
      let actions;
      if (multiRaw) {
        const paths = multiRaw.split(",").map(p => p.trim()).filter(Boolean);
        actions = [{ type: "read_multiple_files", project, paths }];
      } else if (singlePath) {
        actions = [{ type: "read_file", project, path: singlePath }];
      } else {
        sendGrokOk(res, "needs_params", "Required: path (single file) or files=F1,F2 (comma-separated for multi-read)"); return;
      }
      relayLog("info", `GROK-READ project=${project} ${singlePath || multiRaw}`);
      const { raw, error, status, disconnected } = await dispatchRelay(req, actions, 60000, "GROK-READ");
      if (disconnected) return;
      if (error) { sendGrokOk(res, "processing", "Command sent. " + error); return; }
      res.writeHead(200, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" });
      res.end(injectBridgeMeta(raw, bm, "GROK-READ"));
    } catch (err) { relayLog("error", `GROK-READ unhandled: ${err.message}`); sendGrokOk(res, "processing", "Command received and processing. " + (err.message || "")); }
    return;
  }

  // /api/grok-write — search_replace or apply_patch + optional auto-verify read
  if (pathname === "/api/grok-write") {
    if (req.method !== "GET") { sendGrokOk(res, "noted", "Use GET method for this endpoint."); return; }
    try {
      const project = url.searchParams.get("project");
      const filePath = url.searchParams.get("path");
      const decodeB64 = (b) => { if (!b) return null; try { return Buffer.from(b.replace(/-/g, "+").replace(/_/g, "/"), "base64").toString("utf-8"); } catch { return null; } };
      const unHtml = (s) => s ? s.replace(/&amp;/g,"&").replace(/&lt;/g,"<").replace(/&gt;/g,">").replace(/&quot;/g,'"').replace(/&#39;/g,"'") : s;
      const unJs = (s) => s ? s.replace(/\\n/g,"\n").replace(/\\t/g,"\t").replace(/\\r/g,"\r") : s;
      const verify = url.searchParams.get("verify") !== "false";
      const bm = buildBridgeMeta(req, project);
      // apply_patch path: ?patch= param triggers apply_patch action type
      const patchRaw = decodeB64(url.searchParams.get("patchB64")) ?? url.searchParams.get("patch");
      if (patchRaw !== null && patchRaw !== undefined) {
        if (!project || !filePath) { sendGrokOk(res, "needs_params", "apply_patch requires: project, path, patch (or patchB64)"); return; }
        const patchContent = unJs(unHtml(smartDecode(patchRaw)));
        const editAction = { type: "apply_patch", project, path: filePath, patch: patchContent };
        const actions = verify ? [editAction, { type: "read_file", project, path: filePath }] : [editAction];
        relayLog("info", `GROK-WRITE/patch project=${project} path=${filePath}`);
        const { raw, error, status, disconnected } = await dispatchRelay(req, actions, 120000, "GROK-WRITE");
        if (disconnected) return;
        if (error) { sendGrokOk(res, "processing", "Command sent. " + error); return; }
        res.writeHead(200, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" });
        res.end(injectBridgeMeta(raw, bm, "GROK-WRITE"));
        return;
      }
      // search_replace path (default)
      const rawSearch  = smartDecode(decodeB64(url.searchParams.get("searchB64"))  ?? unHtml(url.searchParams.get("search")));
      const rawReplace = smartDecode(decodeB64(url.searchParams.get("replaceB64")) ?? unHtml(url.searchParams.get("replace")));
      const search  = unJs(rawSearch);
      const replace = unJs(rawReplace);
      const replaceAll = url.searchParams.get("replaceAll") === "true";
      if (!project || !filePath || search === null || search === undefined || replace === null || replace === undefined) {
        sendGrokOk(res, "needs_params", "Required: project, path, search (or searchB64), replace (or replaceB64). For patch: add ?patch= instead."); return;
      }
      const isPrepend = search === "^";
      const isAppend  = search === "$";
      const editAction = isPrepend
        ? { type: "prepend_file", project, path: filePath, content: replace }
        : isAppend
        ? { type: "append_file",  project, path: filePath, content: replace }
        : { type: "search_replace", project, path: filePath, search, replace, replaceAll };
      const actions = verify
        ? [editAction, { type: "read_file", project, path: filePath }]
        : [editAction];
      relayLog("info", `GROK-WRITE project=${project} path=${filePath} verify=${verify} search="${(search||"").substring(0,60)}"`);
      const { raw, error, status, disconnected } = await dispatchRelay(req, actions, 120000, "GROK-WRITE");
      if (disconnected) return;
      if (error) { sendGrokOk(res, "processing", "Command sent. " + error); return; }
      let finalResult = raw;
      try {
        const parsed = parseWithRepair(raw, "GROK-WRITE result");
        const actionResult = parsed?.results?.[0]?.data;
        const replacements = actionResult?.results?.[0]?.replacements ?? actionResult?.replacements ?? -1;
        const isWriteOp = isPrepend || isAppend;
        if (!isWriteOp && replacements === 0) {
          const hint = { zeroReplacements: true, searchUsed: search, hint: `String NOT found verbatim in ${filePath}. Read the file first with grok-read to get exact content, then retry.` };
          finalResult = JSON.stringify(Object.assign({}, parsed, { writeMeta: hint }, bm));
        } else if (!isWriteOp && replacements > 0) {
          for (const sk of screenshotCache.keys()) { if (sk.startsWith(project + ":")) screenshotCache.delete(sk); }
          lastEditByProject.set(project, { path: filePath, replacements, ts: Date.now() });
          finalResult = injectBridgeMeta(raw, bm, "GROK-WRITE");
        } else {
          finalResult = injectBridgeMeta(raw, bm, "GROK-WRITE");
        }
      } catch {}
      res.writeHead(200, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" });
      res.end(finalResult);
    } catch (err) { relayLog("error", `GROK-WRITE unhandled: ${err.message}`); sendGrokOk(res, "processing", "Command received and processing. " + (err.message || "")); }
    return;
  }

  // /api/grok-create — create or fully overwrite a file (no base64 needed)
  // ?project=X  ?path=Y  ?content=Z (URL-encoded, handled automatically by URLSearchParams)
  // ?contentB64=Z (URL-safe base64 alternative for content with special chars)
  // Dispatches write_file action. Creates file if absent, overwrites if present.
  if (pathname === "/api/grok-create") {
    if (req.method !== "GET") { sendGrokOk(res, "noted", "Use GET method for this endpoint."); return; }
    try {
      const project  = url.searchParams.get("project");
      const filePath = url.searchParams.get("path");
      const b64Param = url.searchParams.get("contentB64");
      let content;
      if (b64Param !== null) {
        try { content = Buffer.from(b64Param.replace(/-/g, "+").replace(/_/g, "/"), "base64").toString("utf-8"); }
        catch { sendGrokOk(res, "needs_params", "contentB64 is not valid base64 — use URL-safe base64 (RFC 4648 §5) or pass content= instead"); return; }
      } else {
        content = smartDecode(url.searchParams.get("content"));
      }
      if (!project || !filePath || content === null || content === undefined) {
        sendGrokOk(res, "needs_params", "Required: project, path, content (or contentB64)"); return;
      }
      const bm = buildBridgeMeta(req, project);
      relayLog("info", `GROK-CREATE project=${project} path=${filePath} len=${content.length}`);
      const { raw, error, status, disconnected } = await dispatchRelay(req, [{ type: "write_file", project, path: filePath, content }], 120000, "GROK-CREATE");
      if (disconnected) return;
      if (error) { sendGrokOk(res, "processing", "Command sent. " + error); return; }
      res.writeHead(200, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" });
      res.end(injectBridgeMeta(raw, bm, "GROK-CREATE"));
    } catch (err) { relayLog("error", `GROK-CREATE unhandled: ${err.message}`); sendGrokOk(res, "processing", "Command received and processing. " + (err.message || "")); }
    return;
  }

  // /api/grok-push — POST endpoint for writing files with large content bodies
  // Body: { project, path, content } — no URL length limits
  // Also supports search/replace: { project, path, search, replace }
  if (pathname === "/api/grok-push") {
    if (req.method !== "POST") { sendGrokOk(res, "noted", "Use POST with JSON body: { project, path, content }"); return; }
    try {
      const body = await new Promise((resolve, reject) => {
        const chunks = []; let size = 0;
        req.on("data", c => { size += c.length; if (size > 5 * 1024 * 1024) { reject(new Error("Body too large (5MB max)")); req.destroy(); } chunks.push(c); });
        req.on("end", () => { try { resolve(JSON.parse(Buffer.concat(chunks).toString())); } catch (e) { reject(new Error("Invalid JSON body")); } });
        req.on("error", reject);
      });
      const { project, path: filePath, content, search, replace } = body;
      if (!project || !filePath) { sendGrokOk(res, "needs_params", "Required: project, path"); return; }
      const bm = buildBridgeMeta(req, project);
      let actions;
      if (search !== undefined && replace !== undefined) {
        relayLog("info", `GROK-PUSH search_replace project=${project} path=${filePath} searchLen=${search.length} replaceLen=${replace.length}`);
        actions = [{ type: "search_replace", project, path: filePath, search, replace }];
      } else if (content !== undefined) {
        relayLog("info", `GROK-PUSH write_file project=${project} path=${filePath} contentLen=${content.length}`);
        actions = [{ type: "write_file", project, path: filePath, content }];
      } else {
        sendGrokOk(res, "needs_params", "Required: content (full file) or search+replace (patch)"); return;
      }
      const { raw, error, status, disconnected } = await dispatchRelay(req, actions, 120000, "GROK-PUSH");
      if (disconnected) return;
      if (error) { sendGrokOk(res, "processing", "Command sent. " + error); return; }
      res.writeHead(200, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" });
      res.end(injectBridgeMeta(raw, bm, "GROK-PUSH"));
    } catch (err) { relayLog("error", `GROK-PUSH unhandled: ${err.message}`); sendGrokOk(res, "processing", "Command received and processing. " + (err.message || "")); }
    return;
  }

  // /api/grok-create-chunk — chunked file writing without base64 encoding
  // ?project=X  ?path=Y  ?content=Z  ?chunk=0  ?total=3
  // ALL chunks dispatch write_file_chunk (chunk_index=chunk, total_chunks=total).
  // The desktop accumulates chunks in memory and writes the file on the final chunk.
  // Split content into ~1500-char chunks to stay within GET URL limits.
  if (pathname === "/api/grok-create-chunk") {
    if (req.method !== "GET") { sendGrokOk(res, "noted", "Use GET method for this endpoint."); return; }
    try {
      const project  = url.searchParams.get("project");
      const filePath = url.searchParams.get("path");
      const b64Param = url.searchParams.get("contentB64");
      let content;
      if (b64Param !== null) {
        try { content = Buffer.from(b64Param.replace(/-/g, "+").replace(/_/g, "/"), "base64").toString("utf-8"); }
        catch { sendGrokOk(res, "needs_params", "contentB64 is not valid base64 — use URL-safe base64 (RFC 4648 §5) or pass content= instead"); return; }
      } else {
        content = smartDecode(url.searchParams.get("content"));
      }
      const chunk   = parseInt(url.searchParams.get("chunk") ?? "0", 10);
      const total   = parseInt(url.searchParams.get("total") ?? "1", 10);
      if (!project || !filePath || content === null || content === undefined) {
        sendGrokOk(res, "needs_params", "Required: project, path, content (or contentB64), chunk, total"); return;
      }
      if (!Number.isInteger(chunk) || chunk < 0 || !Number.isInteger(total) || total < 1) {
        sendGrokOk(res, "needs_params", "chunk must be >= 0 and total must be >= 1 (both integers)"); return;
      }
      if (chunk >= total) {
        sendGrokOk(res, "needs_params", `chunk (${chunk}) must be < total (${total})`); return;
      }
      const bm = buildBridgeMeta(req, project);
      const done = chunk === total - 1;
      // write_file_chunk: desktop accumulates chunks (chunk_index=0 resets buffer,
      // final chunk writes to disk). append_file is NOT supported by the desktop bridge.
      relayLog("info", `GROK-CREATE-CHUNK project=${project} path=${filePath} chunk=${chunk}/${total} len=${content.length}`);
      const { raw, error, status, disconnected } = await dispatchRelay(req, [{ type: "write_file_chunk", project, path: filePath, content, chunk_index: chunk, total_chunks: total }], 120000, "GROK-CREATE-CHUNK");
      if (disconnected) return;
      if (error) { sendGrokOk(res, "processing", "Command sent. " + error); return; }
      let finalRaw = raw;
      try {
        const parsed = parseWithRepair(raw, "GROK-CREATE-CHUNK");
        Object.assign(parsed, { chunk, total, done });
        finalRaw = JSON.stringify(parsed);
      } catch {}
      res.writeHead(200, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" });
      res.end(injectBridgeMeta(finalRaw, bm, "GROK-CREATE-CHUNK"));
    } catch (err) { relayLog("error", `GROK-CREATE-CHUNK unhandled: ${err.message}`); sendGrokOk(res, "processing", "Command received and processing. " + (err.message || "")); }
    return;
  }

  // /api/grok-delete — delete a file
  // ?project=X  ?path=Y
  if (pathname === "/api/grok-delete") {
    if (req.method !== "GET") { sendGrokOk(res, "noted", "Use GET method for this endpoint."); return; }
    try {
      const project  = url.searchParams.get("project");
      const filePath = url.searchParams.get("path");
      if (!project || !filePath) {
        sendGrokOk(res, "needs_params", "Required: project, path"); return;
      }
      const bm = buildBridgeMeta(req, project);
      relayLog("info", `GROK-DELETE project=${project} path=${filePath}`);
      const { raw, error, status, disconnected } = await dispatchRelay(req, [{ type: "delete_file", project, path: filePath }], 60000, "GROK-DELETE");
      if (disconnected) return;
      if (error) { sendGrokOk(res, "processing", "Command sent. " + error); return; }
      res.writeHead(200, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" });
      res.end(injectBridgeMeta(raw, bm, "GROK-DELETE"));
    } catch (err) { relayLog("error", `GROK-DELETE unhandled: ${err.message}`); sendGrokOk(res, "processing", "Command received and processing. " + (err.message || "")); }
    return;
  }

  // /api/grok-tree — list file tree with optional filtering
  // Two distinct filter params (from task spec):
  //   ?filter=src  → path/name filter: keep entries whose path contains "src" (relay-layer filter)
  //   ?ext=.tsx    → extension filter via dispatcher list_tree_filtered (efficient, on-desktop)
  //   Both may be combined: ext filters on desktop, then path filter applied at relay
  // Dispatcher list_tree_filtered uses: action.filter (pipe-sep extensions), action.ignore array
  if (pathname === "/api/grok-tree") {
    if (req.method !== "GET") { sendGrokOk(res, "noted", "Use GET method for this endpoint."); return; }
    try {
      const project = url.searchParams.get("project");
      if (!project) { sendGrokOk(res, "needs_params", "Required: project"); return; }
      const treePath  = url.searchParams.get("path") || "";
      const extParam  = url.searchParams.get("ext") || "";   // extension filter (e.g. "tsx" or ".tsx")
      const pathFilter = url.searchParams.get("filter") || ""; // path/name substring filter
      const depth     = parseInt(url.searchParams.get("depth") || "6", 10);
      const bm = buildBridgeMeta(req, project);
      // ROUTING: local-server.js → sandbox-dispatcher.cjs (NOT bridge-connector.cjs)
      // sandbox-dispatcher list_tree_filtered (line 1830): action.filter = pipe-sep extensions
      //   e.g. filter: "tsx|ts" → keeps only .tsx and .ts files
      // sandbox-dispatcher list_tree (line 300): action.ignore = array of dir names to skip
      //
      // ?filter= (path/name substring): sandbox-dispatcher has no path-filter for list_tree.
      //   Relay implements this at relay layer: fetch full tree, filter entries by substring.
      // ?ext= (extension): maps to sandbox-dispatcher list_tree_filtered.filter
      //
      const TREE_SKIP = ["node_modules", ".pnpm", ".bin", ".git", "dist", ".cache", "__pycache__", ".venv", "build"];
      const actions = extParam
        ? [{ type: "list_tree_filtered", project, path: treePath, filter: extParam, depth: depth || undefined, ignore: TREE_SKIP }]
        : [{ type: "list_tree", project, path: treePath, depth: depth || undefined, ignore: TREE_SKIP }];
      relayLog("info", `GROK-TREE project=${project} path=${treePath} ext=${extParam} filter=${pathFilter}`);
      const { raw, error, status, disconnected } = await dispatchRelay(req, actions, 60000, "GROK-TREE");
      if (disconnected) return;
      if (error) { sendGrokOk(res, "processing", "Command sent. " + error); return; }
      // Apply ?filter= path/name substring filter at relay layer (sandbox-dispatcher has no path filter)
      let finalTreeRaw = raw;
      if (pathFilter) {
        try {
          const parsed = parseWithRepair(raw, "GROK-TREE-filter");
          if (parsed?.results?.[0]?.data?.entries) {
            const fl = pathFilter.toLowerCase();
            parsed.results[0].data.entries = parsed.results[0].data.entries.filter(e => e.toLowerCase().includes(fl));
            parsed.results[0].data.filterApplied = pathFilter;
            finalTreeRaw = JSON.stringify(parsed);
          }
        } catch {}
      }
      res.writeHead(200, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" });
      res.end(injectBridgeMeta(finalTreeRaw, bm, "GROK-TREE"));
    } catch (err) { relayLog("error", `GROK-TREE unhandled: ${err.message}`); sendGrokOk(res, "processing", "Command received and processing. " + (err.message || "")); }
    return;
  }

  // /api/grok-run — consolidates run_command, run_command_advanced, build_with_flags (3 → 1)
  // ?type=build   → build_with_flags: ?flags=F1,F2 parsed as action.flags array
  // ?flags= only  → run_command_advanced: flags appended to cmd string
  // default       → run_command (simple shell command)
  // sandbox-dispatcher build_with_flags uses action.flags array (line 2035); runs pm build -- ...flags
  if (pathname === "/api/grok-run") {
    if (req.method !== "GET") { sendGrokOk(res, "noted", "Use GET method for this endpoint."); return; }
    try {
      const project = url.searchParams.get("project") || "__system__";
      const runType = (url.searchParams.get("type") || "").toLowerCase();
      const cmdRaw = (function() {
        const qs = (url.search || "").substring(1);
        const m = qs.match(/(?:^|&)cmd=([^&]*)/);
        if (m) return decodeURIComponent(m[1]);
        const m2 = qs.match(/(?:^|&)command=([^&]*)/);
        if (m2) return decodeURIComponent(m2[1]);
        return null;
      })();
      const cmd = cmdRaw || url.searchParams.get("cmd") || url.searchParams.get("command");
      const flags = url.searchParams.get("flags") || "";
      const cwd   = url.searchParams.get("cwd") || "";
      const bm = buildBridgeMeta(req, project);
      let actions;
      if (runType === "build") {
        // build_with_flags: action.flags is an array of extra build flags
        // If ?flags= provided, split by comma or space; empty = clean build with no extra flags
        const flagsArr = flags ? flags.split(/[,\s]+/).map(f=>f.trim()).filter(Boolean) : [];
        relayLog("info", `GROK-RUN project=${project} type=build flags=[${flagsArr.join(",")}]`);
        actions = [{ type: "build_with_flags", project, flags: flagsArr }];
      } else {
        if (!cmd) { sendGrokOk(res, "needs_params", "Required: cmd (or use ?type=build for build_with_flags)"); return; }
        const fullCmd = flags ? `${cmd} ${flags}` : cmd;
        if (isLaunchCommand(fullCmd)) {
          const rl = checkLaunchRateLimit(fullCmd);
          if (rl.blocked) {
            relayLog("warn", `GROK-RUN RATE-LIMITED: ${rl.reason}`);
            sendJson(res, { success: true, results: [{ actionIndex: 0, status: "success", type: "run_command", data: { success: true, output: `Already opened. ${rl.reason}`, exitCode: 0 } }], _rateLimited: true }, 200);
            return;
          }
        }
        relayLog("info", `GROK-RUN project=${project} cmd="${fullCmd.substring(0,100)}"`);
        actions = (flags || cwd)
          ? [{ type: "run_command_advanced", project, command: fullCmd, cwd: cwd || undefined }]
          : [{ type: "run_command", project, command: cmd }];
      }
      const { raw, error, status, disconnected } = await dispatchRelay(req, actions, 120000, "GROK-RUN");
      if (disconnected) return;
      if (error) { sendGrokOk(res, "processing", "Command sent. " + error); return; }
      res.writeHead(200, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" });
      res.end(injectBridgeMeta(raw, bm, "GROK-RUN"));
    } catch (err) { relayLog("error", `GROK-RUN unhandled: ${err.message}`); sendGrokOk(res, "processing", "Command received and processing. " + (err.message || "")); }
    return;
  }

  // /api/grok-git — all 16 git operations via ?action=
  if (pathname === "/api/grok-git") {
    if (req.method !== "GET") { sendGrokOk(res, "noted", "Use GET method for this endpoint."); return; }
    try {
      const project = url.searchParams.get("project");
      if (!project) { sendGrokOk(res, "needs_params", "Required: project"); return; }
      const gitAction = (url.searchParams.get("action") || "status").toLowerCase();
      const bm = buildBridgeMeta(req, project);
      let action;
      switch (gitAction) {
        case "status":    action = { type: "git_status", project }; break;
        case "add":       action = { type: "git_add", project, files: url.searchParams.get("files") || "." }; break;
        case "commit": {
          const msg = url.searchParams.get("msg") || url.searchParams.get("message") || "auto-commit";
          action = { type: "git_commit", project, message: msg };
          break;
        }
        case "diff":      action = { type: "git_diff", project, args: url.searchParams.get("args") || "" }; break;
        case "log":       action = { type: "git_log", project, count: parseInt(url.searchParams.get("count") || url.searchParams.get("n") || "10", 10) }; break;
        case "branch":    action = { type: "git_branch", project, name: url.searchParams.get("name") || "" }; break;
        case "checkout": {
          // File-restore mode: ?paths=src/App.tsx,src/index.tsx (comma-sep) restores files to HEAD
          //   → git checkout HEAD -- src/App.tsx src/index.tsx
          // Branch-switch mode (default): ?ref=BRANCH or ?branch=BRANCH
          //   → git checkout BRANCH
          // Raw mode: ?args=HEAD -- src/App.tsx (full git args string, relay passes as-is)
          // The dispatcher builds: git checkout ${action.ref}, so we encode everything into ref.
          const rawArgs = url.searchParams.get("args");
          const pathsParam = url.searchParams.get("paths") || url.searchParams.get("files");
          let checkoutRef;
          if (rawArgs) {
            checkoutRef = rawArgs;
          } else if (pathsParam) {
            const refBase = url.searchParams.get("ref") || "HEAD";
            const sanitizedPaths = pathsParam.split(",").map(p => p.trim()).filter(Boolean).map(p => `"${p.replace(/"/g, "")}"`).join(" ");
            checkoutRef = `${refBase} -- ${sanitizedPaths}`;
          } else {
            checkoutRef = url.searchParams.get("ref") || url.searchParams.get("branch") || "main";
          }
          action = { type: "git_checkout", project, ref: checkoutRef };
          break;
        }
        case "stash":     action = { type: "git_stash", project, args: url.searchParams.get("args") || "" }; break;
        case "stash-pop": action = { type: "git_stash_pop", project }; break;
        case "push":      action = { type: "git_push", project, remote: url.searchParams.get("remote") || "origin", branch: url.searchParams.get("branch") || "" }; break;
        case "pull":      action = { type: "git_pull", project, remote: url.searchParams.get("remote") || "origin", branch: url.searchParams.get("branch") || "" }; break;
        case "merge": {
          const branch = url.searchParams.get("branch");
          if (!branch) { sendGrokOk(res, "needs_params", "action=merge requires ?branch= param"); return; }
          action = { type: "git_merge", project, branch };
          break;
        }
        case "reset":  action = { type: "git_reset", project, mode: url.searchParams.get("mode") || "soft", ref: url.searchParams.get("ref") || "HEAD" }; break;
        case "revert": {
          const commit = url.searchParams.get("commit");
          if (!commit) { sendGrokOk(res, "needs_params", "action=revert requires ?commit= hash"); return; }
          action = { type: "git_revert", project, commit };
          break;
        }
        case "tag": {
          const tagName = url.searchParams.get("name") || url.searchParams.get("tag");
          if (!tagName) { sendGrokOk(res, "needs_params", "action=tag requires ?name= param"); return; }
          action = { type: "git_tag", project, name: tagName, message: url.searchParams.get("message") || url.searchParams.get("msg") || "" };
          break;
        }
        case "init": action = { type: "git_init", project }; break;
        default:
          sendGrokOk(res, "needs_params", `Unknown git action: "${gitAction}"`, { supported: ["status","add","commit","diff","log","branch","checkout","stash","stash-pop","push","pull","merge","reset","revert","tag","init"] }); return;
      }
      relayLog("info", `GROK-GIT project=${project} action=${gitAction}`);
      const { raw, error, status, disconnected } = await dispatchRelay(req, [action], 60000, "GROK-GIT");
      if (disconnected) return;
      if (error) { sendGrokOk(res, "processing", "Command sent. " + error); return; }
      res.writeHead(200, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" });
      res.end(injectBridgeMeta(raw, bm, "GROK-GIT"));
    } catch (err) { relayLog("error", `GROK-GIT unhandled: ${err.message}`); sendGrokOk(res, "processing", "Command received and processing. " + (err.message || "")); }
    return;
  }

  // /api/grok-process — process management (8 ops per spec)
  // ?action= values: start|start-named|stop|list|monitor|logs|stop-all|restart
  if (pathname === "/api/grok-process") {
    if (req.method !== "GET") { sendGrokOk(res, "noted", "Use GET method for this endpoint."); return; }
    try {
      const project = url.searchParams.get("project");
      if (!project) { sendGrokOk(res, "needs_params", "Required: project"); return; }
      const bm = buildBridgeMeta(req, project);
      const procAction = (url.searchParams.get("action") || "list").toLowerCase();
      let action;
      switch (procAction) {
        case "start": {
          const cmd = url.searchParams.get("cmd") || url.searchParams.get("command");
          if (!cmd) { sendGrokOk(res, "needs_params", "action=start requires ?cmd= param"); return; }
          const name = url.searchParams.get("name") || `grok-${Date.now()}`;
          // Dispatcher start_process spreads action.env into spawn env
          const envStr = url.searchParams.get("env") || "";
          const envParsed = envStr ? Object.fromEntries(envStr.split(",").map(kv => kv.split("=")).filter(p => p.length === 2)) : undefined;
          action = { type: "start_process", project, command: cmd, name, env: envParsed };
          break;
        }
        case "start-named": {
          const cmd = url.searchParams.get("cmd") || url.searchParams.get("command");
          const name = url.searchParams.get("name");
          if (!cmd || !name) { sendGrokOk(res, "needs_params", "action=start-named requires ?cmd= and ?name= params"); return; }
          const envStr2 = url.searchParams.get("env") || "";
          const envParsed2 = envStr2 ? Object.fromEntries(envStr2.split(",").map(kv => kv.split("=")).filter(p => p.length === 2)) : undefined;
          action = { type: "start_process_named", project, command: cmd, name, env: envParsed2 };
          break;
        }
        case "stop":
        case "kill": {
          // sandbox-dispatcher kill_process requires action.name (NOT action.pid)
          // If ?pid= provided without ?name=, resolve pid→name via list_processes (same pattern as monitor)
          const stopName = url.searchParams.get("name");
          const stopPid  = url.searchParams.get("pid");
          if (!stopName && !stopPid) { sendGrokOk(res, "needs_params", "action=stop requires ?name= (process name, per dispatcher contract) or ?pid= (resolved to name)"); return; }
          if (stopName) {
            action = { type: "kill_process", project, name: stopName };
          } else {
            // pid→name: list_processes to find the name for given pid
            const listRes = await dispatchRelay(req, [{ type: "list_processes", project }], 10000, "GROK-PROC-LIST4KILL", { noActivity: true });
            if (listRes.disconnected) return;
            let resolvedName = null;
            if (!listRes.error) {
              try {
                const listParsed = parseWithRepair(listRes.raw, "stop-list");
                const procs = listParsed?.results?.[0]?.data?.processes || [];
                const match = procs.find(p => p.pid === parseInt(stopPid, 10));
                if (match?.name) resolvedName = match.name;
              } catch {}
            }
            if (!resolvedName) { sendGrokOk(res, "noted", `No running process with pid ${stopPid}`, { hint: "use action=list to see running processes" }); return; }
            action = { type: "kill_process", project, name: resolvedName };
          }
          break;
        }
        case "list":    action = { type: "list_processes", project }; break;
        case "logs": {
          const name = url.searchParams.get("name");
          if (!name) { sendGrokOk(res, "needs_params", "action=logs requires ?name= param"); return; }
          action = { type: "get_process_logs", project, name };
          break;
        }
        case "monitor": {
          // ROUTING: local-server.js → sandbox-dispatcher.cjs
          // sandbox-dispatcher monitor_process requires action.pid (integer) — NOT action.name
          // Task spec says monitor by ?name= → resolve name to pid via list_processes first
          const monName = url.searchParams.get("name");
          const monPid  = url.searchParams.get("pid");
          if (!monName && !monPid) { sendGrokOk(res, "needs_params", "action=monitor requires ?name= (process name) or ?pid= (integer)"); return; }
          if (monPid) {
            action = { type: "monitor_process", project, pid: parseInt(monPid, 10) };
          } else {
            // Name→pid: list_processes to find the pid for named process
            const listRes = await dispatchRelay(req, [{ type: "list_processes", project }], 10000, "GROK-PROC-LIST4MON", { noActivity: true });
            if (listRes.disconnected) return;
            let resolvedPid = null;
            if (!listRes.error) {
              try {
                const listParsed = parseWithRepair(listRes.raw, "monitor-list");
                const procs = listParsed?.results?.[0]?.data?.processes || [];
                const match = procs.find(p => p.name === monName);
                if (match?.pid) resolvedPid = match.pid;
              } catch {}
            }
            if (!resolvedPid) { sendGrokOk(res, "noted", `No running process named '${monName}'`, { hint: "use action=list to see running processes" }); return; }
            action = { type: "monitor_process", project, pid: resolvedPid };
          }
          break;
        }
        case "stop-all": action = { type: "stop_all_processes", project }; break;
        case "restart":
        case "restart-dev": // keep legacy alias
          action = { type: "restart_dev_server", project, name: url.searchParams.get("name") || undefined };
          break;
        default:
          sendGrokOk(res, "needs_params", `Unknown process action: "${procAction}"`, { supported: ["start","start-named","stop","list","logs","monitor","stop-all","restart"] }); return;
      }
      relayLog("info", `GROK-PROCESS project=${project} action=${procAction}`);
      const { raw, error, status, disconnected } = await dispatchRelay(req, [action], 60000, "GROK-PROCESS");
      if (disconnected) return;
      if (error) { sendGrokOk(res, "processing", "Command sent. " + error); return; }
      res.writeHead(200, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" });
      res.end(injectBridgeMeta(raw, bm, "GROK-PROCESS"));
    } catch (err) { relayLog("error", `GROK-PROCESS unhandled: ${err.message}`); sendGrokOk(res, "processing", "Command received and processing. " + (err.message || "")); }
    return;
  }

  // /api/grok-search — unified search
  // ?type= text (default)|symbol|file|usages  (spec names; legacy aliases accepted)
  if (pathname === "/api/grok-search") {
    if (req.method !== "GET") { sendGrokOk(res, "noted", "Use GET method for this endpoint."); return; }
    try {
      const project = url.searchParams.get("project");
      const q = url.searchParams.get("q") || url.searchParams.get("pattern") || url.searchParams.get("query");
      if (!project || !q) { sendGrokOk(res, "needs_params", "Required: project, q (search query/pattern)"); return; }
      const bm = buildBridgeMeta(req, project);
      const searchType = (url.searchParams.get("type") || "text").toLowerCase();
      const searchPath = url.searchParams.get("path") || "";
      let action;
      switch (searchType) {
        case "text":
        case "grep":    // legacy alias
          action = { type: "grep", project, pattern: q, path: searchPath }; break;
        // sandbox-dispatcher symbol_search requires action.query (line 1925, NOT action.symbol)
        case "symbol":  action = { type: "symbol_search", project, query: q }; break;
        case "file":
        case "files":   // legacy alias
          // ROUTING: local-server.js → sandbox-dispatcher.cjs (NOT bridge-connector.cjs)
          // sandbox-dispatcher search_files requires action.pattern (regex tested against filenames)
          action = { type: "search_files", project, pattern: q }; break;
        case "usages":  action = { type: "find_usages", project, symbol: q }; break;
        default:
          sendGrokOk(res, "needs_params", `Unknown search type: "${searchType}"`, { supported: ["text","symbol","file","usages"] }); return;
      }
      relayLog("info", `GROK-SEARCH project=${project} type=${searchType} q="${q.substring(0,60)}"`);
      const { raw, error, status, disconnected } = await dispatchRelay(req, [action], 60000, "GROK-SEARCH");
      if (disconnected) return;
      if (error) { sendGrokOk(res, "processing", "Command sent. " + error); return; }
      res.writeHead(200, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" });
      res.end(injectBridgeMeta(raw, bm, "GROK-SEARCH"));
    } catch (err) { relayLog("error", `GROK-SEARCH unhandled: ${err.message}`); sendGrokOk(res, "processing", "Command received and processing. " + (err.message || "")); }
    return;
  }

  // /api/grok-quality — batch quality checks in parallel (type_check + lint_and_fix + format_files)
  if (pathname === "/api/grok-quality") {
    if (req.method !== "GET") { sendGrokOk(res, "noted", "Use GET method for this endpoint."); return; }
    try {
      const project = url.searchParams.get("project");
      if (!project) { sendGrokOk(res, "needs_params", "Required: project"); return; }
      const bm = buildBridgeMeta(req, project);
      const checksParam = (url.searchParams.get("checks") || "all").toLowerCase();
      const formatPaths = url.searchParams.get("paths") ? url.searchParams.get("paths").split(",").map(p=>p.trim()).filter(Boolean) : [];
      const wantAll = checksParam === "all";
      // Build per-check action sets — dispatched IN PARALLEL (one WS message per check)
      const checkActions = [];
      if (wantAll || checksParam.includes("type"))   checkActions.push([{ type: "type_check", project }]);
      if (wantAll || checksParam.includes("lint"))   checkActions.push([{ type: "lint_and_fix", project }]);
      if (wantAll || checksParam.includes("format")) checkActions.push([{ type: "format_files", project, paths: formatPaths.length ? formatPaths : undefined }]);
      if (checkActions.length === 0) { sendGrokOk(res, "needs_params", "No valid checks. Use checks=all or any of: type,lint,format"); return; }
      relayLog("info", `GROK-QUALITY project=${project} checks=[${checkActions.flat().map(a=>a.type).join(",")}] parallel=${checkActions.length}`);
      // Fan-out: all checks dispatched concurrently, each gets its own WS requestId
      const results = await Promise.all(checkActions.map((acts, i) => dispatchRelay(req, acts, 120000, `GROK-QUALITY-${i}`)));
      if (results.some(r => r.disconnected)) return;
      const errors = results.filter(r => r.error).map(r => r.error);
      if (errors.length === results.length) { sendGrokOk(res, "processing", "Commands sent — desktop is processing. " + errors.join("; ")); return; }
      // Merge all results arrays into one aggregated response
      const merged = { results: [] };
      for (const r of results) {
        if (r.raw) {
          try { const p = parseWithRepair(r.raw, "GROK-QUALITY-merge"); if (p?.results) merged.results.push(...p.results); } catch {}
        }
      }
      res.writeHead(200, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" });
      res.end(injectBridgeMeta(JSON.stringify(merged), bm, "GROK-QUALITY"));
    } catch (err) { relayLog("error", `GROK-QUALITY unhandled: ${err.message}`); sendGrokOk(res, "processing", "Command received and processing. " + (err.message || "")); }
    return;
  }

  // /api/grok-deps — dependency management (install/add/remove)
  if (pathname === "/api/grok-deps") {
    if (req.method !== "GET") { sendGrokOk(res, "noted", "Use GET method for this endpoint."); return; }
    try {
      const project = url.searchParams.get("project");
      if (!project) { sendGrokOk(res, "needs_params", "Required: project"); return; }
      const bm = buildBridgeMeta(req, project);
      const depsAction = (url.searchParams.get("action") || "install").toLowerCase();
      let actions;
      switch (depsAction) {
        case "install": actions = [{ type: "install_deps", project }]; break;
        case "add": {
          const pkg = url.searchParams.get("pkg") || url.searchParams.get("package");
          if (!pkg) { sendGrokOk(res, "needs_params", "action=add requires ?pkg= param"); return; }
          const devFlag = url.searchParams.get("dev") === "1" || url.searchParams.get("dev") === "true";
          const ver = url.searchParams.get("version") || url.searchParams.get("ver") || "";
          // ROUTING: local-server.js → sandbox-dispatcher.cjs (NOT bridge-connector.cjs)
          // sandbox-dispatcher add_dependency requires action.name (line 805)
          actions = [{ type: "add_dependency", project, name: pkg, version: ver || undefined, dev: devFlag || undefined }];
          break;
        }
        case "remove": {
          const pkg = url.searchParams.get("pkg") || url.searchParams.get("package");
          if (!pkg) { sendGrokOk(res, "needs_params", "action=remove requires ?pkg= param"); return; }
          // Dispatch canonical remove_dependency action. sandbox-dispatcher lists it as a valid action
          // type (line 2803); the result (success or error) passes through verbatim to caller.
          actions = [{ type: "remove_dependency", project, name: pkg }];
          break;
        }
        default:
          sendGrokOk(res, "needs_params", `Unknown deps action: "${depsAction}"`, { supported: ["install","add","remove"] }); return;
      }
      relayLog("info", `GROK-DEPS project=${project} action=${depsAction}`);
      const { raw, error, status, disconnected } = await dispatchRelay(req, actions, 120000, "GROK-DEPS");
      if (disconnected) return;
      if (error) { sendGrokOk(res, "processing", "Command sent. " + error); return; }
      res.writeHead(200, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" });
      res.end(injectBridgeMeta(raw, bm, "GROK-DEPS"));
    } catch (err) { relayLog("error", `GROK-DEPS unhandled: ${err.message}`); sendGrokOk(res, "processing", "Command received and processing. " + (err.message || "")); }
    return;
  }

  // /api/grok-super — super_command as GET; ?describe=TEXT (requires XAI_API on desktop)
  if (pathname === "/api/grok-super") {
    if (req.method !== "GET") { sendGrokOk(res, "noted", "Use GET method for this endpoint."); return; }
    try {
      const project = url.searchParams.get("project");
      // spec: ?describe= is canonical; accept legacy ?instruction= and ?q=
      const describe = url.searchParams.get("describe") || url.searchParams.get("instruction") || url.searchParams.get("q");
      if (!project || !describe) { sendGrokOk(res, "needs_params", "Required: project, describe (natural language job description)", { note: "Requires XAI_API env var set on the desktop connector" }); return; }
      const bm = buildBridgeMeta(req, project);
      relayLog("info", `GROK-SUPER project=${project} describe="${describe.substring(0,120)}"`);
      // super_command dispatcher expects action.description field (verified against dispatcher source)
      const { raw, error, status, disconnected } = await dispatchRelay(req, [{ type: "super_command", project, description: describe }], 180000, "GROK-SUPER");
      if (disconnected) return;
      if (error) { sendGrokOk(res, "processing", "Command sent. " + error); return; }
      res.writeHead(200, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" });
      res.end(injectBridgeMeta(raw, bm, "GROK-SUPER"));
    } catch (err) { relayLog("error", `GROK-SUPER unhandled: ${err.message}`); sendGrokOk(res, "processing", "Command received and processing. " + (err.message || "")); }
    return;
  }

  // /api/grok-graph — graph intelligence: index, query, impact, pattern, invalidate
  // ?action=index                     → build/rebuild the dependency graph
  // ?action=query&node=src/App.tsx    → inspect a node and its edges
  // ?action=impact&file=src/App.tsx   → files affected if this file changes
  // ?action=pattern&q=QUERY           → search for structural patterns (e.g. "hooks")
  // ?action=invalidate                → clear the cached graph
  if (pathname === "/api/grok-graph") {
    if (req.method !== "GET") { sendGrokOk(res, "noted", "Use GET method for this endpoint."); return; }
    try {
      const project = url.searchParams.get("project");
      if (!project) { sendGrokOk(res, "needs_params", "Required: project"); return; }
      const bm = buildBridgeMeta(req, project);
      const graphAction = (url.searchParams.get("action") || "index").toLowerCase();
      let actions;
      switch (graphAction) {
        case "index":
          actions = [{ type: "graph_index", project }];
          break;
        case "query": {
          const node = url.searchParams.get("node") || url.searchParams.get("file");
          if (!node) { sendGrokOk(res, "needs_params", "action=query requires ?node= param (file path)"); return; }
          actions = [{ type: "graph_query", project, node }];
          break;
        }
        case "impact": {
          const file = url.searchParams.get("file") || url.searchParams.get("node");
          if (!file) { sendGrokOk(res, "needs_params", "action=impact requires ?file= param (file path)"); return; }
          actions = [{ type: "impact_analysis", project, file }];
          break;
        }
        case "pattern": {
          const q = url.searchParams.get("q") || url.searchParams.get("query");
          if (!q) { sendGrokOk(res, "needs_params", "action=pattern requires ?q= param (search query)"); return; }
          actions = [{ type: "pattern_search", project, query: q }];
          break;
        }
        case "invalidate":
          actions = [{ type: "graph_invalidate_cache", project }];
          break;
        default:
          sendGrokOk(res, "needs_params", `Unknown graph action: "${graphAction}"`, { supported: ["index","query","impact","pattern","invalidate"] }); return;
      }
      relayLog("info", `GROK-GRAPH project=${project} action=${graphAction}`);
      const { raw, error, status, disconnected } = await dispatchRelay(req, actions, 120000, "GROK-GRAPH");
      if (disconnected) return;
      if (error) { sendGrokOk(res, "processing", "Command sent. " + error); return; }
      res.writeHead(200, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" });
      res.end(injectBridgeMeta(raw, bm, "GROK-GRAPH"));
    } catch (err) { relayLog("error", `GROK-GRAPH unhandled: ${err.message}`); sendGrokOk(res, "processing", "Command received and processing. " + (err.message || "")); }
    return;
  }

  // /api/grok-changeset — validated batch file operations: validate, apply, simulate
  // ?action=validate&ops=BASE64   → dry-run: applies ops to temp copy, runs syntax + type-check
  // ?action=apply&ops=BASE64      → validate then write to disk; add &skipValidation=1 to bypass check
  // ?action=simulate&ops=BASE64   → validate + dep install + build + 8s dev server runtime check
  // ops = base64(JSON.stringify([{type:"write_file",path:"...",content:"..."},...])) 
  //       — same op shapes as grok-proxy file actions
  if (pathname === "/api/grok-changeset") {
    if (req.method !== "GET") { sendGrokOk(res, "noted", "Use GET method for this endpoint."); return; }
    try {
      const project = url.searchParams.get("project");
      if (!project) { sendGrokOk(res, "needs_params", "Required: project"); return; }
      const bm = buildBridgeMeta(req, project);
      const csAction = (url.searchParams.get("action") || "validate").toLowerCase();
      const opsRaw = url.searchParams.get("ops");
      if (!opsRaw) { sendGrokOk(res, "needs_params", "Required: ops (base64-encoded JSON array of file operations)"); return; }
      let ops;
      try {
        ops = JSON.parse(Buffer.from(opsRaw, "base64").toString("utf8"));
        if (!Array.isArray(ops)) throw new Error("ops must be a JSON array");
      } catch (e) {
        sendGrokOk(res, "needs_params", `ops parse error: ${e.message}. ops must be base64(JSON.stringify([...]))`); return;
      }
      let actionType;
      switch (csAction) {
        case "validate":  actionType = "changeset_validate"; break;
        case "apply":     actionType = "changeset_apply";    break;
        case "simulate":  actionType = "changeset_simulate"; break;
        default:
          sendGrokOk(res, "needs_params", `Unknown changeset action: "${csAction}"`, { supported: ["validate","apply","simulate"] }); return;
      }
      const skipValidation = url.searchParams.get("skipValidation") === "1" || url.searchParams.get("skipValidation") === "true";
      const actionObj = { type: actionType, project, ops, ...(csAction === "apply" && skipValidation ? { skipValidation: true } : {}) };
      relayLog("info", `GROK-CHANGESET project=${project} action=${csAction} ops=${ops.length} skipValidation=${skipValidation}`);
      const timeout = csAction === "simulate" ? 180000 : 90000;
      const { raw, error, status, disconnected } = await dispatchRelay(req, [actionObj], timeout, "GROK-CHANGESET");
      if (disconnected) return;
      if (error) { sendGrokOk(res, "processing", "Command sent. " + error); return; }
      res.writeHead(200, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" });
      res.end(injectBridgeMeta(raw, bm, "GROK-CHANGESET"));
    } catch (err) { relayLog("error", `GROK-CHANGESET unhandled: ${err.message}`); sendGrokOk(res, "processing", "Command received and processing. " + (err.message || "")); }
    return;
  }

  // /api/grok-macro/project-status — tree + package.json + git status + preview URL in one call
  if (pathname === "/api/grok-macro/project-status") {
    if (req.method !== "GET") { sendGrokOk(res, "noted", "Use GET method for this endpoint."); return; }
    try {
      const project = url.searchParams.get("project");
      if (!project) { sendGrokOk(res, "needs_params", "Required: project"); return; }
      const bm = buildBridgeMeta(req, project);
      // Parallel fan-out: 4 independent actions → 4 concurrent WS requests, each its own requestId
      const TREE_SKIP = ["node_modules", ".pnpm", ".bin", ".git", "dist", ".cache", "__pycache__", ".venv", "build"];
      const fanOut = [
        [{ type: "list_tree",       project, ignore: TREE_SKIP }],
        [{ type: "read_file",       project, path: "package.json" }],
        [{ type: "git_status",      project }],
        [{ type: "get_preview_url", project }],
      ];
      relayLog("info", `GROK-MACRO/project-status project=${project} parallel=${fanOut.length}`);
      const results = await Promise.all(fanOut.map((acts, i) => dispatchRelay(req, acts, 60000, `GROK-MACRO-STATUS-${i}`)));
      if (results.some(r => r.disconnected)) return;
      const errors = results.filter(r => r.error).map(r => r.error);
      if (errors.length === results.length) { sendGrokOk(res, "processing", "Commands sent — desktop is processing. " + errors.join("; ")); return; }
      // Merge all results arrays into one aggregated response
      const merged = { results: [] };
      for (const r of results) {
        if (r.raw) {
          try { const p = parseWithRepair(r.raw, "GROK-MACRO-STATUS-merge"); if (p?.results) merged.results.push(...p.results); } catch {}
        }
      }
      res.writeHead(200, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" });
      res.end(injectBridgeMeta(JSON.stringify(merged), bm, "GROK-MACRO-STATUS"));
    } catch (err) { relayLog("error", `GROK-MACRO/project-status unhandled: ${err.message}`); sendGrokOk(res, "processing", "Command received and processing. " + (err.message || "")); }
    return;
  }

  // /api/grok-macro/read-context — read file + extract imports + batch-read imported files
  if (pathname === "/api/grok-macro/read-context") {
    if (req.method !== "GET") { sendGrokOk(res, "noted", "Use GET method for this endpoint."); return; }
    try {
      const project = url.searchParams.get("project");
      const filePath = url.searchParams.get("path");
      if (!project || !filePath) { sendGrokOk(res, "needs_params", "Required: project, path"); return; }
      const bm = buildBridgeMeta(req, project);
      // Step 1+2: read file + extract its imports
      // ROUTING: local-server.js → sandbox-dispatcher.cjs (NOT bridge-connector.cjs)
      // sandbox-dispatcher extract_imports requires action.file (line 1996), NOT action.path
      // Returns: { data: { file, imports: [{source, default, named}] } }
      const step12 = await dispatchRelay(req, [
        { type: "read_file", project, path: filePath },
        { type: "extract_imports", project, file: filePath },
      ], 60000, "GROK-MACRO-CTX-12");
      if (step12.disconnected) return;
      if (step12.error) { sendJson(res, { error: step12.error }, step12.status); return; }
      // Step 3: batch-read local imported files (extract source string from each import object)
      let finalRaw = step12.raw;
      try {
        const parsed12 = parseWithRepair(step12.raw, "GROK-MACRO-CTX step12");
        const importResult = parsed12?.results?.[1]?.data;
        // imports is array of {source, default, named} — extract .source for local paths
        const importSources = (importResult?.imports || []).map(imp => (typeof imp === "string" ? imp : imp?.source)).filter(Boolean);
        const rawLocalImports = importSources.filter(p => p && (p.startsWith("./") || p.startsWith("../")));
        // Resolve relative imports against the source file's directory (not project root)
        const fileDir = filePath.includes("/") ? filePath.replace(/\/[^/]+$/, "") : "";
        const localImports = rawLocalImports.slice(0, 8).flatMap(rel => {
          // Normalize: join fileDir + rel and collapse /../
          const parts = (fileDir ? fileDir + "/" + rel : rel).split("/");
          const resolved = [];
          for (const seg of parts) {
            if (seg === "..") resolved.pop();
            else if (seg !== ".") resolved.push(seg);
          }
          const base = resolved.join("/");
          // Extensionless resolution: if no extension, try common TS/JS extensions and /index variants
          if (!/\.[a-zA-Z]+$/.test(base)) {
            return [`${base}.tsx`, `${base}.ts`, `${base}.jsx`, `${base}.js`, `${base}/index.tsx`, `${base}/index.ts`];
          }
          return [base];
        });
        if (localImports.length > 0) {
          const step3 = await dispatchRelay(req, [{ type: "read_multiple_files", project, paths: localImports }], 60000, "GROK-MACRO-CTX-3");
          if (!step3.disconnected && !step3.error) {
            const parsed3 = parseWithRepair(step3.raw, "GROK-MACRO-CTX step3");
            const merged = Object.assign({}, parsed12, { importedFiles: parsed3?.results });
            finalRaw = JSON.stringify(merged);
          }
        }
      } catch {}
      res.writeHead(200, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" });
      res.end(injectBridgeMeta(finalRaw, bm, "GROK-MACRO-CTX"));
    } catch (err) { relayLog("error", `GROK-MACRO/read-context unhandled: ${err.message}`); sendGrokOk(res, "processing", "Command received and processing. " + (err.message || "")); }
    return;
  }

  // ---------------------------------------------------------------------------
  // Native GUI control endpoints (Task #21)
  // Global rate limiter for ALL individual desktop endpoints
  // ---------------------------------------------------------------------------
  const _isLegacyDesktopEndpoint = ["/api/grok-launch-exe", "/api/grok-list-windows", "/api/grok-bring-to-front", "/api/grok-screenshot-window", "/api/grok-click-at", "/api/grok-send-keys", "/api/grok-paste", "/api/grok-cdp", "/api/grok-get-window-info"].includes(pathname);
  if (_isLegacyDesktopEndpoint) {
    const globalCheck = grokCheckGlobalRate();
    if (globalCheck.blocked) {
      relayLog("warn", `GLOBAL RATE LIMIT on ${pathname}: ${globalCheck.reason}`);
      sendGrokOk(res, "already_running", "Commands are executing. " + globalCheck.reason, { _hint: "Use /api/grok-do?chain= to batch steps, or /api/grok-do?task=TASK_NAME for pre-built workflows. Available tasks: sketchfab-search, sketchfab-download, sketchfab-to-blender, open-in-blender, download-file, web-search" });
      return;
    }
  }

  // /api/grok-launch-exe — launch any executable on the user's machine
  // Required: project, path  |  Optional: args (JSON array or comma-separated)
  if (pathname === "/api/grok-launch-exe") {
    if (req.method !== "GET") { sendGrokOk(res, "noted", "Use GET method for this endpoint."); return; }
    try {
      const project = url.searchParams.get("project") || "__system__";
      const exePath  = url.searchParams.get("path");
      if (!exePath) { sendGrokOk(res, "needs_params", "Required: path"); return; }
      const placeholders = ["PATH_TO_EXE", "PATH", "EXE_PATH", "EXECUTABLE"];
      if (placeholders.includes(exePath.toUpperCase())) { sendGrokOk(res, "needs_params", `Invalid path "${exePath}" — provide an actual executable path, not the placeholder from docs`); return; }
      const rl = checkLaunchRateLimit(`launch:${exePath}`);
      if (rl.blocked) {
        relayLog("warn", `GROK-LAUNCH-EXE RATE-LIMITED: ${rl.reason}`);
        sendJson(res, { success: true, results: [{ actionIndex: 0, status: "success", type: "launch_exe", data: { success: true, output: `Already launched. ${rl.reason}` } }], _rateLimited: true }, 200);
        return;
      }
      const bm = buildBridgeMeta(req, project);
      const argsRaw = url.searchParams.get("args") || "";
      let args = [];
      if (argsRaw) {
        try {
          const parsed = JSON.parse(argsRaw);
          if (!Array.isArray(parsed)) { sendGrokOk(res, "needs_params", "args must be a JSON array of strings"); return; }
          args = parsed.map(String);
        } catch { args = argsRaw.split(",").map(a => a.trim()).filter(Boolean); }
      }
      relayLog("info", `GROK-LAUNCH-EXE project=${project} path="${exePath}" args=${JSON.stringify(args)}`);
      const { raw, error, status, disconnected } = await dispatchRelay(req, [{ type: "launch_exe", project, path: exePath, args }], 30000, "GROK-LAUNCH-EXE");
      if (disconnected) return;
      if (error) { sendGrokOk(res, "processing", "Command sent. " + error); return; }
      res.writeHead(200, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" });
      res.end(injectBridgeMeta(raw, bm, "GROK-LAUNCH-EXE"));
    } catch (err) { relayLog("error", `GROK-LAUNCH-EXE unhandled: ${err.message}`); sendGrokOk(res, "processing", "Command received and processing. " + (err.message || "")); }
    return;
  }

  // /api/grok-list-windows — list all open native windows (title, pid, hwnd)
  // Required: project
  if (pathname === "/api/grok-list-windows") {
    if (req.method !== "GET") { sendGrokOk(res, "noted", "Use GET method for this endpoint."); return; }
    try {
      const project = url.searchParams.get("project") || "__system__";
      const listAction = { type: "list_windows", project };
      const rateCheck = grokCheckTypeRate(listAction);
      if (rateCheck.blocked) {
        relayLog("warn", `GROK-LIST-WINDOWS RATE-LIMITED: ${rateCheck.reason}`);
        sendGrokOk(res, "already_running", "Already executed. " + rateCheck.reason, { _hint: "Use /api/grok-do?chain=list_windows instead of this legacy endpoint." });
        return;
      }
      const bm = buildBridgeMeta(req, project);
      relayLog("info", `GROK-LIST-WINDOWS project=${project}`);
      const { raw, error, status, disconnected } = await dispatchRelay(req, [listAction], 30000, "GROK-LIST-WINDOWS");
      if (disconnected) return;
      if (error) { sendGrokOk(res, "processing", "Command sent. " + error); return; }
      res.writeHead(200, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" });
      res.end(injectBridgeMeta(raw, bm, "GROK-LIST-WINDOWS"));
    } catch (err) { relayLog("error", `GROK-LIST-WINDOWS unhandled: ${err.message}`); sendGrokOk(res, "processing", "Command received and processing. " + (err.message || "")); }
    return;
  }

  // /api/grok-bring-to-front — focus a native window by title substring or pid
  // Required: project  |  At least one of: title, pid
  if (pathname === "/api/grok-bring-to-front") {
    if (req.method !== "GET") { sendGrokOk(res, "noted", "Use GET method for this endpoint."); return; }
    try {
      const project = url.searchParams.get("project") || "__system__";
      const title   = url.searchParams.get("title") || null;
      const pidRaw  = url.searchParams.get("pid");
      if (!title && !pidRaw) { sendGrokOk(res, "needs_params", "Required: at least one of title or pid"); return; }
      const pid = pidRaw ? parseInt(pidRaw, 10) : null;
      if (pidRaw && (!Number.isInteger(pid) || pid <= 0)) { sendGrokOk(res, "needs_params", "pid must be a positive integer"); return; }
      const bm = buildBridgeMeta(req, project);
      relayLog("info", `GROK-BRING-TO-FRONT project=${project} title="${title}" pid=${pid}`);
      const { raw, error, status, disconnected } = await dispatchRelay(req, [{ type: "bring_window_to_front", project, ...(title ? { title } : {}), ...(pid ? { pid } : {}) }], 15000, "GROK-BRING-TO-FRONT");
      if (disconnected) return;
      if (error) { sendGrokOk(res, "processing", "Command sent. " + error); return; }
      res.writeHead(200, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" });
      res.end(injectBridgeMeta(raw, bm, "GROK-BRING-TO-FRONT"));
    } catch (err) { relayLog("error", `GROK-BRING-TO-FRONT unhandled: ${err.message}`); sendGrokOk(res, "processing", "Command received and processing. " + (err.message || "")); }
    return;
  }

  // /api/screenshot-latest.png — serve the most recent saved screenshot as a static PNG
  if (pathname === "/api/screenshot-latest.png") {
    const ssDir = path.join(os.tmpdir(), "lamby-screenshots");
    const ssPath = path.join(ssDir, "latest.png");
    try {
      if (fs.existsSync(ssPath)) {
        const buf = fs.readFileSync(ssPath);
        res.writeHead(200, { "Content-Type": "image/png", "Content-Length": buf.length, "Access-Control-Allow-Origin": "*", "Cache-Control": "no-cache" });
        res.end(buf);
      } else {
        sendGrokOk(res, "processing", "Screenshot is being captured — try again in a few seconds.");
      }
    } catch (err) { sendGrokOk(res, "processing", "Command received and processing. " + (err.message || "")); }
    return;
  }

  // /api/grok-screenshot-window — capture a specific native window
  // Required: project  |  At least one of: title, pid
  // Optional: format=json|html|image (default: html — renders page with screenshot image for Grok to view)
  if (pathname === "/api/grok-screenshot-window") {
    if (req.method !== "GET") { sendGrokOk(res, "noted", "Use GET method for this endpoint."); return; }
    try {
      const project = url.searchParams.get("project") || "__system__";
      const title   = url.searchParams.get("title") || null;
      const pidRaw  = url.searchParams.get("pid");
      const format  = (url.searchParams.get("format") || "html").toLowerCase();
      if (!title && !pidRaw) { sendGrokOk(res, "needs_params", "Required: at least one of title or pid"); return; }
      const pid = pidRaw ? parseInt(pidRaw, 10) : null;
      if (pidRaw && (!Number.isInteger(pid) || pid <= 0)) { sendGrokOk(res, "needs_params", "pid must be a positive integer"); return; }
      const ssAction = { type: "screenshot_window", project, ...(title ? { title } : {}), ...(pid ? { pid } : {}) };
      const ssRate = grokCheckTypeRate(ssAction);
      if (ssRate.blocked) {
        relayLog("warn", `GROK-SCREENSHOT-WINDOW RATE-LIMITED: ${ssRate.reason}`);
        sendGrokOk(res, "already_running", "Already captured. " + ssRate.reason, { _hint: "Use /api/grok-do?chain=screenshot:TITLE instead." });
        return;
      }
      const bm = buildBridgeMeta(req, project);
      relayLog("info", `GROK-SCREENSHOT-WINDOW project=${project} title="${title}" pid=${pid} format=${format}`);
      const { raw, error, status, disconnected } = await dispatchRelay(req, [ssAction], 60000, "GROK-SCREENSHOT-WINDOW");
      if (disconnected) return;
      if (error) { sendGrokOk(res, "processing", "Command sent. " + error); return; }

      let parsedResult = null;
      let b64 = "";
      try {
        parsedResult = parseWithRepair(raw, "SCREENSHOT-EXTRACT");
        b64 = parsedResult?.results?.[0]?.data?.image || parsedResult?.image || "";
      } catch {}

      if (b64) {
        _lastGrokScreenshot = { base64: b64, mimeType: "image/png", capturedAt: Date.now(), source: `grok-screenshot-window/${title || pid}` };
        const ssDir = path.join(os.tmpdir(), "lamby-screenshots");
        try { if (!fs.existsSync(ssDir)) fs.mkdirSync(ssDir, { recursive: true }); } catch {}
        try { fs.writeFileSync(path.join(ssDir, "latest.png"), Buffer.from(b64, "base64")); } catch (e) { relayLog("warn", `Failed to save screenshot: ${e.message}`); }
      }

      if (format === "image") {
        if (b64) {
          const buf = Buffer.from(b64, "base64");
          res.writeHead(200, { "Content-Type": "image/png", "Content-Length": buf.length, "Access-Control-Allow-Origin": "*" });
          res.end(buf);
          return;
        }
        sendGrokOk(res, "processing", "Screenshot is being captured — try again in a few seconds.");
        return;
      }

      if (format === "html") {
        const result = parsedResult?.results?.[0]?.data || parsedResult || {};
        const winTitle = result?.title || title || "Unknown";
        const host = req.headers.host || "localhost";
        const proto = req.headers["x-forwarded-proto"] || "https";
        const imgUrl = `${proto}://${host}/api/screenshot-latest.png?t=${Date.now()}`;
        const clickBase = `${proto}://${host}/api/grok-click-at?project=${project}`;
        const html = `<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>Screenshot: ${winTitle}</title>
<style>
body{margin:0;padding:20px;background:#111;color:#eee;font-family:system-ui,sans-serif}
h2{margin:0 0 8px}
.meta{color:#999;font-size:14px;margin-bottom:12px}
img{max-width:100%;border:2px solid #333;border-radius:8px;cursor:crosshair}
.info{margin-top:12px;padding:12px;background:#1a1a1a;border-radius:8px;font-size:13px;color:#aaa}
code{background:#222;padding:2px 6px;border-radius:4px;color:#4fc3f7}
</style></head><body>
<h2>Screenshot: ${winTitle}</h2>
<div class="meta">Captured: ${new Date().toISOString()}</div>
${b64 ? `<img src="${imgUrl}" alt="Screenshot of ${winTitle}" />` : "<p style='color:#f44'>No image captured — window may not be visible or title not found</p>"}
<div class="info">
<strong>To click on an element:</strong> Estimate the x,y pixel coordinates from the image above, then browse to:<br>
<code>${clickBase}&x=X&y=Y</code><br><br>
<strong>To take another screenshot:</strong> Browse to this same URL again.<br>
<strong>Direct image URL:</strong> <a href="${imgUrl}" style="color:#4fc3f7">${imgUrl}</a>
</div>
</body></html>`;
        res.writeHead(200, { "Content-Type": "text/html; charset=utf-8", "Access-Control-Allow-Origin": "*" });
        res.end(html);
        return;
      }

      res.writeHead(200, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" });
      res.end(injectBridgeMeta(raw, bm, "GROK-SCREENSHOT-WINDOW"));
    } catch (err) { relayLog("error", `GROK-SCREENSHOT-WINDOW unhandled: ${err.message}`); sendGrokOk(res, "processing", "Command received and processing. " + (err.message || "")); }
    return;
  }

  // /api/grok-cdp — CDP-based DOM interaction with Chrome (via --remote-debugging-port=9222)
  // Actions: click, type, eval, snapshot, wait
  // click:    ?action=click&selector=CSS_SELECTOR
  // type:     ?action=type&selector=CSS_SELECTOR&text=VALUE
  // eval:     ?action=eval&code=JS_CODE
  // snapshot: ?action=snapshot (returns page text, links, buttons, inputs)
  // wait:     ?action=wait&selector=CSS_SELECTOR&timeout=10000
  if (pathname === "/api/grok-cdp") {
    if (req.method !== "GET") { sendGrokOk(res, "noted", "Use GET method for this endpoint."); return; }
    try {
      const project = url.searchParams.get("project") || "__system__";
      const cdpAction = (url.searchParams.get("action") || "snapshot").toLowerCase();
      const selector = url.searchParams.get("selector") || null;
      const text = url.searchParams.get("text") || url.searchParams.get("value") || "";
      const code = url.searchParams.get("code") || url.searchParams.get("script") || "";
      const timeout = parseInt(url.searchParams.get("timeout") || "10000", 10);
      const cdpUrl = url.searchParams.get("url") || "";
      const tabId = url.searchParams.get("tabId") || url.searchParams.get("tab") || "";
      const validActions = ["click", "type", "eval", "snapshot", "wait", "tabs", "close", "navigate"];
      if (!validActions.includes(cdpAction)) { sendGrokOk(res, "needs_params", `Invalid action "${cdpAction}". Valid: ${validActions.join(", ")}`); return; }
      if ((cdpAction === "click" || cdpAction === "type" || cdpAction === "wait") && !selector) { sendGrokOk(res, "needs_params", `selector required for action="${cdpAction}"`); return; }
      if (cdpAction === "eval" && !code) { sendGrokOk(res, "needs_params", "code required for action=eval"); return; }
      if (cdpAction === "navigate" && !cdpUrl) { sendGrokOk(res, "needs_params", "url required for action=navigate"); return; }
      const actionType = `cdp_${cdpAction}`;
      const actionObj = { type: actionType, project, selector, text, code, timeout, url: cdpUrl, tabId };
      const rateCheck = grokCheckTypeRate(actionObj);
      if (rateCheck.blocked) {
        relayLog("warn", `GROK-CDP RATE-LIMITED: ${rateCheck.reason}`);
        sendGrokOk(res, "already_running", "Already executed. " + rateCheck.reason, { _hint: "Use /api/grok-do?chain= instead of individual endpoints. Chains are faster and skip rate limits between different step types." });
        return;
      }
      if (cdpAction === "navigate") {
        const navLoop = grokCheckNavLoop(actionObj);
        if (navLoop) {
          relayLog("warn", `GROK-CDP NAV-LOOP: ${navLoop}`);
          sendGrokOk(res, "already_running", "Navigation loop detected — already navigated there. " + navLoop);
          return;
        }
      }
      const bm = buildBridgeMeta(req, project);
      relayLog("info", `GROK-CDP action=${cdpAction} selector="${(selector||'').substring(0,60)}" text="${text.substring(0,40)}"`);
      const { raw, error, status, disconnected } = await dispatchRelay(req, [actionObj], 30000, "GROK-CDP");
      if (disconnected) return;
      if (error) { sendGrokOk(res, "processing", "Command sent. " + error); return; }
      res.writeHead(200, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" });
      res.end(injectBridgeMeta(raw, bm, "GROK-CDP"));
    } catch (err) { relayLog("error", `GROK-CDP unhandled: ${err.message}`); sendGrokOk(res, "processing", "Command received and processing. " + (err.message || "")); }
    return;
  }

  // /api/grok-click-at — click at absolute screen coordinates
  // Required: project, x, y  |  Optional: button (left|right|middle, default left)
  if (pathname === "/api/grok-click-at") {
    if (req.method !== "GET") { sendGrokOk(res, "noted", "Use GET method for this endpoint."); return; }
    try {
      const project = url.searchParams.get("project") || "__system__";
      const xRaw    = url.searchParams.get("x");
      const yRaw    = url.searchParams.get("y");
      const button  = url.searchParams.get("button") || "left";
      if (xRaw === null || yRaw === null) { sendGrokOk(res, "needs_params", "Required: x, y"); return; }
      const x = parseInt(xRaw, 10);
      const y = parseInt(yRaw, 10);
      if (isNaN(x) || isNaN(y)) { sendGrokOk(res, "needs_params", "x and y must be integers"); return; }
      if (!["left", "right", "middle"].includes(button)) { sendGrokOk(res, "needs_params", "button must be left, right, or middle"); return; }
      const bm = buildBridgeMeta(req, project);
      relayLog("info", `GROK-CLICK-AT project=${project} x=${x} y=${y} button=${button}`);
      const { raw, error, status, disconnected } = await dispatchRelay(req, [{ type: "click_at", project, x, y, button }], 15000, "GROK-CLICK-AT");
      if (disconnected) return;
      if (error) { sendGrokOk(res, "processing", "Command sent. " + error); return; }
      res.writeHead(200, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" });
      res.end(injectBridgeMeta(raw, bm, "GROK-CLICK-AT"));
    } catch (err) { relayLog("error", `GROK-CLICK-AT unhandled: ${err.message}`); sendGrokOk(res, "processing", "Command received and processing. " + (err.message || "")); }
    return;
  }

  // /api/grok-send-keys — send text or key combos to the active window
  // Required: project, keys  |  Examples: keys=Hello+World, keys=Ctrl+S, keys=Space
  if (pathname === "/api/grok-send-keys") {
    if (req.method !== "GET") { sendGrokOk(res, "noted", "Use GET method for this endpoint."); return; }
    try {
      const project = url.searchParams.get("project") || "__system__";
      const keys    = url.searchParams.get("keys");
      if (!keys) { sendGrokOk(res, "needs_params", "Required: keys"); return; }
      const bm = buildBridgeMeta(req, project);
      relayLog("info", `GROK-SEND-KEYS project=${project} keys="${keys.substring(0, 60)}"`);
      const { raw, error, status, disconnected } = await dispatchRelay(req, [{ type: "send_keys", project, keys }], 15000, "GROK-SEND-KEYS");
      if (disconnected) return;
      if (error) { sendGrokOk(res, "processing", "Command sent. " + error); return; }
      res.writeHead(200, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" });
      res.end(injectBridgeMeta(raw, bm, "GROK-SEND-KEYS"));
    } catch (err) { relayLog("error", `GROK-SEND-KEYS unhandled: ${err.message}`); sendGrokOk(res, "processing", "Command received and processing. " + (err.message || "")); }
    return;
  }

  if (pathname === "/api/grok-do") {
    const allowedMethods = ["GET", "POST"];
    if (!allowedMethods.includes(req.method)) { sendGrokOk(res, "noted", "Use GET method for this endpoint."); return; }
    const protocol = req.headers["x-forwarded-proto"] || "http";
    const host = req.headers["x-forwarded-host"] || req.headers.host || "localhost:3000";
    const baseUrl = `${protocol}://${host}`;
    try {
      const taskName = url.searchParams.get("task") || url.searchParams.get("macro") || url.searchParams.get("recipe");
      if (taskName) {
        const taskParams = Object.fromEntries(url.searchParams.entries());
        delete taskParams.task; delete taskParams.macro; delete taskParams.recipe; delete taskParams.project;
        delete taskParams._remoteOrigin;
        const reqIp = req.headers["x-forwarded-for"] || req.socket?.remoteAddress || "";
        const isLocal = reqIp === "127.0.0.1" || reqIp === "::1" || reqIp === "::ffff:127.0.0.1" || reqIp.startsWith("192.168.") || reqIp.startsWith("10.") || reqIp === "";
        if (!isLocal) taskParams._remoteOrigin = reqIp;
        if (url.searchParams.get("recall") === "yes" || url.searchParams.get("recall") === "true") {
          const recalled = memoryRecall(taskName);
          if (recalled.length > 0) {
            relayLog("info", `MEMORY RECALL for task=${taskName}: ${recalled.length} past routes found, best=${recalled[0].stepCount} steps / ${recalled[0].elapsedMs}ms`);
          }
        }
        const macro = buildTaskMacro(taskName, taskParams);
        if (macro.error) { sendGrokOk(res, "needs_params", macro.error, { availableTasks: "sketchfab-search, sketchfab-download, sketchfab-to-blender, open-in-blender, download-file, web-search, google-home, website-test, app-test, app-control, comms-test, blender-scene, create-tool, memory, god-mode-test" + (Object.keys(_customTools).length ? ", " + Object.keys(_customTools).join(", ") : "") }); return; }
        if (macro._serverSideAsync && typeof macro.run === "function") {
          relayLog("info", `GROK-DO TASK-MACRO(async) task=${taskName} desc="${macro.description}"`);
          const bm = buildBridgeMeta(req, url.searchParams.get("project") || "__system__");
          const fakeReq = { headers: req.headers || {}, on: () => {}, socket: req.socket };
          const bridgeExec = async (actions) => {
            const { raw, error } = await dispatchRelay(fakeReq, actions, 120000, `TASK-${taskName}`);
            if (error) return { error };
            try { return JSON.parse(raw); } catch { return { raw }; }
          };
          const _taskStartMs = Date.now();
          try {
            const result = await macro.run(bridgeExec);
            const _taskElapsed = Date.now() - _taskStartMs;
            const response = { success: true, task: taskName, description: macro.description, ...result };
            if (result.error) { response.status = "completed_with_notes"; }
            else { memorySave(taskName, taskParams, result.stepsExecuted || 1, _taskElapsed, JSON.stringify(result).slice(0, 300)); }
            const recalled = memoryRecall(taskName);
            if (recalled.length > 0) response._memoryHits = recalled.length;
            if (_lastGrokScreenshot) response._screenshotUrl = `${baseUrl}/api/grok-last-screenshot`;
            res.writeHead(200, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" });
            res.end(injectBridgeMeta(JSON.stringify(response), bm, `TASK-${taskName}`));
          } catch (e) {
            sendGrokOk(res, "processing", "Task is executing. " + (e.message || ""), { task: taskName });
          }
          return;
        }
        relayLog("info", `GROK-DO TASK-MACRO task=${taskName} steps=${macro.steps.length} desc="${macro.description}"`);
        const project = url.searchParams.get("project") || "__system__";
        const bm = buildBridgeMeta(req, project);
        const _seqStartMs = Date.now();
        const allResults = [];
        for (let i = 0; i < macro.steps.length; i++) {
          const step = macro.steps[i];
          if (!step.project) step.project = project;
          step._skipThrottle = true;
          if (step.type === "wait") {
            const waitMs = Math.min(parseInt(step.ms || "1000", 10), 30000);
            await new Promise(r => setTimeout(r, waitMs));
            allResults.push({ step: i, type: "wait", status: "success", data: { waited: waitMs } });
            continue;
          }
          const stepTimeout = parseInt(step.timeout || "60000", 10);
          const { raw, error, disconnected } = await dispatchRelay(req, [step], Math.min(stepTimeout, 120000), `TASK-${taskName}-step${i}`);
          if (disconnected) return;
          if (error) {
            allResults.push({ step: i, type: step.type, status: "error", error });
            continue;
          }
          try {
            const parsed = JSON.parse(raw);
            const stepResult = parsed.results && parsed.results[0] ? parsed.results[0] : parsed;
            allResults.push({ step: i, type: step.type, status: stepResult.status || "success", data: stepResult.data || stepResult });
          } catch {
            allResults.push({ step: i, type: step.type, status: "success", rawLength: (raw || "").length });
          }
        }
        for (const r of allResults) {
          const img = r.data?.image || r.data?.screenshot;
          if (img && img.length > 100) { _lastGrokScreenshot = { base64: img, mimeType: "image/png", capturedAt: Date.now(), source: `task:${taskName}/step${r.step}` }; }
        }
        const _seqElapsed = Date.now() - _seqStartMs;
        const hasErrors = allResults.some(r => r.status === "error");
        if (!hasErrors) { memorySave(taskName, taskParams, allResults.length, _seqElapsed, allResults.map(r => `${r.type}:${r.status}`).join(",")); }
        const response = { success: true, task: taskName, description: macro.description, stepsExecuted: allResults.length, stepsTotal: macro.steps.length, results: allResults };
        if (macro._followUp) response._nextStep = macro._followUp;
        if (_lastGrokScreenshot) response._screenshotUrl = `${baseUrl}/api/grok-last-screenshot`;
        const recalled = memoryRecall(taskName);
        if (recalled.length > 0) response._memoryHits = recalled.length;
        res.writeHead(200, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" });
        res.end(injectBridgeMeta(JSON.stringify(response), bm, `TASK-${taskName}`));
        return;
      }
      let steps = [];
      let delayMs = 0;
      if (req.method === "POST") {
        const body = await new Promise((resolve) => {
          let d = ""; req.on("data", c => d += c); req.on("end", () => resolve(d));
        });
        try {
          const j = JSON.parse(body);
          steps = Array.isArray(j.steps) ? j.steps : (Array.isArray(j.actions) ? j.actions : []);
          delayMs = parseInt(j.delay || "0", 10) || 0;
          if (steps.length === 0 && j.type) steps = [j];
        } catch { /* ignore */ }
      }
      if (steps.length === 0) {
        const stepsParam = url.searchParams.get("steps") || url.searchParams.get("actions");
        if (stepsParam) {
          try { steps = JSON.parse(stepsParam); if (!Array.isArray(steps)) steps = []; } catch { steps = []; }
        }
      }
      if (steps.length === 0) {
        const chainParam = url.searchParams.get("chain");
        if (chainParam) {
          const _knownTypes = new Set(["run","run_command","cmd","shell","wait","delay","snapshot","cdp_snapshot","click","cdp_click","nav","navigate","goto","cdp_navigate","eval","js","cdp_eval","type_text","cdp_type","screenshot","screenshot_window","focus","bring_window_to_front","launch","launch_exe","open","paste","paste_text","keys","send_keys","click_at","list_windows","tabs","cdp_tabs","list"]);
          const _pipeableTypes = new Set(["run","run_command","cmd","shell","eval","js","cdp_eval"]);
          const segments = chainParam.split("|");
          const smartSegments = [];
          for (let si = 0; si < segments.length; si++) {
            const seg = segments[si].trim();
            if (!seg) continue;
            const colonIdx = seg.indexOf(":");
            const segType = colonIdx === -1 ? seg.trim().toLowerCase() : seg.substring(0, colonIdx).trim().toLowerCase();
            const isKnown = _knownTypes.has(segType);
            if (isKnown) {
              smartSegments.push(seg);
            } else if (smartSegments.length > 0) {
              const lastIdx = smartSegments.length - 1;
              const lastColon = smartSegments[lastIdx].indexOf(":");
              const lastType = lastColon === -1 ? smartSegments[lastIdx].trim().toLowerCase() : smartSegments[lastIdx].substring(0, lastColon).trim().toLowerCase();
              if (_pipeableTypes.has(lastType)) {
                smartSegments[lastIdx] += "|" + seg;
              } else {
                smartSegments.push(seg);
              }
            } else {
              smartSegments.push(seg);
            }
          }
          for (const seg of smartSegments) {
            const trimmed = seg.trim();
            if (!trimmed) continue;
            if (trimmed.toLowerCase().startsWith("parallel:")) {
              const parallelParts = trimmed.substring(9).split("+").map(p => p.trim()).filter(Boolean);
              const parallelSteps = [];
              for (const pp of parallelParts) {
                const ci = pp.indexOf(":");
                if (ci === -1) { parallelSteps.push({ type: pp }); }
                else {
                  const pt = pp.substring(0, ci).trim();
                  const pv = pp.substring(ci + 1).trim();
                  if (pt === "snapshot" || pt === "cdp_snapshot") parallelSteps.push({ type: "cdp_snapshot" });
                  else if (pt === "screenshot" || pt === "screenshot_window") parallelSteps.push({ type: "screenshot_window", title: pv });
                  else if (pt === "run" || pt === "run_command") parallelSteps.push({ type: "run_command", command: pv });
                  else if (pt === "eval" || pt === "js") parallelSteps.push({ type: "cdp_eval", code: pv });
                  else if (pt === "tabs" || pt === "cdp_tabs") parallelSteps.push({ type: "cdp_tabs" });
                  else if (pt === "list_windows" || pt === "windows") parallelSteps.push({ type: "list_windows" });
                  else parallelSteps.push({ type: pt, command: pv, selector: pv, title: pv });
                }
              }
              if (parallelSteps.length > 0) steps.push({ type: "_parallel", _parallelSteps: parallelSteps });
              continue;
            }
            const colonIdx = trimmed.indexOf(":");
            if (colonIdx === -1) {
              steps.push({ type: trimmed });
            } else {
              const sType = trimmed.substring(0, colonIdx).trim();
              const sVal = trimmed.substring(colonIdx + 1).trim();
              if (sType === "wait" || sType === "delay") {
                steps.push({ type: "wait", ms: parseInt(sVal, 10) || 3000 });
              } else if (sType === "run_command" || sType === "run" || sType === "cmd" || sType === "shell") {
                steps.push({ type: "run_command", command: sVal });
              } else if (sType === "cdp_click" || sType === "click") {
                steps.push({ type: "cdp_click", selector: sVal });
              } else if (sType === "cdp_type" || sType === "type_text") {
                const parts = sVal.split(">>>");
                steps.push({ type: "cdp_type", selector: parts[0].trim(), text: (parts[1] || "").trim() });
              } else if (sType === "cdp_eval" || sType === "eval" || sType === "js") {
                steps.push({ type: "cdp_eval", code: sVal });
              } else if (sType === "cdp_navigate" || sType === "navigate" || sType === "goto" || sType === "nav") {
                steps.push({ type: "cdp_navigate", url: sVal });
              } else if (sType === "cdp_snapshot" || sType === "snapshot") {
                steps.push({ type: "cdp_snapshot" });
              } else if (sType === "screenshot" || sType === "screenshot_window") {
                steps.push({ type: "screenshot_window", title: sVal });
              } else if (sType === "focus" || sType === "bring_window_to_front") {
                steps.push({ type: "bring_window_to_front", title: sVal });
              } else if (sType === "launch" || sType === "launch_exe" || sType === "open") {
                const parts = sVal.split(">>>");
                steps.push({ type: "launch_exe", path: parts[0].trim(), args: (parts[1] || "").trim() });
              } else if (sType === "paste" || sType === "paste_text") {
                steps.push({ type: "paste_text", text: sVal, send: true });
              } else if (sType === "keys" || sType === "send_keys") {
                steps.push({ type: "send_keys", keys: sVal });
              } else if (sType === "click_at") {
                const coords = sVal.split(",");
                steps.push({ type: "click_at", x: parseInt(coords[0], 10), y: parseInt(coords[1], 10), button: coords[2] || "left" });
              } else {
                steps.push({ type: sType, command: sVal, selector: sVal, title: sVal, url: sVal, text: sVal, code: sVal });
              }
            }
          }
        }
      }
      if (steps.length === 0) {
        const params = Object.fromEntries(url.searchParams.entries());
        const numberedSteps = {};
        for (const [key, val] of Object.entries(params)) {
          const m = key.match(/^(?:step|s|action|a)(\d+)$/i);
          if (m) {
            const idx = parseInt(m[1], 10);
            if (!numberedSteps[idx]) numberedSteps[idx] = {};
            numberedSteps[idx].type = val;
          }
          const m2 = key.match(/^(?:cmd|command|c)(\d+)$/i);
          if (m2) {
            const idx = parseInt(m2[1], 10);
            if (!numberedSteps[idx]) numberedSteps[idx] = {};
            numberedSteps[idx].command = val;
          }
          const m3 = key.match(/^(?:sel|selector)(\d+)$/i);
          if (m3) {
            const idx = parseInt(m3[1], 10);
            if (!numberedSteps[idx]) numberedSteps[idx] = {};
            numberedSteps[idx].selector = val;
          }
          const m4 = key.match(/^(?:url|u)(\d+)$/i);
          if (m4) {
            const idx = parseInt(m4[1], 10);
            if (!numberedSteps[idx]) numberedSteps[idx] = {};
            numberedSteps[idx].url = val;
          }
          const m5 = key.match(/^(?:ms|wait|w)(\d+)$/i);
          if (m5) {
            const idx = parseInt(m5[1], 10);
            if (!numberedSteps[idx]) numberedSteps[idx] = {};
            numberedSteps[idx].ms = val;
          }
          const m6 = key.match(/^(?:text|t)(\d+)$/i);
          if (m6) {
            const idx = parseInt(m6[1], 10);
            if (!numberedSteps[idx]) numberedSteps[idx] = {};
            numberedSteps[idx].text = val;
          }
          const m7 = key.match(/^(?:title)(\d+)$/i);
          if (m7) {
            const idx = parseInt(m7[1], 10);
            if (!numberedSteps[idx]) numberedSteps[idx] = {};
            numberedSteps[idx].title = val;
          }
          const m8 = key.match(/^(?:code|js)(\d+)$/i);
          if (m8) {
            const idx = parseInt(m8[1], 10);
            if (!numberedSteps[idx]) numberedSteps[idx] = {};
            numberedSteps[idx].code = val;
          }
          const m9 = key.match(/^(?:path|p)(\d+)$/i);
          if (m9) {
            const idx = parseInt(m9[1], 10);
            if (!numberedSteps[idx]) numberedSteps[idx] = {};
            numberedSteps[idx].path = val;
          }
          const m10 = key.match(/^(?:args)(\d+)$/i);
          if (m10) {
            const idx = parseInt(m10[1], 10);
            if (!numberedSteps[idx]) numberedSteps[idx] = {};
            numberedSteps[idx].args = val;
          }
        }
        const sortedIdxs = Object.keys(numberedSteps).map(Number).sort((a, b) => a - b);
        if (sortedIdxs.length > 0) {
          for (const idx of sortedIdxs) {
            const s = numberedSteps[idx];
            if (s.type) steps.push(s);
          }
        }
      }
      if (steps.length === 0) {
        const t = url.searchParams.get("type") || url.searchParams.get("action");
        if (t) {
          const stepObj = Object.fromEntries(url.searchParams.entries());
          if (stepObj.action && !stepObj.type) { stepObj.type = stepObj.action; delete stepObj.action; }
          if (stepObj.cmd && !stepObj.command) { stepObj.command = stepObj.cmd; delete stepObj.cmd; }
          steps = [stepObj];
        }
      }
      const _validTypes = new Set(["run_command","run","shell","exec","cmd","cdp_click","click","cdp_navigate","nav","navigate","goto","cdp_snapshot","snapshot","cdp_eval","eval","js","cdp_type","type_text","type","input","screenshot_window","screenshot","bring_window_to_front","focus","launch_exe","launch","open","paste_text","paste","send_keys","keys","type_keys","click_at","list_windows","windows","list","cdp_tabs","tabs","wait","delay","list_tree","read_file","write_file","search_replace","grep","git_status","git_commit","git_diff","list_processes","run_command_advanced","get_window_info","_parallel","delete_file"]);
      steps = steps.filter(s => {
        if (!s.type) return false;
        const t = s.type.toLowerCase().trim();
        if (_validTypes.has(t)) return true;
        if (t.length > 30 || /[(){}\[\];=]/.test(t) || /^['"]/.test(t)) {
          relayLog("warn", `GROK-DO rejected malformed step type: "${t.slice(0,60)}"`);
          return false;
        }
        return true;
      });
      for (const s of steps) {
        if (s.action && !s.type) { s.type = s.action; delete s.action; }
        if (s.cmd && !s.command) { s.command = s.cmd; delete s.cmd; }
        if (s.type === "run" || s.type === "shell" || s.type === "exec") s.type = "run_command";
        if (s.type === "click") s.type = "cdp_click";
        if (s.type === "nav" || s.type === "goto" || s.type === "navigate") s.type = "cdp_navigate";
        if (s.type === "snapshot") s.type = "cdp_snapshot";
        if (s.type === "screenshot") s.type = "screenshot_window";
        if (s.type === "focus") s.type = "bring_window_to_front";
        if (s.type === "launch" || s.type === "open") s.type = "launch_exe";
        if (s.type === "paste") s.type = "paste_text";
        if (s.type === "keys" || s.type === "type_keys") s.type = "send_keys";
        if (s.type === "eval" || s.type === "js") s.type = "cdp_eval";
        if (s.type === "type" || s.type === "type_text" || s.type === "input") s.type = "cdp_type";
        if (s.type === "windows" || s.type === "list") s.type = "list_windows";
        if (s.type === "tabs") s.type = "cdp_tabs";
      }
      if (steps.length === 0) {
        sendGrokOk(res, "needs_params", "No steps found. Use: ?chain=run:dir|wait:3000|snapshot OR ?s1=run_command&c1=dir&s2=wait&w2=3000 OR ?steps=[{...}] OR ?type=run_command&command=dir");
        return;
      }
      const project = url.searchParams.get("project") || "__system__";
      const bm = buildBridgeMeta(req, project);
      relayLog("info", `GROK-DO project=${project} steps=${steps.length} types=[${steps.map(s => s.type).join(",")}]`);
      const allResults = [];
      const warnings = [];
      const confirmParam = url.searchParams.get("confirm") === "yes";
      for (let i = 0; i < steps.length; i++) {
        const step = steps[i];
        if (!step.project) step.project = project;
        if (i > 0) {
          const prev = steps[i - 1];
          const isDupe = prev && prev.type === step.type && prev.command === step.command && prev.selector === step.selector && prev.title === step.title;
          if (!isDupe) step._skipThrottle = true;
        } else {
          step._skipThrottle = true;
        }
        if (step.type === "wait" || step.type === "delay") {
          const waitMs = Math.min(parseInt(step.ms || step.delay || "1000", 10), 30000);
          await new Promise(r => setTimeout(r, waitMs));
          allResults.push({ step: i, type: "wait", status: "success", data: { waited: waitMs } });
          continue;
        }
        if (step.type === "_parallel" && Array.isArray(step._parallelSteps)) {
          relayLog("info", `GROK-DO step${i} PARALLEL fan-out: ${step._parallelSteps.length} concurrent steps`);
          const parallelPromises = step._parallelSteps.map((ps, pi) => {
            if (!ps.project) ps.project = project;
            ps._skipThrottle = true;
            if (!confirmParam) {
              const pRisk = classifyRisk(ps);
              if (pRisk.high) {
                return Promise.resolve({ type: ps.type, status: "needs_confirmation", data: { message: `High-risk action blocked in parallel branch: ${pRisk.reason}. Use &confirm=yes.`, risk: pRisk.reason } });
              }
            }
            const psTimeout = parseInt(ps.timeout || "30000", 10);
            return dispatchRelay(req, [ps], Math.min(psTimeout, 120000), `GROK-DO-step${i}-p${pi}`)
              .then(({ raw, error }) => {
                if (error) return { type: ps.type, status: "error", error };
                try {
                  const parsed = JSON.parse(raw);
                  const sr = parsed.results && parsed.results[0] ? parsed.results[0] : parsed;
                  return { type: ps.type, status: sr.status || "success", data: sr.data || sr };
                } catch { return { type: ps.type, status: "success", rawLength: (raw || "").length }; }
              })
              .catch(e => ({ type: ps.type, status: "error", error: e.message }));
          });
          const parallelResults = await Promise.all(parallelPromises);
          allResults.push({ step: i, type: "_parallel", status: "success", data: { branches: parallelResults.length, results: parallelResults } });
          continue;
        }
        if (!confirmParam) {
          const risk = classifyRisk(step);
          if (risk.high) {
            relayLog("warn", `GROK-DO step${i} SAFETY-FLAGGED: ${risk.reason}`);
            allResults.push({ step: i, type: step.type, status: "needs_confirmation", data: { message: `⚠️ High-risk action blocked: ${risk.reason}. Re-run with &confirm=yes to proceed.`, risk: risk.reason } });
            continue;
          }
        }
        const validation = grokValidateStep(step);
        if (validation.rejected) {
          relayLog("warn", `GROK-DO step${i} REJECTED: ${validation.reason}`);
          allResults.push({ step: i, type: step.type, status: "noted", data: { success: true, message: `Parameter check: ${validation.reason}` } });
          continue;
        }
        const clickCheck = checkClickDedup(step);
        if (clickCheck.blocked) {
          relayLog("warn", `GROK-DO step${i} CLICK-DEDUP: ${clickCheck.reason}`);
          allResults.push({ step: i, type: step.type, status: "success", data: { success: true, message: clickCheck.reason } });
          continue;
        }
        const rateCheck = step._skipThrottle ? { blocked: false } : grokCheckTypeRate(step);
        if (rateCheck.blocked) {
          relayLog("warn", `GROK-DO step${i} RATE-LIMITED: ${rateCheck.reason}`);
          allResults.push({ step: i, type: step.type, status: "already_running", data: { success: true, message: `This command was already sent recently and is likely still executing. ${rateCheck.reason}`, _retryable: false } });
          continue;
        }
        const navLoop = grokCheckNavLoop(step);
        if (navLoop) {
          relayLog("warn", `GROK-DO step${i} NAV-LOOP: ${navLoop}`);
          warnings.push(navLoop);
          allResults.push({ step: i, type: step.type, status: "blocked", error: navLoop });
          continue;
        }
        const stepTimeout = parseInt(step.timeout || "30000", 10);
        const { raw, error, status: httpStatus, disconnected } = await dispatchRelay(req, [step], Math.min(stepTimeout, 120000), `GROK-DO-step${i}`);
        if (disconnected) return;
        if (error) {
          const recovery = classifyError(error);
          if (recovery) {
            relayLog("info", `GROK-DO step${i} AUTO-RECOVERY: ${recovery.strategy} for "${error.slice(0, 80)}"`);
            allResults.push({ step: i, type: step.type, status: "error_recovered", data: { originalError: error, recoveryStrategy: recovery.strategy, recoveryDesc: recovery.desc, _retryable: true } });
          } else {
            allResults.push({ step: i, type: step.type, status: "error", error });
          }
          if (step.stopOnError !== false) break;
          continue;
        }
        try {
          const parsed = JSON.parse(raw);
          const stepResult = parsed.results && parsed.results[0] ? parsed.results[0] : parsed;
          const stepStatus = stepResult.status || "success";
          allResults.push({ step: i, type: step.type, status: stepStatus, data: stepResult.data || stepResult });
          if (stepStatus === "error" && step.stopOnError !== false) break;
        } catch {
          allResults.push({ step: i, type: step.type, status: "success", rawLength: (raw || "").length });
        }
        if (delayMs > 0 && i < steps.length - 1) {
          await new Promise(r => setTimeout(r, Math.min(delayMs, 10000)));
        }
      }
      for (const r of allResults) {
        const img = r.data?.image || r.data?.screenshot;
        if (img && img.length > 100) { _lastGrokScreenshot = { base64: img, mimeType: "image/png", capturedAt: Date.now(), source: `chain/step${r.step}` }; }
      }
      const response = { success: true, stepsExecuted: allResults.length, stepsTotal: steps.length, results: allResults };
      if (warnings.length > 0) response._warnings = warnings;
      if (_lastGrokScreenshot) response._screenshotUrl = `${baseUrl}/api/grok-last-screenshot`;
      res.writeHead(200, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" });
      res.end(injectBridgeMeta(JSON.stringify(response), bm, "GROK-DO"));
    } catch (err) { relayLog("error", `GROK-DO unhandled: ${err.message}`); sendGrokOk(res, "processing", "Command received and processing. " + (err.message || "")); }
    return;
  }

  if (pathname === "/api/grok-paste") {
    try {
      let text = "";
      if (req.method === "GET") {
        text = url.searchParams.get("text") || "";
      } else if (req.method === "POST") {
        const body = await new Promise((resolve) => {
          let d = ""; req.on("data", c => d += c); req.on("end", () => resolve(d));
        });
        try { const j = JSON.parse(body); text = j.text || ""; } catch { text = body; }
      } else { sendGrokOk(res, "noted", "Use GET method for this endpoint."); return; }
      if (!text) { sendGrokOk(res, "needs_params", "Required: text"); return; }
      const project = url.searchParams.get("project") || "__system__";
      const send = url.searchParams.get("send") !== "false";
      const bm = buildBridgeMeta(req, project);
      relayLog("info", `GROK-PASTE project=${project} len=${text.length} send=${send}`);
      const { raw, error, status, disconnected } = await dispatchRelay(req, [{ type: "paste_text", project, text, send }], 30000, "GROK-PASTE");
      if (disconnected) return;
      if (error) { sendGrokOk(res, "processing", "Command sent. " + error); return; }
      res.writeHead(200, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" });
      res.end(injectBridgeMeta(raw, bm, "GROK-PASTE"));
    } catch (err) { relayLog("error", `GROK-PASTE unhandled: ${err.message}`); sendGrokOk(res, "processing", "Command received and processing. " + (err.message || "")); }
    return;
  }

  // /api/grok-get-window-info — get position, size, title of a matched window
  // Required: project  |  At least one of: title, pid
  if (pathname === "/api/grok-get-window-info") {
    if (req.method !== "GET") { sendGrokOk(res, "noted", "Use GET method for this endpoint."); return; }
    try {
      const project = url.searchParams.get("project") || "__system__";
      const title   = url.searchParams.get("title") || null;
      const pidRaw  = url.searchParams.get("pid");
      if (!title && !pidRaw) { sendGrokOk(res, "needs_params", "Required: at least one of title or pid"); return; }
      const pid = pidRaw ? parseInt(pidRaw, 10) : null;
      if (pidRaw && (!Number.isInteger(pid) || pid <= 0)) { sendGrokOk(res, "needs_params", "pid must be a positive integer"); return; }
      const bm = buildBridgeMeta(req, project);
      relayLog("info", `GROK-GET-WINDOW-INFO project=${project} title="${title}" pid=${pid}`);
      const { raw, error, status, disconnected } = await dispatchRelay(req, [{ type: "get_window_info", project, ...(title ? { title } : {}), ...(pid ? { pid } : {}) }], 15000, "GROK-GET-WINDOW-INFO");
      if (disconnected) return;
      if (error) { sendGrokOk(res, "processing", "Command sent. " + error); return; }
      res.writeHead(200, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" });
      res.end(injectBridgeMeta(raw, bm, "GROK-GET-WINDOW-INFO"));
    } catch (err) { relayLog("error", `GROK-GET-WINDOW-INFO unhandled: ${err.message}`); sendGrokOk(res, "processing", "Command received and processing. " + (err.message || "")); }
    return;
  }

  // /api/grok-inject-prompt — inject a prompt into Lamby's Grok chat textarea and send it
  // Required: project, prompt (URL-encoded or POST body)
  if (pathname === "/api/grok-inject-prompt") {
    const allowedMethods = ["GET", "POST"];
    if (!allowedMethods.includes(req.method)) { sendGrokOk(res, "noted", "Use GET method for this endpoint."); return; }
    try {
      const project = url.searchParams.get("project") || "__system__";
      let prompt = url.searchParams.get("prompt") || null;
      if (!prompt && req.method === "POST") {
        const body = await new Promise((resolve) => {
          let data = "";
          req.on("data", chunk => { data += chunk; });
          req.on("end", () => {
            try { resolve(JSON.parse(data)); } catch { resolve({ prompt: data }); }
          });
        });
        prompt = body.prompt || body.text || null;
      }
      if (!prompt) { sendGrokOk(res, "needs_params", "Required: prompt (query param or POST body)"); return; }
      const PLACEHOLDER_RE = /^(YOUR_PROMPT|PROMPT|PROMPT_TEXT|YOUR_TEXT|TEXT|ENTER_PROMPT|INSERT_PROMPT|PLACEHOLDER)$/i;
      if (PLACEHOLDER_RE.test(prompt.trim())) {
        sendGrokOk(res, "needs_params", `Rejected placeholder prompt "${prompt}" — provide actual text, not the template value`);
        return;
      }
      const bm = buildBridgeMeta(req, project);
      relayLog("info", `GROK-INJECT-PROMPT project=${project} prompt="${prompt.substring(0, 80)}${prompt.length > 80 ? '...' : ''}"`);
      const { raw, error, status, disconnected } = await dispatchRelay(req, [{ type: "inject_prompt", project, prompt }], 30000, "GROK-INJECT-PROMPT");
      if (disconnected) return;
      if (error) { sendGrokOk(res, "processing", "Command sent. " + error); return; }
      res.writeHead(200, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" });
      res.end(injectBridgeMeta(raw, bm, "GROK-INJECT-PROMPT"));
    } catch (err) { relayLog("error", `GROK-INJECT-PROMPT unhandled: ${err.message}`); sendGrokOk(res, "processing", "Command received and processing. " + (err.message || "")); }
    return;
  }

  // /api/diag — relay + desktop diagnostics with live round-trip timing
  if (pathname === "/api/diag") {
    const _dHost  = req.headers.host || `localhost:${PORT}`;
    const _dProto = req.headers["x-forwarded-proto"] || "https";
    const _dBase  = `${_dProto}://${_dHost}`;
    const _dProject = url.searchParams.get("project") || null;
    const _dClient = ((_dProject && desktopClients.get(_dProject)) || findBridgeClient(null));
    const _desktopConnected = !!(_dClient?.alive);
    const diagBase = { relay: "Lamby Bridge Relay", ts: new Date().toISOString(), uptime: Math.floor(process.uptime()), port: PORT,
      desktop: { connected: _desktopConnected, project: _dClient?.project || null,
        bridgeKeyPrefix: _dClient?.bridgeKey ? _dClient.bridgeKey.substring(0, 8) + "..." : null,
        lastPingSecondsAgo: _dClient?.lastPing ? Math.round((Date.now() - _dClient.lastPing) / 1000) : null,
        connectedDesktops: [...desktopClients.values()].filter(c => c.alive).length },
      pendingRequests: pendingSandboxRelayRequests.size, activityLogSize: activityLog.length, coordBoardSize: coordBoard.length };
    // Live round-trip test (list_tree) if desktop connected
    let roundTrip = null;
    if (_desktopConnected && _dProject) {
      try {
        const t0 = Date.now();
        const rt = await dispatchRelay(req, [{ type: "list_tree", project: _dProject }], 15000, "DIAG-ROUNDTRIP", { noActivity: true });
        roundTrip = { ok: !rt.error && !rt.disconnected, latencyMs: Date.now() - t0, error: rt.error || null };
      } catch (e) { roundTrip = { ok: false, error: e.message }; }
    }
    const p = _dProject;
    // Per-endpoint pass/fail matrix — pass requires: desktop connected AND live roundtrip ok AND project known
    const _epOk = _desktopConnected && p && (roundTrip?.ok !== false);
    const _epStatus = (endpointName) => _epOk ? "PASS" : (!_desktopConnected ? "FAIL (desktop not connected)" : !p ? "FAIL (no project)" : "FAIL (roundtrip failed)");
    const endpointPassFail = {
      "grok-read":                 { status: _epStatus(), url: p ? `${_dBase}/api/grok-read?project=${p}&path=package.json`               : null },
      "grok-write":                { status: _epStatus(), url: p ? `${_dBase}/api/grok-write?project=${p}&path=FILE&search=X&replace=Y`   : null },
      "grok-create":               { status: _epStatus(), url: p ? `${_dBase}/api/grok-create?project=${p}&path=FILE&content=CONTENT`     : null },
      "grok-create-chunk":         { status: _epStatus(), url: p ? `${_dBase}/api/grok-create-chunk?project=${p}&path=FILE&content=C&chunk=0&total=1` : null },
      "grok-delete":               { status: _epStatus(), url: p ? `${_dBase}/api/grok-delete?project=${p}&path=FILE`                     : null },
      "grok-tree":                 { status: _epStatus(), url: p ? `${_dBase}/api/grok-tree?project=${p}`                                 : null },
      "grok-run":                  { status: _epStatus(), url: p ? `${_dBase}/api/grok-run?project=${p}&cmd=echo+hello`                   : null },
      "grok-git":                  { status: _epStatus(), url: p ? `${_dBase}/api/grok-git?project=${p}&action=status`                    : null },
      "grok-process":              { status: _epStatus(), url: p ? `${_dBase}/api/grok-process?project=${p}&action=list`                  : null },
      "grok-search":               { status: _epStatus(), url: p ? `${_dBase}/api/grok-search?project=${p}&q=TODO`                        : null },
      "grok-quality":              { status: _epStatus(), url: p ? `${_dBase}/api/grok-quality?project=${p}&checks=type`                  : null },
      "grok-deps":                 { status: _epStatus(), url: p ? `${_dBase}/api/grok-deps?project=${p}&action=install`                  : null },
      "grok-super":                { status: _desktopConnected && p ? "CONDITIONAL (needs XAI_API on desktop)" : _epStatus(), url: p ? `${_dBase}/api/grok-super?project=${p}&describe=list+files` : null },
      "grok-graph":                { status: _epStatus(), url: p ? `${_dBase}/api/grok-graph?project=${p}&action=index`                   : null },
      "grok-changeset":            { status: _epStatus(), url: p ? `${_dBase}/api/grok-changeset?project=${p}&action=validate&ops=W10=`   : null },
      "grok-macro/project-status": { status: _epStatus(), url: p ? `${_dBase}/api/grok-macro/project-status?project=${p}`                 : null },
      "grok-macro/read-context":   { status: _epStatus(), url: p ? `${_dBase}/api/grok-macro/read-context?project=${p}&path=package.json` : null },
      "grok-launch-exe":           { status: _epStatus(), url: p ? `${_dBase}/api/grok-launch-exe?project=${p}&path=C%3A%5CProgram+Files%5Cnotepad.exe` : null },
      "grok-list-windows":         { status: _epStatus(), url: p ? `${_dBase}/api/grok-list-windows?project=${p}`                                        : null },
      "grok-bring-to-front":       { status: _epStatus(), url: p ? `${_dBase}/api/grok-bring-to-front?project=${p}&title=Notepad`                        : null },
      "grok-screenshot-window":    { status: _epStatus(), url: p ? `${_dBase}/api/grok-screenshot-window?project=${p}&title=Notepad`                     : null },
      "grok-click-at":             { status: _epStatus(), url: p ? `${_dBase}/api/grok-click-at?project=${p}&x=100&y=200&button=left`                    : null },
      "grok-send-keys":            { status: _epStatus(), url: p ? `${_dBase}/api/grok-send-keys?project=${p}&keys=Ctrl%2BS`                             : null },
      "grok-get-window-info":      { status: _epStatus(), url: p ? `${_dBase}/api/grok-get-window-info?project=${p}&title=Notepad`                       : null },
    };
    const readyUrls = p ? {
      read:        `${_dBase}/api/grok-read?project=${p}&path=FILE`,
      write:       `${_dBase}/api/grok-write?project=${p}&path=FILE&search=OLD&replace=NEW`,
      tree:        `${_dBase}/api/grok-tree?project=${p}`,
      run:         `${_dBase}/api/grok-run?project=${p}&cmd=COMMAND`,
      git:         `${_dBase}/api/grok-git?project=${p}&action=status`,
      process:     `${_dBase}/api/grok-process?project=${p}&action=list`,
      search:      `${_dBase}/api/grok-search?project=${p}&q=PATTERN`,
      quality:     `${_dBase}/api/grok-quality?project=${p}`,
      deps:        `${_dBase}/api/grok-deps?project=${p}&action=install`,
      super:       `${_dBase}/api/grok-super?project=${p}&describe=TEXT`,
      graph:       `${_dBase}/api/grok-graph?project=${p}&action=index`,
      changeset:   `${_dBase}/api/grok-changeset?project=${p}&action=validate&ops=OPS_BASE64`,
      macroStatus:      `${_dBase}/api/grok-macro/project-status?project=${p}`,
      macroCtx:         `${_dBase}/api/grok-macro/read-context?project=${p}&path=FILE`,
      grokDo:           `${_dBase}/api/grok-do?chain=run:COMMAND|wait:3000|snapshot`,
      grokDoNote:       "USE grok-do?chain= for ALL desktop control. Individual endpoints are rate-limited.",
      diag:             `${_dBase}/api/diag?project=${p}`,
      coord:            `${_dBase}/api/coord`,
    } : null;
    sendJson(res, Object.assign({}, diagBase, {
      roundTrip: roundTrip || (_desktopConnected ? "skipped (no project param — add ?project=NAME)" : "skipped (desktop not connected)"),
      endpointPassFail,
      readyUrls,
    }));
    return;
  }

  // /api/coord — in-memory coordination ring buffer (max 50 entries)
  // spec: ?note=TEXT&from=SOURCE → append; ?clear=1 → clear; no params → last 20
  // Dedup: exact-match note+from within last 60 s is rejected (idempotent retry-safe).
  //        ?force=1 bypasses dedup to allow intentional re-post.
  if (pathname === "/api/coord") {
    const _note  = smartDecode(url.searchParams.get("note") || "");
    const _from  = smartDecode(url.searchParams.get("from") || "grok");
    const _clear = url.searchParams.get("clear") === "1";
    const _tag   = smartDecode(url.searchParams.get("tag") || "");
    const _force = url.searchParams.get("force") === "1";
    if (_clear) {
      const prev = coordBoard.length;
      coordBoard.length = 0;
      sendJson(res, { ok: true, cleared: prev });
    } else if (_note) {
      // Dedup: reject if an identical (note+from) entry exists in the last 60 seconds
      if (!_force) {
        const now = Date.now();
        const dup = coordBoard.slice(-20).find(e => e.from === _from.substring(0, 50) && e.note === _note.substring(0, 500) && (now - e.ts) < 60000);
        if (dup) {
          relayLog("info", `COORD dedup — same note from=${_from} age=${Math.round((now - dup.ts) / 1000)}s`);
          sendJson(res, { ok: true, deduplicated: true, reason: "identical note posted within 60s — use ?force=1 to override", existing: dup, total: coordBoard.length });
          return;
        }
      }
      const entry = { id: crypto.randomUUID().substring(0, 8), ts: Date.now(), from: _from.substring(0, 50), note: _note.substring(0, 500), tag: _tag.substring(0, 50) };
      coordBoard.push(entry);
      if (coordBoard.length > 50) coordBoard.splice(0, coordBoard.length - 50);
      sendJson(res, { ok: true, entry, total: coordBoard.length });
    } else {
      const filtered = _tag ? coordBoard.filter(e => e.tag === _tag) : coordBoard.slice(-20);
      sendJson(res, { total: coordBoard.length, returned: filtered.length, items: filtered });
    }
    return;
  }

  res.writeHead(404, { "Content-Type": "application/json" });
  res.end(JSON.stringify({ error: "Not found", endpoints: ["/", "/api/grok", "/api/grok-do", "/api/grok-edit", "/api/grok-read", "/api/grok-write", "/api/grok-create", "/api/grok-create-chunk", "/api/grok-delete", "/api/grok-tree", "/api/grok-run", "/api/grok-git", "/api/grok-process", "/api/grok-search", "/api/grok-quality", "/api/grok-deps", "/api/grok-super", "/api/grok-graph", "/api/grok-changeset", "/api/grok-macro/project-status", "/api/grok-macro/read-context", "/api/grok-interact", "/api/grok-proxy", "/api/snapshot-key", "/api/bridge-status", "/api/snapshot/:project", "/api/console-logs", "/api/sandbox/execute", "/api/sandbox/audit-log", "/api/screenshot-data/:project", "/api/commands", "/api/diag", "/api/coord", "/api/grok-launch-exe", "/api/grok-list-windows", "/api/grok-bring-to-front", "/api/grok-screenshot-window", "/api/grok-click-at", "/api/grok-send-keys", "/api/grok-paste", "/api/grok-get-window-info", "/api/grok-reference"] }));
});
server.on("upgrade", (req, socket, head) => {
  const ip = req.headers["x-forwarded-for"] || req.socket?.remoteAddress || "?";
  const ua = req.headers["user-agent"] || "";
  relayLog("info", `WS-UPGRADE attempt url=${req.url} ip=${ip} ua=${ua.substring(0, 60)}`);
  const reqUrl = new URL(req.url || "", "http://localhost");
  if (req.url && req.url.startsWith("/bridge-ws")) {
    const clientProject = reqUrl.searchParams.get("project") || "";
    handleWsUpgrade(req, socket, clientProject);
    return;
  }
  relayLog("warn", `WS-UPGRADE rejected bad-path url=${req.url}`);
  socket.destroy();
});
setInterval(() => {
  const now = Date.now();
  for (const [project, client] of desktopClients) {
    // Only prune truly dead clients (no ping for 10 minutes AND not reconnecting)
    if (now - client.lastPing > 600000 && !client.reconnecting) {
      relayLog("warn", `Pruning stale desktop client project=${project} key=${client.bridgeKey?.substring(0, 8)}... lastPing=${Math.round((now - client.lastPing)/1000)}s ago`);
      client.alive = false;
      try { client.socket.destroy(); } catch {}
      desktopClients.delete(project);
    }
  }
}, 60000);
process.on("uncaughtException", (err) => {
  console.error(`[Bridge] Uncaught exception: ${err.message}`);
  console.error(err.stack);
});
process.on("unhandledRejection", (reason) => {
  console.error(`[Bridge] Unhandled rejection: ${reason}`);
});
server.listen(PORT, "0.0.0.0", () => {
  console.log(`[Lamby Bridge Relay]`);
  console.log(`  Running on port ${PORT}`);
  console.log(`  Zero dependencies — pure Node.js`);
  console.log(`  Endpoints:`);
  console.log(`    GET  /                      Health check`);
  console.log(`    GET  /api/snapshot-key       Get connection info`);
  console.log(`    GET  /api/bridge-status      Connected clients (public)`);
  console.log(`    GET  /api/snapshot/:project   Get project snapshot (via desktop)`);
  console.log(`    GET  /api/console-logs       Get desktop console logs (via desktop)`);
  console.log(`    POST /api/sandbox/execute    Execute actions (via desktop)`);
  console.log(`    GET  /api/sandbox/audit-log  Recent actions`);
  console.log(`    GET  /api/grok               Full AI agent docs + all commands (browse this!)`);
  console.log(`    GET  /api/screenshot/:project  Clean screenshot URL — no & needed (best for browse_page)`);
  console.log(`    GET  /api/grok-edit          Search-replace, no encoding (best for Grok)`);
  console.log(`    GET  /api/grok-read          Read single/multi files`);
  console.log(`    GET  /api/grok-write         Search+replace with auto-verify`);
  console.log(`    GET  /api/grok-tree          List file tree (filterable)`);
  console.log(`    GET  /api/grok-run           Run shell command`);
  console.log(`    GET  /api/grok-git           All 16 git ops via ?action=`);
  console.log(`    GET  /api/grok-process       Process mgmt via ?action=`);
  console.log(`    GET  /api/grok-search        Unified search (grep/symbol/glob/files)`);
  console.log(`    GET  /api/grok-quality       Batch quality checks (type+lint+format)`);
  console.log(`    GET  /api/grok-deps          Dependency management`);
  console.log(`    GET  /api/grok-super         super_command as GET`);
  console.log(`    GET  /api/grok-graph         Graph intelligence (index/query/impact/pattern)`);
  console.log(`    GET  /api/grok-changeset     Validated batch file ops (validate/apply/simulate)`);
  console.log(`    GET  /api/grok-macro/project-status  Parallel project overview`);
  console.log(`    GET  /api/grok-macro/read-context    File + import map`);
  console.log(`    GET  /api/grok-interact      Browser interact: click, runFunction, evaluate`);
  console.log(`    GET  /api/grok-proxy         GET proxy (base64 payload → execute)`);
  console.log(`    GET  /api/commands           Compact command type list`);
  console.log(`    GET  /api/diag               Relay diagnostics`);
  console.log(`    GET  /api/coord              Coordination ring buffer`);
  console.log(`    WS   /bridge-ws             Desktop WebSocket connection`);
});
